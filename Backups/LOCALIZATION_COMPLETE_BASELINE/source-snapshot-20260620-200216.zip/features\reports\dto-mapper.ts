export function buildReportAnalytics({
  customerCount,
  revenueLak,
  transactionCount,
}: {
  customerCount: number;
  revenueLak: number;
  transactionCount: number;
}) {
  return {
    categoryBreakdown: [],
    totalCustomers: customerCount,
    totalProfit: 0,
    totalRevenue: revenueLak,
    totalTransactions: transactionCount,
  };
}
