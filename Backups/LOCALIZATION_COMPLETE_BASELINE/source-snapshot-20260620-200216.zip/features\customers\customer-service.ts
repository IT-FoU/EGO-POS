import {
  mockCustomerPayments,
  mockCustomerPurchases,
  mockCustomers,
  mockMembershipLevels,
} from "@/features/customers/mock-data";
import type { Customer, CustomerPayment, CustomerPurchase, MembershipLevel } from "@/features/customers/types";
import { isDemoMode } from "@/lib/demo-mode";
import { requireSession } from "@/lib/auth/session";
import { tenantFromSession } from "@/lib/db/write-context";
import {
  getPrismaCustomerById,
  getPrismaCustomerDetail,
  getPrismaCustomers,
  getPrismaCustomersSnapshot,
} from "@/features/customers/prisma-repository";

export async function getCustomersSnapshot(): Promise<{
  customers: Customer[];
  levels: MembershipLevel[];
  payments: CustomerPayment[];
  purchases: CustomerPurchase[];
}> {
  if (!isDemoMode()) {
    return getPrismaCustomersSnapshot(tenantFromSession(await requireSession()));
  }

  return {
    customers: mockCustomers,
    levels: mockMembershipLevels,
    payments: mockCustomerPayments,
    purchases: mockCustomerPurchases,
  };
}

export async function getCustomers(): Promise<Customer[]> {
  if (!isDemoMode()) {
    return getPrismaCustomers(tenantFromSession(await requireSession()));
  }

  return mockCustomers;
}

export async function getCustomerById(customerId: string): Promise<Customer | undefined> {
  if (!isDemoMode()) {
    return getPrismaCustomerById(customerId, tenantFromSession(await requireSession()));
  }

  return mockCustomers.find((customer) => customer.id === customerId);
}

export async function getCustomerDetail(customerId: string): Promise<{
  customer: Customer | undefined;
  levels: MembershipLevel[];
  payments: CustomerPayment[];
  purchases: CustomerPurchase[];
}> {
  if (!isDemoMode()) {
    return getPrismaCustomerDetail(customerId, tenantFromSession(await requireSession()));
  }

  const customer = await getCustomerById(customerId);

  return {
    customer,
    levels: mockMembershipLevels,
    payments: mockCustomerPayments.filter((payment) => payment.customerId === customerId),
    purchases: mockCustomerPurchases.filter(
      (purchase) => purchase.customerId === customerId,
    ),
  };
}
