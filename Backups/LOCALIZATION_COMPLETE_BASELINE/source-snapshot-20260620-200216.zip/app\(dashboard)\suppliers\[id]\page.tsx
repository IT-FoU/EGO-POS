import { notFound } from "next/navigation";
import { SupplierDetailClient } from "@/features/suppliers/components/supplier-detail-client";
import { getSupplierDetail, getSuppliers } from "@/features/suppliers/supplier-service";

export async function generateStaticParams() {
  const suppliers = await getSuppliers();

  return suppliers.map((supplier) => ({
    id: supplier.id,
  }));
}

export default async function SupplierDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const { payments, purchaseOrders, receivings, supplier } =
    await getSupplierDetail(id);

  if (!supplier) {
    notFound();
  }

  return (
    <SupplierDetailClient
      payments={payments}
      purchaseOrders={purchaseOrders}
      receivings={receivings}
      supplier={supplier}
    />
  );
}
