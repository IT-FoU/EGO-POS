import { MembershipLevelsClient } from "@/features/membership-levels/components/membership-levels-client";
import { getMembershipLevels } from "@/features/membership-levels/membership-level-service";

export default async function MembershipLevelsPage() {
  const levels = await getMembershipLevels();

  return <MembershipLevelsClient levels={levels} />;
}
