import type { PaymentMode, PosProduct } from "@/features/pos/types";

type Row = Record<string, any>;

function toNumber(value: unknown) {
  return value == null ? 0 : Number(value);
}

export function mapPrismaPosProduct(product: Row): PosProduct {
  const units = (product.units ?? [])
    .map((unit: Row) => ({
      allowManualUnitSelect: unit.allowManualUnitSelect ?? true,
      barcode: unit.barcode ?? "",
      conversionQty: toNumber(unit.conversionQty),
      costPriceLak: toNumber(unit.costPriceLak ?? product.costPriceLak),
      id: unit.id,
      imageUrl: unit.imageUrl ?? undefined,
      isBaseUnit: Boolean(unit.isBaseUnit),
      isDefaultSaleUnit: Boolean(unit.isDefaultSaleUnit),
      isPurchaseUnit: Boolean(unit.isPurchaseUnit),
      sellingPriceLak: toNumber(unit.sellingPriceLak),
      sortOrder: toNumber(unit.sortOrder),
      status: unit.status ?? "active",
      unitName: unit.unitName ?? "",
    }))
    .sort((left: Row, right: Row) => toNumber(left.sortOrder) - toNumber(right.sortOrder));
  const activeUnits = units.filter((unit: Row) => unit.status !== "inactive");
  const defaultSaleUnit = activeUnits.find((unit: Row) => unit.isDefaultSaleUnit) ?? activeUnits.find((unit: Row) => unit.isBaseUnit) ?? activeUnits[0];
  const baseUnit = activeUnits.find((unit: Row) => unit.isBaseUnit) ?? defaultSaleUnit;
  const stockQty = (product.balances ?? []).reduce(
    (total: number, balance: Row) => total + toNumber(balance.quantity),
    0,
  );

  return {
    barcode: product.barcode ?? "",
    categoryName: product.category?.nameEn ?? product.category?.nameLo ?? "",
    id: product.id,
    imageKey: product.imageUrl ?? "generic",
    unitImageUrl: defaultSaleUnit?.imageUrl ?? undefined,
    nameEn: product.nameEn ?? "",
    nameLo: product.nameLo,
    priceLak: toNumber(defaultSaleUnit?.sellingPriceLak ?? product.sellingPriceLak),
    costPriceLak: toNumber(defaultSaleUnit?.costPriceLak ?? product.costPriceLak),
    productCode: product.productCode ?? "",
    sku: product.sku ?? "",
    stockQty,
    unitName: defaultSaleUnit?.unitName ?? baseUnit?.unitName ?? "Piece",
    units,
  };
}

export function mapPaymentModeToSalePayments({
  cardAmount = 0,
  cashAmount,
  changeAmount,
  paymentMode,
  qrAmount,
  transferAmount = 0,
}: {
  cardAmount?: number;
  cashAmount: number;
  changeAmount: number;
  paymentMode: PaymentMode;
  qrAmount: number;
  transferAmount?: number;
}) {
  if (paymentMode === "mixed") {
    return [
      { amount: cashAmount, changeAmount, paymentMethod: "cash" as const },
      { amount: qrAmount, changeAmount: 0, paymentMethod: "qr" as const },
      { amount: transferAmount, changeAmount: 0, paymentMethod: "transfer" as const },
      { amount: cardAmount, changeAmount: 0, paymentMethod: "visa" as const },
    ].filter((payment) => payment.amount > 0);
  }

  if (paymentMode === "transfer") {
    return [{ amount: transferAmount, changeAmount: 0, paymentMethod: "transfer" as const }];
  }

  if (paymentMode === "card") {
    return [{ amount: cardAmount, changeAmount: 0, paymentMethod: "visa" as const }];
  }

  return [
    {
      amount: paymentMode === "cash" ? cashAmount : qrAmount,
      changeAmount,
      paymentMethod: paymentMode,
    },
  ];
}
