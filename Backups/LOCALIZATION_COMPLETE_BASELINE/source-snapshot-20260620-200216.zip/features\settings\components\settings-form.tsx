"use client";

import { t } from "@/lib/i18n/ui";
import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Building2, CheckCircle2, ClipboardCheck, Edit3, Eye, Gift, ImagePlus, KeyRound, MonitorPlay, Percent, Plus, QrCode, ReceiptText, Save, ShieldCheck, Trash2, Users, WalletCards, X, type LucideIcon } from "lucide-react";
import { LogoContainer } from "@/components/brand/logo-container";
import { updateSettingsAction } from "@/features/settings/actions";
import type { CurrencyCode, SettingsFormData } from "@/features/settings/types";
import { CUSTOMER_DISPLAY_TEMPLATES, DEFAULT_CUSTOMER_DISPLAY_SETTINGS, readCustomerDisplaySettingsFromStorage, writeCustomerDisplaySettingsToStorage, type CustomerDisplayMedia, type CustomerDisplaySettings, type CustomerDisplayTemplate, } from "@/features/pos/customer-display-settings";
type QrBankSetting = {
    id: string;
    bankName: string;
    accountName: string;
    accountNumber: string;
    qrImageUrl?: string;
};
const QR_BANKS_KEY = t("ui.ego.pos.qr.banks");
export function SettingsForm({ initialSettings }: {
    initialSettings: SettingsFormData;
}) {
    const router = useRouter();
    const [isPending, startTransition] = useTransition();
    const [logoUrl, setLogoUrl] = useState<string | null>(null);
    const [qrBanks, setQrBanks] = useState<QrBankSetting[]>([]);
    const [qrDraft, setQrDraft] = useState({ accountName: "", accountNumber: "", bankName: "BCEL", qrImageUrl: "" });
    const [displaySettings, setDisplaySettings] = useState<CustomerDisplaySettings>(DEFAULT_CUSTOMER_DISPLAY_SETTINGS);
    const [promotionDraft, setPromotionDraft] = useState("");
    const [settings, setSettings] = useState(initialSettings);
    const [message, setMessage] = useState<{
        tone: "error" | "success";
        text: string;
    } | null>(null);
    useEffect(() => {
        setLogoUrl(window.localStorage.getItem(t("ui.ego.pos.company.logo.url")));
        setDisplaySettings(readCustomerDisplaySettingsFromStorage());
        const storedQrBanks = window.localStorage.getItem(QR_BANKS_KEY);
        if (storedQrBanks) {
            try {
                setQrBanks(JSON.parse(storedQrBanks) as QrBankSetting[]);
            }
            catch {
                setQrBanks([]);
            }
        }
    }, []);
    function update<K extends keyof SettingsFormData>(key: K, value: SettingsFormData[K]) {
        setSettings((current) => ({ ...current, [key]: value }));
    }
    function updateLogo(event: React.ChangeEvent<HTMLInputElement>) {
        const file = event.target.files?.[0];
        if (!file || !["image/png", t("ui.image.svg.xml"), "image/webp"].includes(file.type)) {
            setMessage({ text: t("ui.company.logo.must.be.png.svg.or.webp"), tone: "error" });
            return;
        }
        const reader = new FileReader();
        reader.onload = () => {
            if (typeof reader.result !== "string") {
                return;
            }
            window.localStorage.setItem(t("ui.ego.pos.company.logo.url"), reader.result);
            setLogoUrl(reader.result);
            setMessage({ text: t("ui.company.logo.saved.for.this.business.profile"), tone: "success" });
        };
        reader.readAsDataURL(file);
    }
    function persistQrBanks(nextBanks: QrBankSetting[]) {
        setQrBanks(nextBanks);
        window.localStorage.setItem(QR_BANKS_KEY, JSON.stringify(nextBanks));
    }
    function persistCustomerDisplaySettings(nextSettings: CustomerDisplaySettings) {
        setDisplaySettings(nextSettings);
        writeCustomerDisplaySettingsToStorage(nextSettings);
    }
    function updateDisplayTemplate(template: CustomerDisplayTemplate) {
        persistCustomerDisplaySettings({ ...displaySettings, template });
        setMessage({ text: t("ui.customer.display.template.updated"), tone: "success" });
    }
    function updateDisplayAutoReturn(seconds: number) {
        persistCustomerDisplaySettings({ ...displaySettings, autoReturnSeconds: Math.max(1, seconds) });
    }
    function addPromotionMessage() {
        const messageText = promotionDraft.trim();
        if (!messageText) {
            setMessage({ text: t("ui.promotion.message.is.required"), tone: "error" });
            return;
        }
        persistCustomerDisplaySettings({
            ...displaySettings,
            promotionMessages: [...displaySettings.promotionMessages, messageText].slice(-8),
        });
        setPromotionDraft("");
        setMessage({ text: t("ui.promotion.message.saved.for.customer.display"), tone: "success" });
    }
    function deletePromotionMessage(index: number) {
        persistCustomerDisplaySettings({
            ...displaySettings,
            promotionMessages: displaySettings.promotionMessages.filter((_, itemIndex) => itemIndex !== index),
        });
    }
    function updateDisplayMedia(event: React.ChangeEvent<HTMLInputElement>) {
        const file = event.target.files?.[0];
        if (!file || !["image/jpeg", "image/png", "image/webp", t("ui.video.mp4")].includes(file.type)) {
            setMessage({ text: t("ui.customer.display.media.must.be.jpg.png.webp."), tone: "error" });
            return;
        }
        const reader = new FileReader();
        reader.onload = () => {
            if (typeof reader.result !== "string") {
                return;
            }
            const media: CustomerDisplayMedia = {
                id: `display-media-${Date.now()}`,
                name: file.name,
                type: file.type === t("ui.video.mp4") ? "video" : "image",
                url: reader.result,
            };
            persistCustomerDisplaySettings({
                ...displaySettings,
                media: [media, ...displaySettings.media].slice(0, 12),
            });
            setMessage({ text: t("ui.customer.display.media.saved"), tone: "success" });
        };
        reader.readAsDataURL(file);
    }
    function deleteDisplayMedia(id: string) {
        persistCustomerDisplaySettings({
            ...displaySettings,
            media: displaySettings.media.filter((media) => media.id !== id),
        });
    }
    function updateQrImage(event: React.ChangeEvent<HTMLInputElement>) {
        const file = event.target.files?.[0];
        if (!file || !["image/png", t("ui.image.svg.xml"), "image/webp"].includes(file.type)) {
            setMessage({ text: t("ui.qr.image.must.be.png.svg.or.webp"), tone: "error" });
            return;
        }
        const reader = new FileReader();
        reader.onload = () => {
            if (typeof reader.result === "string") {
                setQrDraft((current) => ({ ...current, qrImageUrl: reader.result as string }));
            }
        };
        reader.readAsDataURL(file);
    }
    function addQrBank() {
        if (!qrDraft.bankName.trim() || !qrDraft.accountName.trim() || !qrDraft.accountNumber.trim()) {
            setMessage({ text: t("ui.bank.name.account.name.and.account.number.ar"), tone: "error" });
            return;
        }
        persistQrBanks([
            ...qrBanks,
            {
                accountName: qrDraft.accountName.trim(),
                accountNumber: qrDraft.accountNumber.trim(),
                bankName: qrDraft.bankName.trim(),
                id: `qr-${Date.now()}`,
                qrImageUrl: qrDraft.qrImageUrl || undefined,
            },
        ]);
        setQrDraft({ accountName: "", accountNumber: "", bankName: "BCEL", qrImageUrl: "" });
        setMessage({ text: t("ui.qr.bank.saved.for.pos.checkout"), tone: "success" });
    }
    function deleteQrBank(id: string) {
        persistQrBanks(qrBanks.filter((bank) => bank.id !== id));
        setMessage({ text: t("ui.qr.bank.deleted"), tone: "success" });
    }
    function validate() {
        if (!settings.companyName.trim())
            return t("ui.company.name.is.required");
        if (settings.vatRate < 0 || settings.vatRate > 100)
            return t("ui.vat.rate.must.be.between.0.and.100");
        if (settings.decimalPlaces < 0 || settings.decimalPlaces > 4)
            return t("ui.decimal.places.must.be.between.0.and.4");
        if (settings.loyaltySpendPerPointLak <= 0)
            return t("ui.loyalty.spend.per.point.must.be.greater.than");
        if (settings.loyaltyPointValueLak < 0)
            return t("ui.loyalty.point.value.cannot.be.negative");
        if (settings.loyaltyMinRedeemPoints < 1)
            return t("ui.minimum.redeem.points.must.be.at.least.1");
        return null;
    }
    function saveSettings(event: React.FormEvent<HTMLFormElement>) {
        event.preventDefault();
        const validationError = validate();
        if (validationError) {
            setMessage({ text: validationError, tone: "error" });
            return;
        }
        setMessage(null);
        startTransition(async () => {
            const result = await updateSettingsAction(settings);
            if (!result.ok || !result.data) {
                setMessage({ text: result.error ?? t("ui.settings.save.failed"), tone: "error" });
                return;
            }
            setSettings(result.data as SettingsFormData);
            setMessage({ text: t("ui.settings.saved.successfully"), tone: "success" });
            router.refresh();
        });
    }
    return (<form className="flex flex-col gap-6" onSubmit={saveSettings}>
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div>
          <h1 className="text-3xl font-semibold">Settings</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">{t("ui.company.profile.receipt.tax.currency.and.loy")}</p>
        </div>
        <button className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground transition hover:opacity-90 disabled:opacity-60" disabled={isPending} type="submit">
          <Save aria-hidden="true"/>
          {isPending ? t("ui.saving") : "Save settings"}
        </button>
      </div>

      {message ? (<div className={message.tone === "success"
                ? "rounded-md border border-success/40 bg-success/10 px-4 py-3 text-sm text-success"
                : "rounded-md border border-danger/40 bg-danger/10 px-4 py-3 text-sm text-danger"}>
          {message.text}
        </div>) : null}

      <section className="rounded-lg border border-border bg-card p-5">
        <SectionTitle icon={Building2} title="Company Profile"/>
        <div className="mt-5 grid gap-4 md:grid-cols-2">
          <div className="md:col-span-2">
            <div className="flex flex-col gap-4 rounded-md border border-border bg-background p-4 sm:flex-row sm:items-center">
              <LogoContainer logoUrl={logoUrl} size={96}/>
              <label className="grid flex-1 gap-2 text-sm font-medium">
                Company Logo
                <input accept={t("ui.image.png.image.svg.xml.image.webp")} className="block w-full rounded-md border border-border bg-card px-3 py-3 text-sm" type="file" onChange={updateLogo}/>
                <span className="text-xs leading-5 text-muted-foreground">{t("ui.supports.png.svg.and.webp.for.sidebar.receip")}</span>
              </label>
            </div>
          </div>
          <Field label="Company name">
            <input className="field-input" required value={settings.companyName} onChange={(event) => update("companyName", event.target.value)}/>
          </Field>
          <Field label="Tax number">
            <input className="field-input" value={settings.taxNumber ?? ""} onChange={(event) => update("taxNumber", event.target.value)}/>
          </Field>
          <Field label="Phone">
            <input className="field-input" value={settings.profilePhone ?? ""} onChange={(event) => update("profilePhone", event.target.value)}/>
          </Field>
          <Field label="Email">
            <input className="field-input" type="email" value={settings.profileEmail ?? ""} onChange={(event) => update("profileEmail", event.target.value)}/>
          </Field>
          <div className="md:col-span-2">
            <Field label="Address">
              <textarea className="min-h-24 w-full rounded-md border border-border bg-background p-3 text-sm outline-none transition focus:border-primary" value={settings.profileAddress ?? ""} onChange={(event) => update("profileAddress", event.target.value)}/>
            </Field>
          </div>
        </div>
      </section>

      <section className="rounded-lg border border-border bg-card p-5">
        <SectionTitle icon={ReceiptText} title="Receipt Settings"/>
        <div className="mt-5 grid gap-4 md:grid-cols-2">
          <Field label="Receipt prefix">
            <input className="field-input font-mono" required value={settings.receiptPrefix} onChange={(event) => update("receiptPrefix", event.target.value)}/>
          </Field>
          <Toggle label="Show logo on receipt" checked={settings.showLogoOnReceipt} onChange={(value) => update("showLogoOnReceipt", value)}/>
          <div className="md:col-span-2">
            <Field label="Receipt header">
              <input className="field-input" value={settings.receiptHeader ?? ""} onChange={(event) => update("receiptHeader", event.target.value)}/>
            </Field>
          </div>
          <div className="md:col-span-2">
            <Field label="Receipt footer">
              <input className="field-input" value={settings.receiptFooter ?? ""} onChange={(event) => update("receiptFooter", event.target.value)}/>
            </Field>
          </div>
        </div>
      </section>

      <section className="rounded-lg border border-border bg-card p-5">
        <QrPaymentBankManagementSection onNotify={setMessage}/>
      </section>

      <section className="rounded-lg border border-border bg-card p-5">
        <SectionTitle icon={MonitorPlay} title="Customer Display"/>
        <div className="mt-5 grid gap-5">
          <div>
            <div className="text-sm font-semibold">Display Template</div>
            <div className="mt-3 grid gap-3 md:grid-cols-2 xl:grid-cols-5">
              {CUSTOMER_DISPLAY_TEMPLATES.map((template) => (<button className={displaySettings.template === template.id
                ? "rounded-md border border-primary bg-primary/10 p-3 text-left text-sm shadow-sm"
                : "rounded-md border border-border bg-background p-3 text-left text-sm transition hover:border-primary"} key={template.id} type="button" onClick={() => updateDisplayTemplate(template.id)}>
                  <div className="font-semibold">{template.name}</div>
                  <div className="mt-2 text-xs leading-5 text-muted-foreground">{template.description}</div>
                  <div className="mt-3 text-xs font-semibold text-primary">
                    {displaySettings.template === template.id ? "Selected" : "Select"}
                  </div>
                </button>))}
            </div>
          </div>

          <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(320px,420px)]">
            <div className="rounded-md border border-border bg-background p-4">
              <div className="flex items-center gap-2">
                <ImagePlus className="text-primary" aria-hidden="true"/>
                <h3 className="font-semibold">Advertisement Images and Videos</h3>
              </div>
              <label className="mt-3 block">
                <input accept={t("ui.image.jpeg.image.png.image.webp.video.mp4")} className="block w-full rounded-md border border-border bg-card px-3 py-3 text-sm" type="file" onChange={updateDisplayMedia}/>
              </label>
              <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                {displaySettings.media.length === 0 ? (<div className="rounded-md border border-dashed border-border p-4 text-sm text-muted-foreground sm:col-span-2 xl:col-span-3">{t("ui.no.advertisement.media.uploaded.yet.the.disp")}</div>) : (displaySettings.media.map((media) => (<div className="overflow-hidden rounded-md border border-border bg-card" key={media.id}>
                      {media.type === "video" ? (
            // eslint-disable-next-line jsx-a11y/media-has-caption
            <video className="aspect-video w-full object-cover" src={media.url} muted/>) : (
            // eslint-disable-next-line @next/next/no-img-element
            <img className="aspect-video w-full object-cover" src={media.url} alt={media.name}/>)}
                      <div className="flex items-center justify-between gap-2 p-2">
                        <span className="truncate text-xs font-semibold">{media.name}</span>
                        <button className="grid size-8 shrink-0 place-items-center rounded-md border border-danger/40 text-danger" type="button" onClick={() => deleteDisplayMedia(media.id)} aria-label={`Delete ${media.name}`}>
                          <Trash2 className="size-4" aria-hidden="true"/>
                        </button>
                      </div>
                    </div>)))}
              </div>
            </div>

            <div className="grid gap-4 rounded-md border border-border bg-background p-4">
              <Field label="Auto return to advertising after thank-you screen">
                <input className="field-input" min="1" type="number" value={displaySettings.autoReturnSeconds} onChange={(event) => updateDisplayAutoReturn(Number(event.target.value))}/>
              </Field>
              <Field label="Promotion message">
                <div className="grid gap-2 sm:grid-cols-[minmax(0,1fr)_auto]">
                  <input className="field-input" value={promotionDraft} onChange={(event) => setPromotionDraft(event.target.value)}/>
                  <button className="h-11 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground" type="button" onClick={addPromotionMessage}>
                    Add
                  </button>
                </div>
              </Field>
              <div className="grid gap-2">
                {displaySettings.promotionMessages.map((promotion, index) => (<div className="flex items-center justify-between gap-2 rounded-md border border-border bg-card px-3 py-2 text-sm" key={`${promotion}-${index}`}>
                    <span className="min-w-0 truncate">{promotion}</span>
                    <button className="grid size-8 shrink-0 place-items-center rounded-md border border-danger/40 text-danger" type="button" onClick={() => deletePromotionMessage(index)} aria-label={`Delete promotion message ${promotion}`}>
                      <Trash2 className="size-4" aria-hidden="true"/>
                    </button>
                  </div>))}
              </div>
              <div className="rounded-md border border-primary/30 bg-primary/10 p-3 text-xs leading-5 text-primary">{t("ui.auto.switch.is.enabled.advertising.mode.chan")}</div>
            </div>
          </div>
        </div>
      </section>

      <StaffControlPermissionsSection currencySettings={<section className="rounded-lg border border-border bg-background p-4">
            <SectionTitle icon={WalletCards} title="Currency Settings"/>
            <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
              <Field label="Base currency">
                <select className="field-input" value={settings.baseCurrency} onChange={(event) => update("baseCurrency", event.target.value as CurrencyCode)}>
                  <option value="LAK">LAK</option>
                  <option value="THB">THB</option>
                  <option value="USD">USD</option>
                </select>
              </Field>
              <Field label="Currency display">
                <input className="field-input" value={settings.currencyDisplay} onChange={(event) => update("currencyDisplay", event.target.value)}/>
              </Field>
              <Field label="Decimal places">
                <input className="field-input" max="4" min="0" type="number" value={settings.decimalPlaces} onChange={(event) => update("decimalPlaces", Number(event.target.value))}/>
              </Field>
              <Field label="Rounding method">
                <select className="field-input" value={settings.roundingMethod} onChange={(event) => update("roundingMethod", event.target.value)}>
                  <option value="nearest">Nearest</option>
                  <option value="down">Down</option>
                  <option value="up">Up</option>
                </select>
              </Field>
            </div>
          </section>} loyaltyRules={<section className="rounded-lg border border-border bg-background p-4">
            <SectionTitle icon={Gift} title="Loyalty Rules"/>
            <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
              <Toggle label="Enable loyalty points" checked={settings.loyaltyEnabled} onChange={(value) => update("loyaltyEnabled", value)}/>
              <Field label="Spend LAK per point">
                <input className="field-input" min="1" type="number" value={settings.loyaltySpendPerPointLak} onChange={(event) => update("loyaltySpendPerPointLak", Number(event.target.value))}/>
              </Field>
              <Field label="Point value LAK">
                <input className="field-input" min="0" type="number" value={settings.loyaltyPointValueLak} onChange={(event) => update("loyaltyPointValueLak", Number(event.target.value))}/>
              </Field>
              <Field label="Minimum redeem points">
                <input className="field-input" min="1" type="number" value={settings.loyaltyMinRedeemPoints} onChange={(event) => update("loyaltyMinRedeemPoints", Number(event.target.value))}/>
              </Field>
            </div>
          </section>} onNotify={setMessage}/>

      <section className="rounded-lg border border-border bg-card p-5">
        <SectionTitle icon={Percent} title="Tax / VAT Settings"/>
        <div className="mt-5 grid gap-4 md:grid-cols-3">
          <Toggle label="Enable VAT" checked={settings.vatEnabled} onChange={(value) => update("vatEnabled", value)}/>
          <Toggle label="Tax inclusive pricing" checked={settings.taxInclusive} onChange={(value) => update("taxInclusive", value)}/>
          <Toggle label="Show tax on receipt" checked={settings.showTaxOnReceipt} onChange={(value) => update("showTaxOnReceipt", value)}/>
          <Field label={t("ui.vat.rate")}>
            <input className="field-input" max="100" min="0" step="0.01" type="number" value={settings.vatRate} onChange={(event) => update("vatRate", Number(event.target.value))}/>
          </Field>
        </div>
      </section>

    </form>);
}
type DynamicBankSetting = {
    id: string;
    bankName: string;
    shortCode: string;
    logoUrl?: string;
    sortOrder: number;
    active: boolean;
};
type DynamicQrAccountSetting = {
    id: string;
    bankId: string;
    accountName: string;
    accountNumber: string;
    qrImageUrl?: string;
    displayLabel: string;
    branch: string;
    isDefault: boolean;
    printOnReceipt: boolean;
    showOnCustomerDisplay: boolean;
    active: boolean;
};
const DYNAMIC_QR_BANKS_KEY = t("ui.ego.pos.dynamic.qr.banks");
const DYNAMIC_QR_ACCOUNTS_KEY = t("ui.ego.pos.dynamic.qr.accounts");
const defaultDynamicBanks: DynamicBankSetting[] = [
    { active: true, bankName: "BCEL", id: "bank-bcel", shortCode: "BCEL", sortOrder: 1 },
    { active: true, bankName: "JDB", id: "bank-jdb", shortCode: "JDB", sortOrder: 2 },
    { active: true, bankName: "LDB", id: "bank-ldb", shortCode: "LDB", sortOrder: 3 },
    { active: true, bankName: "ACLEDA", id: "bank-acleda", shortCode: "ACLEDA", sortOrder: 4 },
];
const emptyBankDraft: DynamicBankSetting = {
    active: true,
    bankName: "",
    id: "",
    shortCode: "",
    sortOrder: 1,
};
const emptyQrAccountDraft: DynamicQrAccountSetting = {
    accountName: "",
    accountNumber: "",
    active: false,
    bankId: "",
    branch: "Main Branch",
    displayLabel: "",
    id: "",
    isDefault: false,
    printOnReceipt: true,
    showOnCustomerDisplay: true,
};
function QrPaymentBankManagementSection({ onNotify }: {
    onNotify: (message: {
        tone: "error" | "success";
        text: string;
    } | null) => void;
}) {
    const [banks, setBanks] = useState<DynamicBankSetting[]>([]);
    const [qrAccounts, setQrAccounts] = useState<DynamicQrAccountSetting[]>([]);
    const [bankDraft, setBankDraft] = useState<DynamicBankSetting>(emptyBankDraft);
    const [accountDraft, setAccountDraft] = useState<DynamicQrAccountSetting>(emptyQrAccountDraft);
    const [bankModalOpen, setBankModalOpen] = useState(false);
    const [accountModalOpen, setAccountModalOpen] = useState(false);
    const [editingBankId, setEditingBankId] = useState<string | null>(null);
    const [editingAccountId, setEditingAccountId] = useState<string | null>(null);
    const [bankToDelete, setBankToDelete] = useState<DynamicBankSetting | null>(null);
    const [accountToDelete, setAccountToDelete] = useState<DynamicQrAccountSetting | null>(null);
    const [previewAccount, setPreviewAccount] = useState<DynamicQrAccountSetting | null>(null);
    useEffect(() => {
        const storedBanks = window.localStorage.getItem(DYNAMIC_QR_BANKS_KEY);
        const storedAccounts = window.localStorage.getItem(DYNAMIC_QR_ACCOUNTS_KEY);
        if (storedBanks) {
            try {
                setBanks(JSON.parse(storedBanks) as DynamicBankSetting[]);
            }
            catch {
                setBanks(defaultDynamicBanks);
            }
        }
        else {
            setBanks(defaultDynamicBanks);
            window.localStorage.setItem(DYNAMIC_QR_BANKS_KEY, JSON.stringify(defaultDynamicBanks));
        }
        if (storedAccounts) {
            try {
                setQrAccounts(JSON.parse(storedAccounts) as DynamicQrAccountSetting[]);
            }
            catch {
                setQrAccounts([]);
            }
        }
    }, []);
    const sortedBanks = [...banks].sort((first, second) => first.sortOrder - second.sortOrder || first.bankName.localeCompare(second.bankName));
    const activeBanks = sortedBanks.filter((bank) => bank.active);
    const sortedAccounts = [...qrAccounts].sort((first, second) => first.branch.localeCompare(second.branch) || Number(second.isDefault) - Number(first.isDefault));
    function persistBanks(nextBanks: DynamicBankSetting[]) {
        setBanks(nextBanks);
        window.localStorage.setItem(DYNAMIC_QR_BANKS_KEY, JSON.stringify(nextBanks));
    }
    function persistQrAccounts(nextAccounts: DynamicQrAccountSetting[]) {
        setQrAccounts(nextAccounts);
        window.localStorage.setItem(DYNAMIC_QR_ACCOUNTS_KEY, JSON.stringify(nextAccounts));
    }
    function audit(action: string) {
        onNotify({ text: `Audit log demo: ${action}.`, tone: "success" });
    }
    function readImage(event: React.ChangeEvent<HTMLInputElement>, onLoaded: (url: string) => void) {
        const file = event.target.files?.[0];
        if (!file || !["image/png", "image/jpeg", "image/webp", t("ui.image.svg.xml")].includes(file.type)) {
            onNotify({ text: t("ui.image.must.be.jpg.png.svg.or.webp"), tone: "error" });
            return;
        }
        const reader = new FileReader();
        reader.onload = () => {
            if (typeof reader.result === "string") {
                onLoaded(reader.result);
            }
        };
        reader.readAsDataURL(file);
    }
    function openAddBank() {
        setEditingBankId(null);
        setBankDraft({ ...emptyBankDraft, sortOrder: banks.length + 1 });
        setBankModalOpen(true);
    }
    function openEditBank(bank: DynamicBankSetting) {
        setEditingBankId(bank.id);
        setBankDraft(bank);
        setBankModalOpen(true);
    }
    function saveBank() {
        const bankName = bankDraft.bankName.trim();
        const shortCode = bankDraft.shortCode.trim();
        if (!bankName) {
            onNotify({ text: t("ui.bank.name.is.required"), tone: "error" });
            return;
        }
        const duplicate = banks.some((bank) => bank.id !== editingBankId && bank.bankName.toLowerCase() === bankName.toLowerCase());
        if (duplicate) {
            onNotify({ text: t("ui.bank.name.already.exists"), tone: "error" });
            return;
        }
        if (editingBankId) {
            persistBanks(banks.map((bank) => bank.id === editingBankId ? { ...bankDraft, bankName, shortCode: shortCode || bankName.slice(0, 6).toUpperCase() } : bank));
            audit(`Edit bank ${bankName}`);
        }
        else {
            persistBanks([
                ...banks,
                {
                    ...bankDraft,
                    bankName,
                    id: `bank-${Date.now()}`,
                    shortCode: shortCode || bankName.slice(0, 6).toUpperCase(),
                },
            ]);
            audit(`Add bank ${bankName}`);
        }
        setBankModalOpen(false);
    }
    function confirmDeleteBank() {
        if (!bankToDelete)
            return;
        persistBanks(banks.filter((bank) => bank.id !== bankToDelete.id));
        persistQrAccounts(qrAccounts.filter((account) => account.bankId !== bankToDelete.id));
        audit(`Delete bank ${bankToDelete.bankName}`);
        setBankToDelete(null);
    }
    function disableBank(bank: DynamicBankSetting) {
        persistBanks(banks.map((item) => item.id === bank.id ? { ...item, active: false } : item));
        audit(`Disable bank ${bank.bankName}`);
        setBankToDelete(null);
    }
    function openAddAccount() {
        setEditingAccountId(null);
        setAccountDraft({ ...emptyQrAccountDraft, bankId: activeBanks[0]?.id ?? "" });
        setAccountModalOpen(true);
    }
    function openEditAccount(account: DynamicQrAccountSetting) {
        setEditingAccountId(account.id);
        setAccountDraft(account);
        setAccountModalOpen(true);
    }
    function saveQrAccount() {
        const accountName = accountDraft.accountName.trim();
        const accountNumber = accountDraft.accountNumber.trim();
        if (!accountDraft.bankId) {
            onNotify({ text: t("ui.qr.account.must.select.a.bank"), tone: "error" });
            return;
        }
        if (!accountName) {
            onNotify({ text: t("ui.account.name.is.required"), tone: "error" });
            return;
        }
        if (!accountNumber) {
            onNotify({ text: t("ui.account.number.is.required"), tone: "error" });
            return;
        }
        if (accountDraft.active && !accountDraft.qrImageUrl) {
            onNotify({ text: t("ui.qr.image.is.required.before.activating.qr.ac"), tone: "error" });
            return;
        }
        const duplicate = qrAccounts.some((account) => (account.id !== editingAccountId &&
            account.active &&
            accountDraft.active &&
            account.bankId === accountDraft.bankId &&
            account.accountNumber.trim() === accountNumber));
        if (duplicate) {
            onNotify({ text: t("ui.active.qr.account.number.already.exists.unde"), tone: "error" });
            return;
        }
        const normalizedAccount: DynamicQrAccountSetting = {
            ...accountDraft,
            accountName,
            accountNumber,
            branch: accountDraft.branch.trim() || "Main Branch",
            displayLabel: accountDraft.displayLabel.trim() || accountName,
            id: editingAccountId ?? `qr-account-${Date.now()}`,
        };
        const withoutCurrent = qrAccounts.filter((account) => account.id !== editingAccountId);
        const nextAccounts = [...withoutCurrent, normalizedAccount].map((account) => (normalizedAccount.isDefault && account.branch === normalizedAccount.branch && account.id !== normalizedAccount.id
            ? { ...account, isDefault: false }
            : account));
        persistQrAccounts(nextAccounts);
        audit(`${editingAccountId ? "Edit" : "Add"} QR account ${normalizedAccount.displayLabel}`);
        setAccountModalOpen(false);
    }
    function confirmDeleteAccount() {
        if (!accountToDelete)
            return;
        persistQrAccounts(qrAccounts.filter((account) => account.id !== accountToDelete.id));
        audit(`Delete QR account ${accountToDelete.displayLabel}`);
        setAccountToDelete(null);
    }
    function setDefaultQrAccount(account: DynamicQrAccountSetting) {
        persistQrAccounts(qrAccounts.map((item) => (item.branch === account.branch ? { ...item, isDefault: item.id === account.id } : item)));
        audit(`Set default QR account ${account.displayLabel} for ${account.branch}`);
    }
    function bankName(bankId: string) {
        return banks.find((bank) => bank.id === bankId)?.bankName ?? "Unknown bank";
    }
    return (<div>
      <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
        <SectionTitle icon={QrCode} title="QR Payment Banks"/>
        <div className="flex flex-wrap gap-2">
          <button className="inline-flex h-10 items-center justify-center gap-2 rounded-md border border-border px-3 text-sm font-semibold transition hover:border-primary" type="button" onClick={openAddBank}>
            <Plus className="size-4" aria-hidden="true"/>
            Add Bank
          </button>
          <button className="inline-flex h-10 items-center justify-center gap-2 rounded-md bg-primary px-3 text-sm font-semibold text-primary-foreground transition hover:opacity-90" type="button" onClick={openAddAccount}>
            <Plus className="size-4" aria-hidden="true"/>
            Add QR Account
          </button>
        </div>
      </div>

      <div className="mt-5 grid gap-4 xl:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
        <section className="min-w-0 rounded-lg border border-border bg-background p-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h3 className="font-semibold">Bank Management</h3>
              <p className="mt-1 text-xs text-muted-foreground">{t("ui.banks.are.editable.examples.qr.accounts.are.")}</p>
            </div>
            <span className="rounded-full bg-primary/10 px-2 py-1 text-xs font-semibold text-primary">{banks.length} banks</span>
          </div>

          {banks.length === 0 ? (<div className="mt-4 grid min-h-32 place-items-center rounded-md border border-dashed border-border px-4 text-center text-sm text-muted-foreground">{t("ui.no.qr.payment.banks.configured.yet.add.your.")}</div>) : (<div className="mt-4 grid gap-3">
              {sortedBanks.map((bank) => (<div className="grid gap-3 rounded-md border border-border bg-card p-3 sm:grid-cols-[48px_minmax(0,1fr)_auto]" key={bank.id}>
                  <div className="grid size-12 place-items-center overflow-hidden rounded-md border border-border bg-background text-xs font-bold text-primary">
                    {bank.logoUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img className="size-full object-contain" src={bank.logoUrl} alt={`${bank.bankName} logo`}/>) : (bank.shortCode || "BANK")}
                  </div>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="truncate font-semibold">{bank.bankName}</h4>
                      <span className={bank.active ? "rounded-full bg-success/10 px-2 py-0.5 text-xs font-semibold text-success" : "rounded-full bg-muted px-2 py-0.5 text-xs font-semibold text-muted-foreground"}>
                        {bank.active ? "Active" : "Inactive"}
                      </span>
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">{t("ui.code")}{bank.shortCode || "-"}{t("ui.sort")}{bank.sortOrder}</div>
                    <div className="mt-1 text-xs text-muted-foreground">QR accounts: {qrAccounts.filter((account) => account.bankId === bank.id).length}</div>
                  </div>
                  <div className="flex items-center gap-2 sm:justify-end">
                    <button className="grid size-9 place-items-center rounded-md border border-border text-muted-foreground transition hover:border-primary hover:text-primary" type="button" onClick={() => openEditBank(bank)} aria-label={`Edit ${bank.bankName}`}>
                      <Edit3 className="size-4" aria-hidden="true"/>
                    </button>
                    <button className="grid size-9 place-items-center rounded-md border border-danger/40 text-danger transition hover:bg-danger/10" type="button" onClick={() => setBankToDelete(bank)} aria-label={`Delete ${bank.bankName}`}>
                      <Trash2 className="size-4" aria-hidden="true"/>
                    </button>
                  </div>
                </div>))}
            </div>)}
        </section>

        <section className="min-w-0 rounded-lg border border-border bg-background p-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h3 className="font-semibold">QR Account Management</h3>
              <p className="mt-1 text-xs text-muted-foreground">{t("ui.only.one.active.default.qr.account.is.allowe")}</p>
            </div>
            <span className="rounded-full bg-primary/10 px-2 py-1 text-xs font-semibold text-primary">{qrAccounts.length} accounts</span>
          </div>

          {qrAccounts.length === 0 ? (<div className="mt-4 grid min-h-32 place-items-center rounded-md border border-dashed border-border px-4 text-center text-sm text-muted-foreground">{t("ui.no.qr.accounts.configured.yet.add.an.account")}</div>) : (<div className="mt-4 grid gap-3">
              {sortedAccounts.map((account) => (<div className="rounded-md border border-border bg-card p-3" key={account.id}>
                  <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="truncate font-semibold">{account.displayLabel}</h4>
                        {account.isDefault ? <span className="rounded-full bg-primary/10 px-2 py-0.5 text-xs font-semibold text-primary">Default</span> : null}
                        <span className={account.active ? "rounded-full bg-success/10 px-2 py-0.5 text-xs font-semibold text-success" : "rounded-full bg-muted px-2 py-0.5 text-xs font-semibold text-muted-foreground"}>
                          {account.active ? "Active" : "Inactive"}
                        </span>
                      </div>
                      <div className="mt-2 grid gap-1 text-xs text-muted-foreground sm:grid-cols-2">
                        <span>{t("ui.bank")}{bankName(account.bankId)}</span>
                        <span>{t("ui.branch")}{account.branch}</span>
                        <span>{t("ui.account")}{account.accountName}</span>
                        <span>No: {account.accountNumber}</span>
                        <span>Receipt QR: {account.printOnReceipt ? "Yes" : "No"}</span>
                        <span>Customer Display: {account.showOnCustomerDisplay ? "Yes" : "No"}</span>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 lg:justify-end">
                      <button className="h-9 rounded-md border border-border px-3 text-xs font-semibold" type="button" onClick={() => setPreviewAccount(account)}>Test QR / Preview QR</button>
                      <button className="h-9 rounded-md border border-border px-3 text-xs font-semibold" type="button" onClick={() => setDefaultQrAccount(account)}>Set Default</button>
                      <button className="grid size-9 place-items-center rounded-md border border-border text-muted-foreground transition hover:border-primary hover:text-primary" type="button" onClick={() => openEditAccount(account)} aria-label={`Edit ${account.displayLabel}`}>
                        <Edit3 className="size-4" aria-hidden="true"/>
                      </button>
                      <button className="grid size-9 place-items-center rounded-md border border-danger/40 text-danger transition hover:bg-danger/10" type="button" onClick={() => setAccountToDelete(account)} aria-label={`Delete ${account.displayLabel}`}>
                        <Trash2 className="size-4" aria-hidden="true"/>
                      </button>
                    </div>
                  </div>
                </div>))}
            </div>)}
        </section>
      </div>

      <div className="mt-4 grid gap-3 lg:grid-cols-3">
        {[
            ["POS payment screen", t("ui.transfer.qr.can.load.the.branch.default.acco")],
            ["Receipts", t("ui.print.qr.on.receipt.uses.each.account.toggle")],
            ["Customer Display", t("ui.show.qr.on.customer.display.uses.each.accoun")],
        ].map(([title, detail]) => (<div className="rounded-md border border-primary/30 bg-primary/10 p-3 text-sm" key={title}>
            <div className="font-semibold text-primary">{title}</div>
            <p className="mt-1 text-xs leading-5 text-muted-foreground">{detail}</p>
          </div>))}
      </div>

      {bankModalOpen ? (<SettingsDialog title={editingBankId ? "Edit Bank" : "Add Bank"} onClose={() => setBankModalOpen(false)}>
          <div className="grid gap-3 md:grid-cols-2">
            <Field label="Bank name">
              <input className="field-input" value={bankDraft.bankName} onChange={(event) => setBankDraft((current) => ({ ...current, bankName: event.target.value }))}/>
            </Field>
            <Field label="Short code">
              <input className="field-input" value={bankDraft.shortCode} onChange={(event) => setBankDraft((current) => ({ ...current, shortCode: event.target.value.toUpperCase() }))}/>
            </Field>
            <Field label="Sort order">
              <input className="field-input" min="1" type="number" value={bankDraft.sortOrder} onChange={(event) => setBankDraft((current) => ({ ...current, sortOrder: Number(event.target.value) }))}/>
            </Field>
            <Toggle label="Active" checked={bankDraft.active} onChange={(value) => setBankDraft((current) => ({ ...current, active: value }))}/>
            <div className="md:col-span-2">
              <Field label="Bank logo">
                <input accept={t("ui.image.png.image.jpeg.image.webp.image.svg.xm")} className="block w-full rounded-md border border-border bg-card px-3 py-3 text-sm" type="file" onChange={(event) => readImage(event, (url) => setBankDraft((current) => ({ ...current, logoUrl: url })))}/>
              </Field>
            </div>
          </div>
          <DialogActions onCancel={() => setBankModalOpen(false)} onSave={saveBank} saveLabel="Save Bank"/>
        </SettingsDialog>) : null}

      {accountModalOpen ? (<SettingsDialog title={editingAccountId ? "Edit QR Account" : "Add QR Account"} onClose={() => setAccountModalOpen(false)}>
          <div className="grid gap-3 md:grid-cols-2">
            <Field label="Bank">
              <select className="field-input" value={accountDraft.bankId} onChange={(event) => setAccountDraft((current) => ({ ...current, bankId: event.target.value }))}>
                <option value="">Select bank</option>
                {activeBanks.map((bank) => <option key={bank.id} value={bank.id}>{bank.bankName}</option>)}
              </select>
            </Field>
            <Field label="Display label">
              <input className="field-input" value={accountDraft.displayLabel} onChange={(event) => setAccountDraft((current) => ({ ...current, displayLabel: event.target.value }))}/>
            </Field>
            <Field label="Account name">
              <input className="field-input" value={accountDraft.accountName} onChange={(event) => setAccountDraft((current) => ({ ...current, accountName: event.target.value }))}/>
            </Field>
            <Field label="Account number">
              <input className="field-input" value={accountDraft.accountNumber} onChange={(event) => setAccountDraft((current) => ({ ...current, accountNumber: event.target.value }))}/>
            </Field>
            <Field label="Branch">
              <input className="field-input" value={accountDraft.branch} onChange={(event) => setAccountDraft((current) => ({ ...current, branch: event.target.value }))}/>
            </Field>
            <Toggle label="Set as default account" checked={accountDraft.isDefault} onChange={(value) => setAccountDraft((current) => ({ ...current, isDefault: value }))}/>
            <Toggle label="Print QR on receipt" checked={accountDraft.printOnReceipt} onChange={(value) => setAccountDraft((current) => ({ ...current, printOnReceipt: value }))}/>
            <Toggle label="Show QR on customer display" checked={accountDraft.showOnCustomerDisplay} onChange={(value) => setAccountDraft((current) => ({ ...current, showOnCustomerDisplay: value }))}/>
            <Toggle label="Active" checked={accountDraft.active} onChange={(value) => setAccountDraft((current) => ({ ...current, active: value }))}/>
            <div className="md:col-span-2">
              <Field label="QR image">
                <input accept={t("ui.image.png.image.jpeg.image.webp.image.svg.xm")} className="block w-full rounded-md border border-border bg-card px-3 py-3 text-sm" type="file" onChange={(event) => readImage(event, (url) => setAccountDraft((current) => ({ ...current, qrImageUrl: url })))}/>
              </Field>
            </div>
          </div>
          <DialogActions onCancel={() => setAccountModalOpen(false)} onSave={saveQrAccount} saveLabel="Save QR Account"/>
        </SettingsDialog>) : null}

      {bankToDelete ? (<SettingsDialog title={t("ui.delete.bank")} onClose={() => setBankToDelete(null)}>
          <p className="text-sm text-muted-foreground">{t("ui.are.you.sure.you.want.to.delete.this.bank")}</p>
          {qrAccounts.some((account) => account.bankId === bankToDelete.id) ? (<div className="mt-3 rounded-md border border-warning/40 bg-warning/10 p-3 text-sm text-warning">{t("ui.this.bank.is.used.by.qr.payment.accounts.dis")}</div>) : null}
          <div className="mt-5 flex flex-wrap justify-end gap-2">
            <button className="h-10 rounded-md border border-border px-4 text-sm font-semibold" type="button" onClick={() => setBankToDelete(null)}>Cancel</button>
            <button className="h-10 rounded-md border border-warning/50 px-4 text-sm font-semibold text-warning" type="button" onClick={() => disableBank(bankToDelete)}>Disable instead</button>
            <button className="h-10 rounded-md bg-danger px-4 text-sm font-semibold text-white" type="button" onClick={confirmDeleteBank}>Delete</button>
          </div>
        </SettingsDialog>) : null}

      {accountToDelete ? (<SettingsDialog title={t("ui.delete.qr.account")} onClose={() => setAccountToDelete(null)}>
          <p className="text-sm text-muted-foreground">{t("ui.this.removes.the.qr.account.from.demo.settin")}</p>
          <div className="mt-5 flex justify-end gap-2">
            <button className="h-10 rounded-md border border-border px-4 text-sm font-semibold" type="button" onClick={() => setAccountToDelete(null)}>Cancel</button>
            <button className="h-10 rounded-md bg-danger px-4 text-sm font-semibold text-white" type="button" onClick={confirmDeleteAccount}>Delete</button>
          </div>
        </SettingsDialog>) : null}

      {previewAccount ? (<SettingsDialog title="QR Preview" onClose={() => setPreviewAccount(null)}>
          <div className="grid gap-4 md:grid-cols-[180px_minmax(0,1fr)]">
            <div className="grid aspect-square place-items-center overflow-hidden rounded-md border border-border bg-background">
              {previewAccount.qrImageUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img className="size-full object-contain" src={previewAccount.qrImageUrl} alt={`${previewAccount.displayLabel} QR`}/>) : (<QrCode className="size-16 text-muted-foreground" aria-hidden="true"/>)}
            </div>
            <div className="text-sm leading-7">
              <div className="font-semibold">{previewAccount.displayLabel}</div>
              <div>{t("ui.bank")}{bankName(previewAccount.bankId)}</div>
              <div>{t("ui.account")}{previewAccount.accountName}</div>
              <div>{t("ui.number")}{previewAccount.accountNumber}</div>
              <div>{t("ui.branch")}{previewAccount.branch}</div>
              <div>{t("ui.status")}{previewAccount.active ? "Active" : "Inactive"}</div>
            </div>
          </div>
          <div className="mt-5 flex justify-end">
            <button className="h-10 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground" type="button" onClick={() => setPreviewAccount(null)}>Done</button>
          </div>
        </SettingsDialog>) : null}
    </div>);
}
function SettingsDialog({ children, onClose, title }: {
    children: React.ReactNode;
    onClose: () => void;
    title: string;
}) {
    return (<div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4">
      <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-lg border border-border bg-card p-5 shadow-2xl">
        <div className="flex items-center justify-between gap-3">
          <h3 className="text-lg font-semibold">{title}</h3>
          <button className="grid size-9 place-items-center rounded-md border border-border text-muted-foreground" type="button" onClick={onClose} aria-label="Close modal">
            <X className="size-4" aria-hidden="true"/>
          </button>
        </div>
        <div className="mt-4">{children}</div>
      </div>
    </div>);
}
function DialogActions({ onCancel, onSave, saveLabel }: {
    onCancel: () => void;
    onSave: () => void;
    saveLabel: string;
}) {
    return (<div className="mt-5 flex justify-end gap-2">
      <button className="h-10 rounded-md border border-border px-4 text-sm font-semibold" type="button" onClick={onCancel}>Cancel</button>
      <button className="inline-flex h-10 items-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground" type="button" onClick={onSave}>
        <CheckCircle2 className="size-4" aria-hidden="true"/>
        {saveLabel}
      </button>
    </div>);
}
const permissionModules = [
    "Dashboard",
    "POS",
    "Inventory",
    "Purchasing",
    "Customers",
    "Membership",
    "Suppliers",
    "Promotions",
    "Reports",
    "Settings",
];
const permissionActions = ["View", "Create", "Edit", "Delete", "Approve", "Export", "Print"];
const roleTemplates = ["Owner", "Manager", "Staff/Cashier"] as const;
const posControls = ["Create sale", "Hold bill", "Resume bill", "Void bill", "Refund bill", "Apply discount", "Open cash drawer", "Cash in", "Cash out", "Split payment", "Multi-currency payment", "Manual price override", "Reprint receipt", "Delete item from bill"];
const inventoryControls = ["View stock", "Add product", "Edit product", "Delete product", "Stock adjustment", "Stock count", "Stock transfer", "Receive stock", "View cost price", "View profit margin", "Export inventory"];
const purchasingControls = ["Create purchase order", "Edit purchase order", "Cancel purchase order", "Receive goods", "Return to supplier", "Supplier payment", "View supplier debt", "Approve purchase order"];
const customerControls = ["View customer", "Add customer", "Edit customer", "Delete customer", "View customer credit", "Adjust customer points", "Create membership", "Edit membership tier", "Give manual reward", "View member purchase history"];
const promotionControls = ["Create promotion", "Edit promotion", "Delete promotion", "Activate/deactivate promotion", "Approve promotion", "View promotion impact forecast"];
const settingsControls = ["Company Profile", "Receipt Settings", "QR Payment Banks", "Customer Display", "Tax/VAT", "Currency", "Printer Settings", "Backup Settings", "Security Settings", "Staff Control"];
const approvalRules = ["Discount above allowed limit", "Refund", "Void bill", "Product price change", "Product delete", "Stock adjustment", "Promotion creation", "Purchase order above amount", "Supplier payment", "Customer credit adjustment", "Point adjustment"];
const rankingMetrics = ["Total sales amount", "Number of bills", "Average bill value", "Membership signups", "Promotion usage", "Upsell items", "Refund count", "Void count", "Discount amount"];
const staffAccessKey = t("ui.ego.pos.staff.access.users");
const staffRoleOptions = ["Owner", "Manager", "Cashier", "Custom"];
const staffStatusOptions = ["Active", "Inactive"];
const staffBranchOptions = ["Main Branch", "Branch 2", "Branch 3"];
const staffTerminalOptions = ["POS-01", "POS-02", "POS-03", "Back Office"];
type RoleTemplate = (typeof roleTemplates)[number];
type PermissionMatrix = Record<RoleTemplate, Record<string, Record<string, boolean>>>;
type StaffAccessRecord = {
    allowBackOfficeAccess: boolean;
    allowPosAccess: boolean;
    assignedTerminal: string;
    branch: string;
    fullName: string;
    id: string;
    passwordHash: string;
    passwordSalt: string;
    requirePasswordChange: boolean;
    role: string;
    status: string;
    username: string;
};
type StaffAccessDraft = Omit<StaffAccessRecord, "id" | "passwordHash" | "passwordSalt"> & {
    confirmPassword: string;
    password: string;
};
function buildDefaultPermissions(): PermissionMatrix {
    const matrix = Object.fromEntries(roleTemplates.map((role) => [
        role,
        Object.fromEntries(permissionModules.map((module) => [
            module,
            Object.fromEntries(permissionActions.map((action) => [action, role === "Owner" ? true : role === "Manager" ? module !== "Settings" && action !== "Delete" : module === "POS" && ["View", "Create", "Print"].includes(action)])),
        ])),
    ])) as PermissionMatrix;
    matrix.Manager.Reports.View = true;
    matrix.Manager.Reports.Export = false;
    matrix["Staff/Cashier"].Reports.View = true;
    return matrix;
}
function StaffControlPermissionsSection({ currencySettings, loyaltyRules, onNotify }: {
    currencySettings: React.ReactNode;
    loyaltyRules: React.ReactNode;
    onNotify: (message: {
        tone: "error" | "success";
        text: string;
    } | null) => void;
}) {
    const [role, setRole] = useState<RoleTemplate>("Manager");
    const [query, setQuery] = useState("");
    const [matrix, setMatrix] = useState<PermissionMatrix>(() => buildDefaultPermissions());
    const [managerProfit, setManagerProfit] = useState(t("ui.no.hide.profit"));
    const [refundRule, setRefundRule] = useState("Manager approval");
    const [refundThreshold, setRefundThreshold] = useState(100000);
    const [rankingEnabled, setRankingEnabled] = useState(true);
    const [rankingVisibility, setRankingVisibility] = useState("Owner and Manager can see all ranking");
    const [selectedRankingMetrics, setSelectedRankingMetrics] = useState(rankingMetrics.slice(0, 5));
    const filteredModules = permissionModules.filter((module) => module.toLowerCase().includes(query.toLowerCase()));
    function togglePermission(module: string, action: string) {
        if (role === "Owner") {
            onNotify({ text: t("ui.owner.has.full.access.and.cannot.be.restrict"), tone: "error" });
            return;
        }
        setMatrix((current) => ({
            ...current,
            [role]: {
                ...current[role],
                [module]: {
                    ...current[role][module],
                    [action]: !current[role][module][action],
                },
            },
        }));
        onNotify({ text: `Audit log demo: Owner changed ${role} ${module}.${action} permission.`, tone: "success" });
    }
    function setRolePermissions(value: boolean) {
        if (role === "Owner")
            return;
        setMatrix((current) => ({
            ...current,
            [role]: Object.fromEntries(permissionModules.map((module) => [
                module,
                Object.fromEntries(permissionActions.map((action) => [action, value])),
            ])) as PermissionMatrix[RoleTemplate],
        }));
    }
    function resetDefaults() {
        setMatrix(buildDefaultPermissions());
        onNotify({ text: t("ui.staff.permissions.reset.to.default.demo.temp"), tone: "success" });
    }
    function copyPermissions(from: RoleTemplate, to: RoleTemplate) {
        setMatrix((current) => ({ ...current, [to]: current[from] }));
        onNotify({ text: `Copied ${from} permissions to ${to}. Audit log demo recorded.`, tone: "success" });
    }
    return (<section className="rounded-lg border border-border bg-card p-5">
      <SectionTitle icon={ShieldCheck} title={t("ui.staff.control.permissions")}/>
      <div className="mt-5 grid gap-4 xl:grid-cols-[280px_minmax(0,1fr)]">
        <aside className="rounded-lg border border-border bg-background p-4">
          <h3 className="font-semibold">Role Templates</h3>
          <div className="mt-4 grid gap-2">
            {roleTemplates.map((template) => (<button className={role === template ? "rounded-md border border-primary bg-primary/10 p-3 text-left text-sm font-semibold" : "rounded-md border border-border bg-card p-3 text-left text-sm font-semibold hover:border-primary"} key={template} type="button" onClick={() => setRole(template)}>
                {template}
                <span className="mt-1 block text-xs font-normal text-muted-foreground">
                  {template === "Owner" ? t("ui.full.access.cannot.be.restricted") : template === "Manager" ? t("ui.configurable.by.owner.profit.hidden.by.defau") : t("ui.pos.only.own.sales.reports.by.default")}
                </span>
              </button>))}
          </div>
          <div className="mt-5 grid gap-2">
            <button className="h-9 rounded-md border border-border px-3 text-xs font-semibold" type="button" onClick={() => setRolePermissions(true)}>Select all</button>
            <button className="h-9 rounded-md border border-border px-3 text-xs font-semibold" type="button" onClick={() => setRolePermissions(false)}>Clear all</button>
            <button className="h-9 rounded-md border border-border px-3 text-xs font-semibold" type="button" onClick={resetDefaults}>Reset to default</button>
            <button className="h-9 rounded-md border border-border px-3 text-xs font-semibold" type="button" onClick={() => copyPermissions("Manager", "Staff/Cashier")}>Copy Manager permissions to Staff</button>
            <button className="h-9 rounded-md border border-border px-3 text-xs font-semibold" type="button" onClick={() => copyPermissions("Staff/Cashier", "Manager")}>Copy Staff permissions to Manager</button>
          </div>
          <div className="mt-4">
            <ApprovalRulesCard refundRule={refundRule} refundThreshold={refundThreshold} setRefundRule={setRefundRule} setRefundThreshold={setRefundThreshold}/>
          </div>
          <div className="mt-4">
            <StaffRankingSettingsCard rankingEnabled={rankingEnabled} rankingVisibility={rankingVisibility} selectedRankingMetrics={selectedRankingMetrics} setRankingEnabled={setRankingEnabled} setRankingVisibility={setRankingVisibility} setSelectedRankingMetrics={setSelectedRankingMetrics}/>
          </div>
          <div className="mt-4">
            <StaffActivityMonitorCard />
          </div>
        </aside>

        <div className="min-w-0">
          <StaffAccessLoginManagementCard onNotify={onNotify}/>

          <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_320px]">
            <div className="min-w-0 rounded-lg border border-border bg-background p-4">
              <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div>
                  <h3 className="font-semibold">Permission Matrix</h3>
                  <p className="mt-1 text-xs text-muted-foreground">{t("ui.every.permission.change.must.be.written.to.a")}</p>
                </div>
                <input className="field-input md:w-72" placeholder={t("ui.search.staff.permission.setting")} value={query} onChange={(event) => setQuery(event.target.value)}/>
              </div>
              <div className="mt-4 max-w-full overflow-x-auto">
                <table className="w-full min-w-[820px] text-left text-sm">
                  <thead className="border-b border-border text-xs uppercase text-muted-foreground">
                    <tr>
                      <th className="px-3 py-3">Module</th>
                      {permissionActions.map((action) => <th className="px-3 py-3 text-center" key={action}>{action}</th>)}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredModules.map((module) => (<tr className="border-b border-border last:border-b-0" key={module}>
                        <td className="px-3 py-3 font-semibold">{module}</td>
                        {permissionActions.map((action) => (<td className="px-3 py-3 text-center" key={action}>
                            <input checked={matrix[role][module][action]} className="size-4 accent-primary disabled:opacity-50" disabled={role === "Owner"} type="checkbox" onChange={() => togglePermission(module, action)}/>
                          </td>))}
                      </tr>))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="grid gap-4">
              <ControlCard icon={KeyRound} title="Manager Profit Visibility">
                <select className="field-input" value={managerProfit} onChange={(event) => setManagerProfit(event.target.value)}>
                  <option>{t("ui.yes.show.profit")}</option>
                  <option>{t("ui.no.hide.profit")}</option>
                  <option>Show sales only</option>
                </select>
                <p className="mt-2 text-xs text-muted-foreground">{t("ui.when.hidden.manager.cannot.see.cost.margin.g")}</p>
              </ControlCard>
              <ControlCard icon={ClipboardCheck} title="Price Change Rule">
                <label className="flex items-center gap-2 text-sm"><input className="size-4 accent-primary" type="checkbox" defaultChecked/>{t("ui.product.price.change.requires.owner.approval")}</label>
                <p className="mt-2 text-xs text-muted-foreground">{t("ui.manager.edits.save.as.pending.approval.and.d")}</p>
              </ControlCard>
              <ControlCard icon={Users} title="Staff Report Permission">
                <p className="text-sm leading-6 text-muted-foreground">{t("ui.staff.can.only.see.own.sales.staff.cannot.se")}</p>
              </ControlCard>
            </div>
          </div>

          <div className="mt-4 grid gap-4 xl:grid-cols-2">
            <PermissionGroup title="POS Permissions" items={posControls} extra={<NumberField label={t("ui.maximum.discount")} value={10}/>}/>
            <PermissionGroup title="Inventory Permissions" items={inventoryControls}/>
            <PermissionGroup title="Purchasing Permissions" items={purchasingControls}/>
            <PermissionGroup title={t("ui.customer.membership.permissions")} items={customerControls}/>
            <PermissionGroup title="Promotion Permissions" items={promotionControls}/>
            <PermissionGroup title="Settings Permissions" items={settingsControls} note={t("ui.staff.must.not.access.settings.by.default")}/>
          </div>
          <div className="mt-4">
            {loyaltyRules}
          </div>
          <div className="mt-4">
            {currencySettings}
          </div>

        </div>
      </div>
      <PendingApprovalCenter onNotify={onNotify}/>
    </section>);
}
function ControlCard({ children, icon: Icon, title }: {
    children: React.ReactNode;
    icon: LucideIcon;
    title: string;
}) {
    return (<section className="rounded-lg border border-border bg-background p-4">
      <div className="flex items-center gap-2">
        <Icon className="size-4 text-primary" aria-hidden="true"/>
        <h3 className="font-semibold">{title}</h3>
      </div>
      <div className="mt-3">{children}</div>
    </section>);
}
function StaffAccessLoginManagementCard({ onNotify }: {
    onNotify: (message: {
        tone: "error" | "success";
        text: string;
    } | null) => void;
}) {
    const [staff, setStaff] = useState<StaffAccessRecord[]>([]);
    const [staffQuery, setStaffQuery] = useState("");
    const [modalOpen, setModalOpen] = useState(false);
    const [editingStaffId, setEditingStaffId] = useState<string | null>(null);
    const [draft, setDraft] = useState<StaffAccessDraft>(() => buildEmptyStaffDraft());
    useEffect(() => {
        const storedStaff = window.localStorage.getItem(staffAccessKey);
        if (storedStaff) {
            try {
                setStaff(JSON.parse(storedStaff) as StaffAccessRecord[]);
                return;
            }
            catch {
                setStaff([]);
            }
        }
        void seedDemoStaff();
    }, []);
    const filteredStaff = staff.filter((member) => (member.fullName.toLowerCase().includes(staffQuery.toLowerCase()) ||
        member.username.toLowerCase().includes(staffQuery.toLowerCase()) ||
        member.role.toLowerCase().includes(staffQuery.toLowerCase()) ||
        member.branch.toLowerCase().includes(staffQuery.toLowerCase()) ||
        member.assignedTerminal.toLowerCase().includes(staffQuery.toLowerCase())));
    async function seedDemoStaff() {
        const seeded = await Promise.all([
            buildStaffRecord({ ...buildEmptyStaffDraft(), allowBackOfficeAccess: true, fullName: "Store Owner", password: "ChangeMe123!", confirmPassword: "ChangeMe123!", role: "Owner", username: "owner" }),
            buildStaffRecord({ ...buildEmptyStaffDraft(), allowBackOfficeAccess: true, fullName: "Manager", password: "ChangeMe123!", confirmPassword: "ChangeMe123!", role: "Manager", username: "manager" }),
            buildStaffRecord({ ...buildEmptyStaffDraft(), fullName: "Cashier 1", password: "ChangeMe123!", confirmPassword: "ChangeMe123!", role: "Cashier", username: "cashier1" }),
        ]);
        persistStaff(seeded);
    }
    function persistStaff(nextStaff: StaffAccessRecord[]) {
        setStaff(nextStaff);
        window.localStorage.setItem(staffAccessKey, JSON.stringify(nextStaff));
    }
    function openAddStaff() {
        setEditingStaffId(null);
        setDraft(buildEmptyStaffDraft());
        setModalOpen(true);
    }
    function openEditStaff(member: StaffAccessRecord) {
        setEditingStaffId(member.id);
        setDraft({
            allowBackOfficeAccess: member.allowBackOfficeAccess,
            allowPosAccess: member.allowPosAccess,
            assignedTerminal: member.assignedTerminal,
            branch: member.branch,
            confirmPassword: "",
            fullName: member.fullName,
            password: "",
            requirePasswordChange: member.requirePasswordChange,
            role: member.role,
            status: member.status,
            username: member.username,
        });
        setModalOpen(true);
    }
    async function saveStaff() {
        const fullName = draft.fullName.trim();
        const username = draft.username.trim();
        if (!fullName || !username) {
            onNotify({ text: t("ui.full.name.and.username.are.required"), tone: "error" });
            return;
        }
        if (staff.some((member) => member.id !== editingStaffId && member.username.toLowerCase() === username.toLowerCase())) {
            onNotify({ text: t("ui.username.already.exists"), tone: "error" });
            return;
        }
        if (!editingStaffId && !draft.password) {
            onNotify({ text: t("ui.password.is.required.for.new.staff.login"), tone: "error" });
            return;
        }
        if (draft.password || draft.confirmPassword) {
            if (draft.password.length < 8) {
                onNotify({ text: t("ui.password.must.be.at.least.8.characters"), tone: "error" });
                return;
            }
            if (draft.password !== draft.confirmPassword) {
                onNotify({ text: t("ui.password.and.confirm.password.must.match"), tone: "error" });
                return;
            }
        }
        const existing = staff.find((member) => member.id === editingStaffId);
        const nextRecord = draft.password
            ? await buildStaffRecord({ ...draft, fullName, username })
            : existing
                ? {
                    ...existing,
                    allowBackOfficeAccess: draft.allowBackOfficeAccess,
                    allowPosAccess: draft.allowPosAccess,
                    assignedTerminal: draft.assignedTerminal,
                    branch: draft.branch,
                    fullName,
                    requirePasswordChange: draft.requirePasswordChange,
                    role: draft.role,
                    status: draft.status,
                    username,
                }
                : await buildStaffRecord({ ...draft, fullName, username });
        persistStaff(editingStaffId ? staff.map((member) => member.id === editingStaffId ? nextRecord : member) : [...staff, nextRecord]);
        onNotify({ text: `Audit log demo: ${editingStaffId ? "Edited" : "Created"} staff login ${username}.`, tone: "success" });
        setModalOpen(false);
    }
    function disableStaff(member: StaffAccessRecord) {
        persistStaff(staff.map((item) => item.id === member.id ? { ...item, status: "Inactive" } : item));
        onNotify({ text: `Audit log demo: Disabled staff login ${member.username}.`, tone: "success" });
    }
    return (<section className="mb-4 rounded-lg border border-border bg-background p-4">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <KeyRound className="size-4 text-primary" aria-hidden="true"/>
            <h3 className="font-semibold">{t("ui.staff.access.login.management")}</h3>
          </div>
          <p className="mt-1 text-xs leading-5 text-muted-foreground">{t("ui.manager.cashier.and.owner.username.password.")}</p>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <input className="field-input h-10 sm:w-64" placeholder={t("ui.search.staff")} value={staffQuery} onChange={(event) => setStaffQuery(event.target.value)}/>
          <button className="inline-flex h-10 items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground" type="button" onClick={openAddStaff}>
            <Plus className="size-4" aria-hidden="true"/>
            Add Staff
          </button>
        </div>
      </div>

      <div className="mt-4 max-w-full overflow-x-auto">
        <table className="w-full min-w-[920px] text-left text-sm">
          <thead className="border-b border-border text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-3 py-3">Staff</th>
              <th className="px-3 py-3">Username</th>
              <th className="px-3 py-3">Role</th>
              <th className="px-3 py-3">Branch</th>
              <th className="px-3 py-3">Terminal</th>
              <th className="px-3 py-3">Access</th>
              <th className="px-3 py-3">Status</th>
              <th className="px-3 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredStaff.map((member) => (<tr className="border-b border-border last:border-b-0" key={member.id}>
                <td className="px-3 py-3 font-semibold">{member.fullName}</td>
                <td className="px-3 py-3 font-mono text-xs">{member.username}</td>
                <td className="px-3 py-3">{member.role}</td>
                <td className="px-3 py-3">{member.branch}</td>
                <td className="px-3 py-3">{member.assignedTerminal}</td>
                <td className="px-3 py-3 text-xs">
                  <span className={member.allowPosAccess ? "mr-1 rounded-full bg-success/10 px-2 py-1 text-success" : "mr-1 rounded-full bg-muted px-2 py-1 text-muted-foreground"}>POS</span>
                  <span className={member.allowBackOfficeAccess ? "rounded-full bg-primary/10 px-2 py-1 text-primary" : "rounded-full bg-muted px-2 py-1 text-muted-foreground"}>Back Office</span>
                </td>
                <td className="px-3 py-3">
                  <span className={member.status === "Active" ? "rounded-full bg-success/10 px-2 py-1 text-xs font-semibold text-success" : "rounded-full bg-danger/10 px-2 py-1 text-xs font-semibold text-danger"}>
                    {member.status}
                  </span>
                </td>
                <td className="px-3 py-3">
                  <div className="flex flex-wrap gap-2">
                    <button className="h-8 rounded-md border border-border px-3 text-xs font-semibold" type="button" onClick={() => openEditStaff(member)}>Edit</button>
                    <button className="h-8 rounded-md border border-border px-3 text-xs font-semibold" type="button" onClick={() => openEditStaff(member)}>Reset Password</button>
                    <button className="h-8 rounded-md border border-danger/40 px-3 text-xs font-semibold text-danger" type="button" onClick={() => disableStaff(member)}>Disable</button>
                  </div>
                </td>
              </tr>))}
          </tbody>
        </table>
      </div>

      <div className="mt-4 grid gap-3 lg:grid-cols-3">
        {[
            ["Login rules", t("ui.disabled.staff.inactive.roles.or.wrong.passw")],
            ["Permission loading", t("ui.successful.login.loads.role.permission.repor")],
            ["Activity tracking", t("ui.login.logout.bills.discounts.refunds.voids.c")],
        ].map(([title, detail]) => (<div className="rounded-md border border-primary/30 bg-primary/10 p-3 text-xs leading-5" key={title}>
            <div className="font-semibold text-primary">{title}</div>
            <p className="mt-1 text-muted-foreground">{detail}</p>
          </div>))}
      </div>

      {modalOpen ? (<SettingsDialog title={editingStaffId ? "Edit Staff Login" : "Add Staff Login"} onClose={() => setModalOpen(false)}>
          <div className="grid gap-3 md:grid-cols-2">
            <Field label="Full name">
              <input className="field-input" value={draft.fullName} onChange={(event) => setDraft((current) => ({ ...current, fullName: event.target.value }))}/>
            </Field>
            <Field label="Username">
              <input className="field-input" value={draft.username} onChange={(event) => setDraft((current) => ({ ...current, username: event.target.value }))}/>
            </Field>
            <Field label={editingStaffId ? t("ui.new.password.optional") : "Password"}>
              <input className="field-input" type="password" value={draft.password} onChange={(event) => setDraft((current) => ({ ...current, password: event.target.value }))}/>
            </Field>
            <Field label="Confirm password">
              <input className="field-input" type="password" value={draft.confirmPassword} onChange={(event) => setDraft((current) => ({ ...current, confirmPassword: event.target.value }))}/>
            </Field>
            <Field label="Role">
              <select className="field-input" value={draft.role} onChange={(event) => setDraft((current) => ({ ...current, role: event.target.value }))}>
                {staffRoleOptions.map((option) => <option key={option}>{option}</option>)}
              </select>
            </Field>
            <Field label="Branch">
              <select className="field-input" value={draft.branch} onChange={(event) => setDraft((current) => ({ ...current, branch: event.target.value }))}>
                {staffBranchOptions.map((option) => <option key={option}>{option}</option>)}
              </select>
            </Field>
            <Field label="Assigned POS terminal">
              <select className="field-input" value={draft.assignedTerminal} onChange={(event) => setDraft((current) => ({ ...current, assignedTerminal: event.target.value }))}>
                {staffTerminalOptions.map((option) => <option key={option}>{option}</option>)}
              </select>
            </Field>
            <Field label="Status">
              <select className="field-input" value={draft.status} onChange={(event) => setDraft((current) => ({ ...current, status: event.target.value }))}>
                {staffStatusOptions.map((option) => <option key={option}>{option}</option>)}
              </select>
            </Field>
            <Toggle label="Require password change on first login" checked={draft.requirePasswordChange} onChange={(value) => setDraft((current) => ({ ...current, requirePasswordChange: value }))}/>
            <Toggle label="Allow Back Office access" checked={draft.allowBackOfficeAccess} onChange={(value) => setDraft((current) => ({ ...current, allowBackOfficeAccess: value }))}/>
            <Toggle label="Allow POS access" checked={draft.allowPosAccess} onChange={(value) => setDraft((current) => ({ ...current, allowPosAccess: value }))}/>
          </div>
          <div className="mt-4 rounded-md border border-warning/40 bg-warning/10 p-3 text-xs leading-5 text-warning">{t("ui.passwords.are.hashed.for.demo.storage.produc")}</div>
          <DialogActions onCancel={() => setModalOpen(false)} onSave={() => void saveStaff()} saveLabel={editingStaffId ? "Save Staff" : "Add Staff"}/>
        </SettingsDialog>) : null}
    </section>);
}
function buildEmptyStaffDraft(): StaffAccessDraft {
    return {
        allowBackOfficeAccess: false,
        allowPosAccess: true,
        assignedTerminal: "POS-01",
        branch: "Main Branch",
        confirmPassword: "",
        fullName: "",
        password: "",
        requirePasswordChange: true,
        role: "Cashier",
        status: "Active",
        username: "",
    };
}
async function buildStaffRecord(draft: StaffAccessDraft): Promise<StaffAccessRecord> {
    const passwordSalt = crypto.randomUUID();
    const passwordHash = await hashStaffPassword(draft.password, passwordSalt);
    return {
        allowBackOfficeAccess: draft.allowBackOfficeAccess,
        allowPosAccess: draft.allowPosAccess,
        assignedTerminal: draft.assignedTerminal,
        branch: draft.branch,
        fullName: draft.fullName,
        id: `staff-${Date.now()}-${Math.random().toString(16).slice(2)}`,
        passwordHash,
        passwordSalt,
        requirePasswordChange: draft.requirePasswordChange,
        role: draft.role,
        status: draft.status,
        username: draft.username,
    };
}
async function hashStaffPassword(password: string, salt: string) {
    const bytes = new TextEncoder().encode(`${salt}:${password}`);
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
function ApprovalRulesCard({ refundRule, refundThreshold, setRefundRule, setRefundThreshold, }: {
    refundRule: string;
    refundThreshold: number;
    setRefundRule: (value: string) => void;
    setRefundThreshold: (value: number) => void;
}) {
    return (<section className="rounded-lg border border-border bg-card p-3">
      <h3 className="font-semibold">Approval Rules</h3>
      <p className="mt-1 text-xs leading-5 text-muted-foreground">{t("ui.owner.approval.rules.for.sensitive.actions")}</p>
      <div className="mt-3 grid max-h-[560px] gap-2 overflow-y-auto pr-1">
        {approvalRules.map((rule, index) => (<div className="grid gap-2 rounded-md border border-border bg-background p-2" key={rule}>
            <span className="text-xs font-semibold leading-5">{rule}</span>
            <select className="field-input h-9 text-xs" defaultValue={index % 3 === 0 ? "Owner approval" : index % 3 === 1 ? "Manager approval" : "Custom amount threshold"}>
              <option>Disabled</option>
              <option>Manager approval</option>
              <option>Owner approval</option>
              <option>Custom amount threshold</option>
            </select>
            <input className="field-input h-9 text-xs" type="number" defaultValue={index === 1 ? refundThreshold : 100000} onChange={(event) => setRefundThreshold(Number(event.target.value))}/>
          </div>))}
      </div>
      <div className="mt-3 rounded-md border border-primary/30 bg-primary/10 p-3 text-xs leading-5 text-primary">
        Refund rule: {refundRule}. Under {refundThreshold.toLocaleString()}{t("ui.lak.can.use.manager.approval.above.requires.")}</div>
      <select className="field-input mt-3 h-9 text-xs" value={refundRule} onChange={(event) => setRefundRule(event.target.value)}>
        <option>No access</option>
        <option>Manager approval</option>
        <option>Owner approval</option>
        <option>Custom by amount</option>
      </select>
    </section>);
}
function StaffRankingSettingsCard({ rankingEnabled, rankingVisibility, selectedRankingMetrics, setRankingEnabled, setRankingVisibility, setSelectedRankingMetrics, }: {
    rankingEnabled: boolean;
    rankingVisibility: string;
    selectedRankingMetrics: string[];
    setRankingEnabled: (value: boolean) => void;
    setRankingVisibility: (value: string) => void;
    setSelectedRankingMetrics: React.Dispatch<React.SetStateAction<string[]>>;
}) {
    return (<section className="rounded-lg border border-border bg-card p-3">
      <h3 className="font-semibold">Staff Ranking Settings</h3>
      <div className="mt-3 grid gap-3">
        <label className="flex items-center justify-between rounded-md border border-border bg-background p-3 text-sm font-medium">
          Enable ranking
          <input className="size-4 accent-primary" checked={rankingEnabled} type="checkbox" onChange={(event) => setRankingEnabled(event.target.checked)}/>
        </label>
        <select className="field-input text-xs" value={rankingVisibility} onChange={(event) => setRankingVisibility(event.target.value)}>
          <option>Owner and Manager can see all ranking</option>
          <option>Owner only</option>
          <option>Manager only</option>
          <option>Staff can see own ranking</option>
          <option>Staff can see all ranking</option>
        </select>
        <div className="grid gap-2">
          {rankingMetrics.map((metric) => (<label className="flex items-center gap-2 rounded-md border border-border bg-background p-2 text-xs" key={metric}>
              <input className="size-4 shrink-0 accent-primary" checked={selectedRankingMetrics.includes(metric)} type="checkbox" onChange={() => setSelectedRankingMetrics((current) => current.includes(metric) ? current.filter((item) => item !== metric) : [...current, metric])}/>
              <span className="leading-5">{metric}</span>
            </label>))}
        </div>
      </div>
    </section>);
}
function StaffActivityMonitorCard() {
    return (<section className="rounded-lg border border-border bg-card p-3">
      <h3 className="font-semibold">Staff Activity Monitor</h3>
      <div className="mt-3 grid gap-2">
        {["Login time", "Logout time", "Bills created", "Sales amount", "Discounts given", "Refunds", "Voids", "Cash in/out", "Stock adjustments", "Price change requests"].map((item) => (<div className="rounded-md border border-border bg-background p-2 text-xs leading-5" key={item}>{item}</div>))}
      </div>
    </section>);
}
function PendingApprovalCenter({ onNotify }: {
    onNotify: (message: {
        tone: "error" | "success";
        text: string;
    } | null) => void;
}) {
    return (<section className="mt-4 rounded-lg border border-border bg-background p-4">
      <h3 className="font-semibold">Pending Approval Center</h3>
      <div className="mt-4 max-w-full overflow-x-auto">
        <table className="w-full min-w-[760px] text-left text-sm">
          <thead className="border-b border-border text-xs uppercase text-muted-foreground">
            <tr><th className="px-3 py-3">Request</th><th className="px-3 py-3">By</th><th className="px-3 py-3">Old</th><th className="px-3 py-3">New</th><th className="px-3 py-3">Reason</th><th className="px-3 py-3">Action</th></tr>
          </thead>
          <tbody>
            {[
            ["Product price change", "Manager", "8,000", "8,500", "Supplier cost increased"],
            ["Refund bill", "Cashier 1", "0", "85,000", "Customer returned item"],
            ["Stock adjustment", "Manager", "126", "120", "Count correction"],
        ].map((row) => (<tr className="border-b border-border last:border-b-0" key={row[0]}>
                {row.map((cell) => <td className="px-3 py-3" key={cell}>{cell}</td>)}
                <td className="px-3 py-3">
                  <button className="mr-2 h-8 rounded-md bg-success px-3 text-xs font-semibold text-white" type="button" onClick={() => onNotify({ text: t("ui.approval.request.approved.in.demo.mode"), tone: "success" })}>Approve</button>
                  <button className="h-8 rounded-md border border-danger/40 px-3 text-xs font-semibold text-danger" type="button" onClick={() => onNotify({ text: t("ui.approval.request.rejected.in.demo.mode"), tone: "success" })}>Reject</button>
                </td>
              </tr>))}
          </tbody>
        </table>
      </div>
    </section>);
}
function PermissionGroup({ extra, items, note, title }: {
    extra?: React.ReactNode;
    items: string[];
    note?: string;
    title: string;
}) {
    return (<section className="rounded-lg border border-border bg-background p-4">
      <h3 className="font-semibold">{title}</h3>
      {note ? <p className="mt-1 text-xs text-muted-foreground">{note}</p> : null}
      <div className="mt-4 grid gap-2 sm:grid-cols-2">
        {items.map((item) => <label className="flex items-center gap-2 rounded-md border border-border bg-card p-2 text-sm" key={item}><input className="size-4 accent-primary" defaultChecked={title.includes("POS") && !item.includes("Refund") && !item.includes("Manual")} type="checkbox"/>{item}</label>)}
      </div>
      {extra ? <div className="mt-4">{extra}</div> : null}
    </section>);
}
function NumberField({ label, value }: {
    label: string;
    value: number;
}) {
    return <Field label={label}><input className="field-input" min="0" type="number" defaultValue={value}/></Field>;
}
function SectionTitle({ icon: Icon, title }: {
    icon: LucideIcon;
    title: string;
}) {
    return (<div className="flex items-center gap-3">
      <div className="grid size-10 place-items-center rounded-md bg-primary/10 text-primary">
        <Icon aria-hidden="true"/>
      </div>
      <h2 className="text-lg font-semibold">{title}</h2>
    </div>);
}
function Field({ children, label }: {
    children: React.ReactNode;
    label: string;
}) {
    return (<label className="flex flex-col gap-2 text-sm font-medium">
      {label}
      {children}
    </label>);
}
function Toggle({ checked, label, onChange }: {
    checked: boolean;
    label: string;
    onChange: (value: boolean) => void;
}) {
    return (<label className="flex min-h-11 items-center justify-between gap-3 rounded-md border border-border bg-background px-3 text-sm font-medium">
      <span>{label}</span>
      <input checked={checked} className="size-4 accent-primary" type="checkbox" onChange={(event) => onChange(event.target.checked)}/>
    </label>);
}
