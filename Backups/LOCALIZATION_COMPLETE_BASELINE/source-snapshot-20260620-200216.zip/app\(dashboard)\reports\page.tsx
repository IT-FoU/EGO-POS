import { ReportsAnalyticsClient } from "@/features/reports/components/reports-analytics-client";

export default function ReportsPage() {
  return <ReportsAnalyticsClient />;
}
