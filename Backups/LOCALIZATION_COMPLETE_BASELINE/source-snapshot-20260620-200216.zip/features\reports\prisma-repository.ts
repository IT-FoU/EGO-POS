import { prisma } from "@/lib/db/prisma";
import { getPrismaCustomersSnapshot } from "@/features/customers/prisma-repository";
import { getPrismaInventorySnapshot } from "@/features/inventory/prisma-repository";
import { getPrismaProducts } from "@/features/products/prisma-repository";
import { getPrismaSuppliersSnapshot } from "@/features/suppliers/prisma-repository";
import { buildReportAnalytics } from "@/features/reports/dto-mapper";
import type { TenantContext } from "@/lib/db/write-context";
import { resolveTenantScope } from "@/lib/db/tenant-scope";
import type { Product } from "@/features/products/types";
import type { Supplier } from "@/features/suppliers/types";
import type { ProductReportRow, PurchaseTrendPoint, SalesMetric, TrendPoint } from "@/features/reports/types";

const db = prisma as any;

export async function getPrismaReportsSnapshot(tenant: TenantContext) {
  const scope = await resolveTenantScope(tenant);
  const [
    sales,
    salesAggregate,
    salesByPeriod,
    productGroups,
    purchasesBySupplier,
    purchasesByPeriod,
    customers,
    inventory,
    products,
    suppliers,
  ] = await Promise.all([
    db.sale.findMany({
      orderBy: { createdAt: "desc" },
      where: { branchId: scope.branchId, companyId: scope.companyId },
    }),
    db.sale.aggregate({
      _count: { id: true },
      _sum: { profitAmount: true, taxAmount: true, totalAmount: true },
      where: { branchId: scope.branchId, companyId: scope.companyId },
    }),
    db.sale.findMany({
      orderBy: { createdAt: "asc" },
      select: { createdAt: true, profitAmount: true, taxAmount: true, totalAmount: true },
      where: { branchId: scope.branchId, companyId: scope.companyId },
    }),
    db.saleItem.groupBy({
      by: ["productId"],
      _sum: { profitAmount: true, quantity: true, totalAmount: true },
      orderBy: { _sum: { totalAmount: "desc" } },
      take: 20,
      where: { sale: { branchId: scope.branchId, companyId: scope.companyId } },
    }),
    db.purchase.groupBy({
      by: ["supplierId"],
      _sum: { totalAmount: true },
      _count: { id: true },
      orderBy: { _sum: { totalAmount: "desc" } },
      where: { companyId: scope.companyId, warehouseId: { in: scope.warehouseIds } },
    }),
    db.purchase.findMany({
      orderBy: { purchaseDate: "asc" },
      select: { purchaseDate: true, totalAmount: true },
      where: { companyId: scope.companyId, warehouseId: { in: scope.warehouseIds } },
    }),
    getPrismaCustomersSnapshot(scope),
    getPrismaInventorySnapshot(scope),
    getPrismaProducts(scope),
    getPrismaSuppliersSnapshot(scope),
  ]);
  const totalRevenue = Number(salesAggregate._sum.totalAmount ?? 0);
  const productById = new Map<string, Product>(products.map((product: Product) => [product.id, product]));
  const supplierById = new Map<string, Supplier>(suppliers.suppliers.map((supplier: Supplier) => [supplier.id, supplier]));
  const salesMetrics = buildSalesMetrics(salesByPeriod);
  const revenueTrend = buildRevenueTrend(salesByPeriod);
  const productRows: ProductReportRow[] = productGroups.map((row: Record<string, any>) => {
    const product = productById.get(row.productId);
    return {
      categoryName: product?.categoryName ?? "Uncategorized",
      productName: product?.nameEn || product?.nameLo || row.productId,
      profitLak: Number(row._sum.profitAmount ?? 0),
      quantitySold: Number(row._sum.quantity ?? 0),
      revenueLak: Number(row._sum.totalAmount ?? 0),
    };
  });
  const purchaseTrend = buildPurchaseTrend(purchasesByPeriod);
  const purchaseOrders = purchasesBySupplier.map((row: Record<string, any>) => ({
    id: `supplier-${row.supplierId}`,
    purchaseDate: "",
    purchaseNo: "",
    status: "received" as const,
    supplierId: row.supplierId,
    totalLak: Number(row._sum.totalAmount ?? 0),
    warehouseName: supplierById.get(row.supplierId)?.companyName ?? row.supplierId,
  }));

  return {
    analytics: buildReportAnalytics({
      customerCount: customers.customers.length,
      revenueLak: totalRevenue,
      transactionCount: salesAggregate._count.id ?? sales.length,
    }),
    customers: customers.customers,
    inventoryItems: inventory.items,
    productRows,
    products,
    purchaseTrend,
    revenueTrend,
    salesMetrics,
    supplierPayments: suppliers.payments,
    supplierPurchaseOrders: [...purchaseOrders, ...suppliers.purchaseOrders],
    suppliers: suppliers.suppliers,
  };
}

function monthLabel(value: Date) {
  return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, "0")}`;
}

function buildRevenueTrend(rows: Array<Record<string, any>>): TrendPoint[] {
  const totals = new Map<string, { revenueLak: number; salesCount: number }>();
  for (const row of rows) {
    const label = monthLabel(row.createdAt);
    const current = totals.get(label) ?? { revenueLak: 0, salesCount: 0 };
    current.revenueLak += Number(row.totalAmount ?? 0);
    current.salesCount += 1;
    totals.set(label, current);
  }

  return Array.from(totals, ([label, value]) => ({ label, ...value }));
}

function buildSalesMetrics(rows: Array<Record<string, any>>): SalesMetric[] {
  const revenue = rows.reduce((total, row) => total + Number(row.totalAmount ?? 0), 0);
  const profit = rows.reduce((total, row) => total + Number(row.profitAmount ?? 0), 0);
  const tax = rows.reduce((total, row) => total + Number(row.taxAmount ?? 0), 0);

  return [
    { label: "All time", period: "yearly", profitLak: profit, revenueLak: revenue, taxLak: tax, transactions: rows.length },
  ];
}

function buildPurchaseTrend(rows: Array<Record<string, any>>): PurchaseTrendPoint[] {
  const totals = new Map<string, { orderCount: number; purchaseValueLak: number }>();
  for (const row of rows) {
    const label = monthLabel(row.purchaseDate);
    const current = totals.get(label) ?? { orderCount: 0, purchaseValueLak: 0 };
    current.orderCount += 1;
    current.purchaseValueLak += Number(row.totalAmount ?? 0);
    totals.set(label, current);
  }

  return Array.from(totals, ([label, value]) => ({ label, ...value }));
}
