import { notFound } from "next/navigation";
import { PromotionForm } from "@/features/promotions/components/promotion-form";
import { getPromotionDetail, getPromotions } from "@/features/promotions/promotion-service";

export async function generateStaticParams() {
  const promotions = await getPromotions();

  return promotions.map((promotion) => ({
    id: promotion.id,
  }));
}

export default async function EditPromotionPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const { categories, membershipLevels, products, promotion } = await getPromotionDetail(id);

  if (!promotion) {
    notFound();
  }

  return (
    <PromotionForm
      categories={categories}
      initialPromotion={promotion}
      membershipLevels={membershipLevels}
      products={products}
    />
  );
}
