import { getPrismaSettings } from "@/features/settings/prisma-repository";
import { SettingsForm } from "@/features/settings/components/settings-form";
import { requireSession } from "@/lib/auth/session";
import { tenantFromSession } from "@/lib/db/write-context";

export default async function SettingsPage() {
  const session = await requireSession();
  const settings = await getPrismaSettings(tenantFromSession(session));

  return <SettingsForm initialSettings={settings} />;
}
