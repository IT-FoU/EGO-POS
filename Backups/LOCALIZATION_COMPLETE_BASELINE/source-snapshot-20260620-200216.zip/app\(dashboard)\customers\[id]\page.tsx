import { notFound } from "next/navigation";
import { CustomerDetailClient } from "@/features/customers/components/customer-detail-client";
import { getCustomerDetail, getCustomers } from "@/features/customers/customer-service";

export async function generateStaticParams() {
  const customers = await getCustomers();

  return customers.map((customer) => ({
    id: customer.id,
  }));
}

export default async function CustomerDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const { customer, payments, purchases } = await getCustomerDetail(id);

  if (!customer) {
    notFound();
  }

  return (
    <CustomerDetailClient
      customer={customer}
      payments={payments}
      purchases={purchases}
    />
  );
}
