import { mockCustomers } from "@/features/customers/mock-data";
import type { Customer } from "@/features/customers/types";
import { mockInventoryItems } from "@/features/inventory/mock-data";
import type { InventoryItem } from "@/features/inventory/types";
import { mockProducts } from "@/features/products/mock-data";
import type { Product } from "@/features/products/types";
import {
  mockSupplierPayments,
  mockSupplierPurchaseOrders,
  mockSuppliers,
} from "@/features/suppliers/mock-data";
import type { Supplier, SupplierPayment, SupplierPurchaseOrder } from "@/features/suppliers/types";
import {
  mockProductReportRows,
  mockPurchaseTrend,
  mockRevenueTrend,
  mockSalesMetrics,
} from "@/features/reports/mock-data";
import type { ProductReportRow, PurchaseTrendPoint, SalesMetric, TrendPoint } from "@/features/reports/types";
import { isDemoMode } from "@/lib/demo-mode";
import { requireSession } from "@/lib/auth/session";
import { tenantFromSession } from "@/lib/db/write-context";
import { getPrismaReportsSnapshot } from "@/features/reports/prisma-repository";

export type ReportsSnapshot = {
  analytics: {
    categoryBreakdown: Array<{ label: string; value: number }>;
    totalCustomers: number;
    totalProfit: number;
    totalRevenue: number;
    totalTransactions: number;
  };
  customers: Customer[];
  inventoryItems: InventoryItem[];
  products: Product[];
  productRows: ProductReportRow[];
  purchaseTrend: PurchaseTrendPoint[];
  revenueTrend: TrendPoint[];
  salesMetrics: SalesMetric[];
  supplierPayments: SupplierPayment[];
  supplierPurchaseOrders: SupplierPurchaseOrder[];
  suppliers: Supplier[];
};

export async function getReportsSnapshot(): Promise<ReportsSnapshot> {
  if (!isDemoMode()) {
    return getPrismaReportsSnapshot(tenantFromSession(await requireSession()));
  }

  const totalRevenue = mockSalesMetrics.find((metric) => metric.period === "monthly")?.revenueLak ?? 0;
  const totalProfit = mockSalesMetrics.find((metric) => metric.period === "monthly")?.profitLak ?? 0;
  const totalTransactions = mockSalesMetrics.find((metric) => metric.period === "monthly")?.transactions ?? 0;
  const categoryBreakdown = mockProductReportRows.reduce<Record<string, number>>(
    (totals, row) => ({
      ...totals,
      [row.categoryName]: (totals[row.categoryName] ?? 0) + row.revenueLak,
    }),
    {},
  );

  return {
    analytics: {
      categoryBreakdown: Object.entries(categoryBreakdown).map(([label, value]) => ({
        label,
        value,
      })),
      totalCustomers: mockCustomers.length,
      totalProfit,
      totalRevenue,
      totalTransactions,
    },
    customers: mockCustomers,
    inventoryItems: mockInventoryItems,
    products: mockProducts,
    productRows: mockProductReportRows,
    purchaseTrend: mockPurchaseTrend,
    revenueTrend: mockRevenueTrend,
    salesMetrics: mockSalesMetrics,
    supplierPayments: mockSupplierPayments,
    supplierPurchaseOrders: mockSupplierPurchaseOrders,
    suppliers: mockSuppliers,
  };
}
