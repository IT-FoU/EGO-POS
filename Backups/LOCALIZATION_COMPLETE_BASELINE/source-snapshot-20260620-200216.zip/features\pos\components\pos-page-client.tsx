"use client";

import { t } from "@/lib/i18n/ui";
import { useEffect, useMemo, useState, useTransition } from "react";
import { BadgePercent, Banknote, Barcode, CalendarDays, ChevronDown, ChevronUp, CreditCard, GraduationCap, Minus, Plus, Printer, QrCode, ReceiptText, RotateCcw, Search, ShoppingCart, Trash2, UserRoundSearch, WalletCards, X, } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { HeldSale, PaymentMode, PosCartItem, PosCustomer, PosDisplayState, PosProduct, PosProductUnit, QrBank, } from "@/features/pos/types";
import { PosProductImage } from "@/features/pos/components/pos-product-image";
import { formatLak } from "@/features/pos/format";
import { cn } from "@/lib/utils";
import { completeSaleAction } from "@/features/pos/actions";
import { readCustomerDisplaySettingsFromStorage } from "@/features/pos/customer-display-settings";
const POS_DISPLAY_KEY = t("ui.ego.pos.customer.display.state");
const QR_BANKS_KEY = t("ui.ego.pos.qr.banks");
const OPENING_CASH_DENOMINATIONS = [50000, 20000, 10000, 5000, 2000, 1000, 500] as const;
const HYDRATION_SAFE_TIME = "--:--";
const HYDRATION_SAFE_BUSINESS_DATE = "--";
const HYDRATION_SAFE_REFERENCE_DATE = new Date("2026-06-20T00:00:00");
export function PosPageClient({ branchName, branchId, cashierName, customers, products, promotionBanners, qrBanks, taxInclusive, taxRatePercent, warehouseId, }: {
    branchId: string;
    branchName: string;
    cashierName: string;
    customers: PosCustomer[];
    products: PosProduct[];
    promotionBanners: string[];
    qrBanks: QrBank[];
    taxInclusive: boolean;
    taxRatePercent: number;
    warehouseId: string;
}) {
    const [isPending, startTransition] = useTransition();
    const [barcodeQuery, setBarcodeQuery] = useState("");
    const [productQuery, setProductQuery] = useState("");
    const [membershipQuery, setMembershipQuery] = useState("");
    const [selectedCategory, setSelectedCategory] = useState("All");
    const [cartItems, setCartItems] = useState<PosCartItem[]>([]);
    const [unitSelectionProduct, setUnitSelectionProduct] = useState<PosProduct | null>(null);
    const [selectedCustomer, setSelectedCustomer] = useState<PosCustomer | null>(null);
    const [discountAmount, setDiscountAmount] = useState(0);
    const [discountPercent, setDiscountPercent] = useState(0);
    const [taxEnabled, setTaxEnabled] = useState(true);
    const [paymentMode, setPaymentMode] = useState<PaymentMode>("cash");
    const [cashAmount, setCashAmount] = useState(0);
    const [qrAmount, setQrAmount] = useState(0);
    const [transferAmount, setTransferAmount] = useState(0);
    const [cardAmount, setCardAmount] = useState(0);
    const [heldSales, setHeldSales] = useState<HeldSale[]>([]);
    const [selectedHeldSaleId, setSelectedHeldSaleId] = useState("");
    const [selectedStaffName, setSelectedStaffName] = useState(cashierName || "Current User");
    const [staffStatus, setStaffStatus] = useState("Not Started");
    const [staffControlExpanded, setStaffControlExpanded] = useState(true);
    const [workStartedAt, setWorkStartedAt] = useState<Date | null>(null);
    const [workEndedAt, setWorkEndedAt] = useState<Date | null>(null);
    const [otStartedAt, setOtStartedAt] = useState<Date | null>(null);
    const [otEndedAt, setOtEndedAt] = useState<Date | null>(null);
    const [actualClosingCash, setActualClosingCash] = useState(0);
    const [closingSummaryVisible, setClosingSummaryVisible] = useState(false);
    const [openingCashCounts, setOpeningCashCounts] = useState<Record<number, number>>(() => Object.fromEntries(OPENING_CASH_DENOMINATIONS.map((denomination) => [denomination, 0])));
    const [receiptOpen, setReceiptOpen] = useState(false);
    const [mixedPaymentOpen, setMixedPaymentOpen] = useState(false);
    const [message, setMessage] = useState<string | null>(null);
    const [customerDisplayMode, setCustomerDisplayMode] = useState<PosDisplayState["displayMode"]>("advertising");
    const [availableQrBanks, setAvailableQrBanks] = useState(qrBanks);
    const [selectedQrBankId, setSelectedQrBankId] = useState(qrBanks[0]?.id ?? "");
    const [currentTime, setCurrentTime] = useState(HYDRATION_SAFE_TIME);
    const [businessDate, setBusinessDate] = useState(HYDRATION_SAFE_BUSINESS_DATE);
    const [stockReferenceDate, setStockReferenceDate] = useState(HYDRATION_SAFE_REFERENCE_DATE);
    const billNo = "A0001";
    useEffect(() => {
        const storedQrBanks = window.localStorage.getItem(QR_BANKS_KEY);
        if (!storedQrBanks)
            return;
        try {
            const parsed = JSON.parse(storedQrBanks) as QrBank[];
            if (Array.isArray(parsed) && parsed.length > 0) {
                setAvailableQrBanks(parsed);
                setSelectedQrBankId((current) => current || parsed[0]?.id || "");
            }
        }
        catch {
            setAvailableQrBanks(qrBanks);
        }
    }, [qrBanks]);
    useEffect(() => {
        const updateClock = () => {
            const now = new Date();
            setCurrentTime(formatPosTime(now));
            setBusinessDate(formatBusinessDate(now));
            setStockReferenceDate(now);
        };
        updateClock();
        const interval = window.setInterval(updateClock, 30000);
        return () => window.clearInterval(interval);
    }, []);
    useEffect(() => {
        const searchParams = new URLSearchParams(window.location.search);
        const staffControlView = searchParams.get("staffControl");
        if (staffControlView === "collapsed") {
            setStaffControlExpanded(false);
        }
        if (searchParams.get("focus") === "staff") {
            window.setTimeout(() => {
                document.getElementById("staff-control")?.scrollIntoView({ block: "center" });
            }, 250);
        }
    }, []);
    const categories = useMemo(() => ["All", ...Array.from(new Set(products.map((product) => product.categoryName)))], [products]);
    const favoriteProducts = useMemo(() => {
        const favorites = products.filter((product) => product.isFavorite).slice(0, 16);
        return favorites.length >= 12 ? favorites : products.slice(0, 16);
    }, [products]);
    const filteredProducts = useMemo(() => {
        const normalized = productQuery.trim().toLowerCase();
        return products.filter((product) => {
            const categoryMatch = selectedCategory === "All" || product.categoryName === selectedCategory;
            const queryMatch = !normalized ||
                product.nameEn.toLowerCase().includes(normalized) ||
                product.nameLo.toLowerCase().includes(normalized) ||
                product.sku.toLowerCase().includes(normalized) ||
                product.productCode?.toLowerCase().includes(normalized) ||
                product.barcode.includes(productQuery.trim());
            return categoryMatch && queryMatch;
        });
    }, [productQuery, products, selectedCategory]);
    const selectedQrBank = availableQrBanks.find((bank) => bank.id === selectedQrBankId) ?? null;
    const staffOptions = useMemo(() => Array.from(new Set([cashierName || "Cashier 1", "Manager", "Cashier 1", "Cashier 2", "Owner"])), [cashierName]);
    const activeCustomer = isMembershipActive(selectedCustomer) ? selectedCustomer : null;
    const openingCashTotal = OPENING_CASH_DENOMINATIONS.reduce((total, denomination) => total + denomination * (openingCashCounts[denomination] ?? 0), 0);
    const workHours = calculateHours(workStartedAt, workEndedAt);
    const otHours = calculateHours(otStartedAt, otEndedAt);
    const subtotal = cartItems.reduce((total, item) => total + item.priceLak * item.quantity, 0);
    const membershipSavings = cartItems.reduce((total, item) => total + Math.max(item.retailPriceLak - item.priceLak, 0) * item.quantity, 0);
    const percentDiscountValue = Math.round(subtotal * (discountPercent / 100));
    const discountTotal = Math.min(subtotal, discountAmount + percentDiscountValue);
    const taxableAmount = Math.max(subtotal - discountTotal, 0);
    const taxAmount = taxEnabled
        ? Math.round(taxInclusive ? taxableAmount * (taxRatePercent / (100 + taxRatePercent)) : taxableAmount * (taxRatePercent / 100))
        : 0;
    const totalAmount = taxInclusive ? taxableAmount : taxableAmount + taxAmount;
    const pointsEarned = Math.floor(totalAmount / 10000);
    const paidAmount = paymentMode === "cash"
        ? cashAmount
        : paymentMode === "qr"
            ? qrAmount
            : paymentMode === "transfer"
                ? transferAmount
                : paymentMode === "card"
                    ? cardAmount
                    : cashAmount + qrAmount + transferAmount + cardAmount;
    const changeAmount = Math.max(paidAmount - totalAmount, 0);
    const dueAmount = Math.max(totalAmount - paidAmount, 0);
    const cashSales = cashAmount;
    const qrTransferSales = qrAmount + transferAmount;
    const expectedCash = openingCashTotal + cashSales;
    const cashDifference = actualClosingCash - expectedCash;
    const appliedPromotions = useMemo(() => {
        const labels = cartItems
            .map((item) => item.pricingNote)
            .filter((label): label is string => Boolean(label));
        if (discountTotal > 0)
            labels.push("Manual discount applied");
        if (promotionBanners.length > 0)
            labels.push(promotionBanners[0]);
        return Array.from(new Set(labels)).slice(0, 4);
    }, [cartItems, discountTotal, promotionBanners]);
    useEffect(() => {
        const state: PosDisplayState = {
            appliedPromotions,
            customer: selectedCustomer,
            displayMode: cartItems.length > 0 ? customerDisplayMode : "advertising",
            items: cartItems,
            membershipDiscountLak: membershipSavings,
            membershipPoints: selectedCustomer?.pointsBalance ?? 0,
            membershipStatus: selectedCustomer
                ? `${selectedCustomer.membershipType} ${isMembershipActive(selectedCustomer) ? "Active" : "Expired"}`
                : "Guest",
            pointsEarned,
            promotionDiscountLak: discountTotal,
            selectedQrBank,
            storeLogoUrl: window.localStorage.getItem(t("ui.ego.pos.company.logo.url")),
            subtotalLak: subtotal,
            totalLak: totalAmount,
        };
        window.localStorage.setItem(POS_DISPLAY_KEY, JSON.stringify(state));
    }, [appliedPromotions, cartItems, customerDisplayMode, discountTotal, membershipSavings, pointsEarned, selectedCustomer, selectedQrBank, subtotal, totalAmount]);
    function addToCart(product: PosProduct, selectedUnit?: PosProductUnit) {
        const saleUnit = selectedUnit ?? getSaleUnits(product)[0];
        const unitProduct = saleUnit ? productWithSelectedUnit(product, saleUnit) : product;
        const pricedProduct = applyCustomerPricing(unitProduct, activeCustomer);
        const stockWarning = getStockWarning(unitProduct, stockReferenceDate);
        setCartItems((current) => {
            const existing = current.find((item) => item.id === product.id && item.unitId === pricedProduct.unitId);
            if (existing) {
                return current.map((item) => item.id === product.id && item.unitId === pricedProduct.unitId
                    ? { ...item, quantity: Math.min(item.quantity + 1, Math.max(1, Math.floor(item.stockQty / (item.conversionQty ?? 1)))) }
                    : item);
            }
            return [...current, { ...pricedProduct, id: product.id, quantity: 1, stockWarning }];
        });
        setCustomerDisplayMode("checkout");
        setUnitSelectionProduct(null);
        setMessage(stockWarning ? `${stockWarning.label}: ${product.nameEn}` : `${product.nameEn} ${saleUnit?.unitName ?? ""} added to cart.`);
    }
    function selectProductForSale(product: PosProduct, matchedUnit?: PosProductUnit) {
        const saleUnits = getSaleUnits(product);
        if (saleUnits.length <= 1) {
            addToCart(product, matchedUnit ?? saleUnits[0]);
            return;
        }
        setUnitSelectionProduct(matchedUnit ? productWithSortedMatchedUnit(product, matchedUnit) : product);
    }
    function scanBarcode() {
        const normalized = barcodeQuery.trim();
        if (!normalized) {
            setMessage(t("ui.scan.or.enter.barcode.sku.or.internal.code.f"));
            return;
        }
        const product = products.find((item) => item.barcode === normalized ||
            item.units?.some((unit) => unit.barcode === normalized) ||
            item.sku.toLowerCase() === normalized.toLowerCase() ||
            item.productCode?.toLowerCase() === normalized.toLowerCase());
        if (!product) {
            setMessage(t("ui.no.product.found.for.barcode.sku.or.internal"));
            return;
        }
        const matchedUnit = product.units?.find((unit) => unit.barcode === normalized);
        selectProductForSale(product, matchedUnit);
        setBarcodeQuery("");
    }
    function searchMembership() {
        const query = membershipQuery.trim().toLowerCase();
        const customer = customers.find((item) => item.phone.includes(query) ||
            item.name.toLowerCase().includes(query) ||
            item.membershipNumber.toLowerCase().includes(query));
        if (!customer) {
            setSelectedCustomer(null);
            setMessage(t("ui.no.customer.or.membership.found"));
            return;
        }
        setSelectedCustomer(customer);
        setMessage(isMembershipActive(customer)
            ? `${customer.name} membership active.`
            : `${customer.name} membership expired. Retail pricing applies.`);
    }
    function updateQuantity(productId: string, quantity: number, unitId?: string) {
        setCartItems((current) => current
            .map((item) => item.id === productId && item.unitId === unitId
            ? { ...item, quantity: Math.max(1, Math.min(quantity, Math.max(1, Math.floor(item.stockQty / (item.conversionQty ?? 1))))) }
            : item)
            .filter((item) => item.quantity > 0));
    }
    function removeItem(productId: string, unitId?: string) {
        setCartItems((current) => current.filter((item) => !(item.id === productId && item.unitId === unitId)));
    }
    function holdSale() {
        if (cartItems.length === 0) {
            setMessage(t("ui.cart.is.empty.add.items.before.holding.a.bil"));
            return;
        }
        const heldSale: HeldSale = {
            id: `hold-${Date.now()}`,
            saleNo: nextHoldName(heldSales.length),
            createdAt: new Date().toLocaleString("en-GB"),
            itemCount: cartItems.reduce((total, item) => total + item.quantity, 0),
            totalLak: totalAmount,
            items: cartItems,
        };
        setHeldSales((current) => [heldSale, ...current]);
        clearSale();
        setMessage(`Bill ${heldSale.saleNo} held.`);
    }
    function resumeSale() {
        const heldSale = heldSales.find((sale) => sale.id === selectedHeldSaleId);
        if (!heldSale) {
            setMessage(t("ui.select.a.held.bill.to.resume"));
            return;
        }
        setCartItems(heldSale.items);
        setHeldSales((current) => current.filter((sale) => sale.id !== heldSale.id));
        setSelectedHeldSaleId("");
        setMessage(`Bill ${heldSale.saleNo} resumed.`);
    }
    function deleteHeldSale() {
        if (!selectedHeldSaleId) {
            setMessage(t("ui.select.a.held.bill.to.delete"));
            return;
        }
        const sale = heldSales.find((item) => item.id === selectedHeldSaleId);
        setHeldSales((current) => current.filter((item) => item.id !== selectedHeldSaleId));
        setSelectedHeldSaleId("");
        setMessage(`Bill ${sale?.saleNo ?? ""} deleted.`);
    }
    function completeSale() {
        if (cartItems.length === 0) {
            setMessage(t("ui.cart.is.empty"));
            return;
        }
        if (dueAmount > 0) {
            setMessage(t("ui.payment.is.not.complete.yet"));
            return;
        }
        const saleNo = `SALE-${Date.now()}`;
        startTransition(async () => {
            const result = await completeSaleAction({
                branchId,
                cardAmount,
                cashAmount,
                changeAmount,
                customerId: selectedCustomer?.id,
                discountAmount,
                discountPercent,
                items: cartItems.map((item) => ({
                    costPrice: item.costPriceLak,
                    conversionQty: item.conversionQty ?? 1,
                    productId: item.id,
                    quantity: item.quantity,
                    sellingPrice: item.priceLak,
                    unitId: item.unitId,
                })),
                paymentMode,
                qrAmount,
                saleNo,
                taxAmount,
                taxRate: taxEnabled ? taxRatePercent : 0,
                totalAmount,
                transferAmount,
                warehouseId,
            });
            if (!result.ok) {
                setMessage(result.error ?? t("ui.sale.completion.failed"));
                return;
            }
            setReceiptOpen(true);
            setMessage(`${saleNo} completed and saved.`);
            setCustomerDisplayMode("thank_you");
            const displaySettings = readCustomerDisplaySettingsFromStorage();
            window.setTimeout(() => {
                clearSale();
                setCustomerDisplayMode("advertising");
            }, displaySettings.autoReturnSeconds * 1000);
        });
    }
    function clearSale() {
        setCartItems([]);
        setDiscountAmount(0);
        setDiscountPercent(0);
        setCashAmount(0);
        setQrAmount(0);
        setTransferAmount(0);
        setCardAmount(0);
        setPaymentMode("cash");
        setCustomerDisplayMode("advertising");
    }
    function updateOpeningCashCount(denomination: number, quantity: number) {
        setOpeningCashCounts((current) => ({ ...current, [denomination]: Math.max(0, Math.floor(quantity)) }));
    }
    function recordStartWork() {
        setWorkStartedAt(new Date());
        setWorkEndedAt(null);
        setStaffStatus("Working");
        setClosingSummaryVisible(false);
    }
    function recordEndWork() {
        setWorkEndedAt(new Date());
        setStaffStatus("Closed");
        setClosingSummaryVisible(true);
    }
    function recordStartOt() {
        setOtStartedAt(new Date());
        setOtEndedAt(null);
        setStaffStatus("OT");
    }
    function recordEndOt() {
        setOtEndedAt(new Date());
        setStaffStatus(workEndedAt ? "Closed" : "Working");
    }
    return (<div className="flex min-w-0 flex-col gap-3">
      {message ? (<div className="rounded-md border border-primary/30 bg-primary/10 px-4 py-2 text-sm text-primary">
          {message}
        </div>) : null}

      <section className="grid min-w-0 gap-3 xl:grid-cols-[minmax(0,1fr)_390px] 2xl:grid-cols-[minmax(0,1fr)_430px]">
        <main className="flex min-w-0 flex-col gap-3">
          <Panel className="p-3">
            <div className="grid gap-3 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)_auto]">
              <label className="relative">
                <Barcode className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-primary" aria-hidden="true"/>
                <input autoFocus className="h-14 w-full rounded-md border border-primary/40 bg-background pl-12 pr-4 text-lg font-semibold outline-none transition focus:border-primary" placeholder="Scan barcode / SKU / code" value={barcodeQuery} onChange={(event) => setBarcodeQuery(event.target.value)} onKeyDown={(event) => {
            if (event.key === "Enter") {
                event.preventDefault();
                scanBarcode();
            }
        }}/>
              </label>
              <label className="relative">
                <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" aria-hidden="true"/>
                <input className="field-input h-14 pl-10" placeholder={t("ui.search.product.sku.code")} value={productQuery} onChange={(event) => setProductQuery(event.target.value)}/>
              </label>
              <button className="h-14 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground" type="button" onClick={scanBarcode}>
                Scan Barcode
              </button>
            </div>
            <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
              {categories.map((category) => (<button className={cn("h-10 shrink-0 rounded-md border px-4 text-sm font-semibold transition", selectedCategory === category
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-background text-muted-foreground hover:border-primary hover:text-foreground")} key={category} type="button" onClick={() => setSelectedCategory(category)}>
                  {category}
                </button>))}
            </div>
            <div className="mt-2 flex gap-2 overflow-x-auto pb-1">
              {favoriteProducts.slice(0, 16).map((product) => {
            const warning = getStockWarning(product, stockReferenceDate);
            return (<button className="grid h-16 w-36 shrink-0 rounded-md border border-border bg-background p-2 text-left text-xs font-semibold transition hover:border-primary" key={product.id} type="button" onClick={() => addToCart(product)}>
                    <span className="line-clamp-1">{product.nameEn}</span>
                    <span className="flex items-center justify-between gap-1 self-end">
                      <span className="text-primary">{formatLak(product.priceLak)}</span>
                      <span className={cn("rounded px-1 py-0.5 text-[10px]", warning ? warningBadgeClass(warning.tone) : "bg-primary/10 text-primary")}>
                        {warning?.label ?? product.stockQty}
                      </span>
                    </span>
                  </button>);
        })}
            </div>
            <div className="mt-2 flex gap-2 overflow-x-auto">
              {promotionBanners.map((banner) => (<div className="inline-flex h-9 shrink-0 items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 text-xs font-semibold text-primary" key={banner}>
                  <BadgePercent className="size-4" aria-hidden="true"/>
                  {banner}
                </div>))}
            </div>
          </Panel>

          <section className="grid min-w-0 grid-cols-2 gap-2 md:grid-cols-3 xl:grid-cols-4">
            {filteredProducts.map((product) => (<ProductGridItem key={product.id} product={product} stockReferenceDate={stockReferenceDate} onClick={() => selectProductForSale(product)}/>))}
          </section>
        </main>

        <aside className="flex min-w-0 flex-col gap-3">
          <Panel>
            <div className="flex items-center justify-between gap-3 border-b border-border p-3">
              <div className="min-w-0">
                <h2 className="font-semibold">Shopping Cart</h2>
                <p className="text-xs text-muted-foreground">{cartItems.length} lines</p>
              </div>
              <ShoppingCart className="text-primary" aria-hidden="true"/>
            </div>
            <div className="grid grid-cols-2 gap-x-3 gap-y-1 border-b border-border bg-background/50 px-3 py-2 text-xs">
              <CartMeta label={t("ui.bill.no")} value={billNo}/>
              <CartMeta label="Customer" value={selectedCustomer?.name ?? "Guest"}/>
              <CartMeta label="Cashier" value={cashierName || "Current User"}/>
              <CartMeta label="Time" value={currentTime}/>
            </div>
            <div className="max-h-[350px] overflow-y-auto p-3">
              {cartItems.length === 0 ? (<div className="grid min-h-36 place-items-center rounded-md border border-dashed border-border px-4 text-center text-sm text-muted-foreground">{t("ui.scan.barcode.or.tap.product.to.start.sale")}</div>) : (<div className="flex flex-col gap-2">
                  {cartItems.map((item) => (<div className="rounded-md border border-border bg-background p-2" key={`${item.id}:${item.unitId ?? "default"}`}>
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="line-clamp-1 text-sm font-semibold">{item.nameEn}</div>
                          <div className="font-mono text-[11px] text-muted-foreground">{item.sku} / {item.unitName}</div>
                          {item.stockWarning ? (<div className={cn("mt-1 text-xs font-semibold", warningTextClass(item.stockWarning.tone))}>
                              {item.stockWarning.label}
                            </div>) : null}
                          {item.pricingNote ? (<div className="mt-1 text-xs font-semibold text-primary">{item.pricingNote}</div>) : null}
                        </div>
                        <button className="grid size-8 shrink-0 place-items-center rounded-md border border-border text-danger" type="button" onClick={() => removeItem(item.id, item.unitId)} aria-label="Remove item">
                          <Trash2 aria-hidden="true"/>
                        </button>
                      </div>
                      <div className="mt-2 flex items-center justify-between gap-2">
                        <QuantityStepper item={item} onChange={updateQuantity}/>
                        <div className="text-right">
                          <div className="font-semibold">{formatLak(item.priceLak * item.quantity)} LAK</div>
                          <div className="text-xs text-muted-foreground">{formatLak(item.priceLak)} / {item.unitName}</div>
                        </div>
                      </div>
                    </div>))}
                </div>)}
            </div>
          </Panel>

          <Panel className="p-3">
            <div className="mb-2 flex items-center gap-2">
              <UserRoundSearch className="text-primary" aria-hidden="true"/>
              <h2 className="text-sm font-semibold">Membership Search</h2>
            </div>
            <div className="grid gap-2 sm:grid-cols-[minmax(0,1fr)_auto]">
              <input className="field-input h-10 text-sm" placeholder={t("ui.phone.name.or.member.no")} value={membershipQuery} onChange={(event) => setMembershipQuery(event.target.value)} onKeyDown={(event) => {
            if (event.key === "Enter") {
                event.preventDefault();
                searchMembership();
            }
        }}/>
              <button className="h-10 rounded-md bg-primary px-3 text-sm font-semibold text-primary-foreground" type="button" onClick={searchMembership}>
                Find Member
              </button>
            </div>
            <CustomerCard customer={selectedCustomer}/>
          </Panel>

          <Panel className="p-3">
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-semibold">Payment</h2>
              <button className="text-xs font-semibold text-primary" type="button" onClick={() => setMixedPaymentOpen(true)}>
                Mixed popup
              </button>
            </div>
            <dl className="mt-3">
              <div className="flex items-center justify-between rounded-md border border-primary/25 bg-primary/10 px-3 py-3 text-xl font-semibold">
                <dt>Total</dt>
                <dd>{formatLak(totalAmount)} LAK</dd>
              </div>
            </dl>
            <div className="mt-3 grid grid-cols-5 gap-1">
              <PaymentButton active={paymentMode === "cash"} icon={Banknote} label="Cash" onClick={() => setPaymentMode("cash")}/>
              <PaymentButton active={paymentMode === "qr"} icon={QrCode} label="QR" onClick={() => setPaymentMode("qr")}/>
              <PaymentButton active={paymentMode === "transfer"} icon={WalletCards} label="Bank" onClick={() => setPaymentMode("transfer")}/>
              <PaymentButton active={paymentMode === "card"} icon={CreditCard} label="Card" onClick={() => setPaymentMode("card")}/>
              <PaymentButton active={paymentMode === "mixed"} icon={ReceiptText} label="Mixed" onClick={() => { setPaymentMode("mixed"); setMixedPaymentOpen(true); }}/>
            </div>

            <PaymentFields availableQrBanks={availableQrBanks} cardAmount={cardAmount} cashAmount={cashAmount} mode={paymentMode} qrAmount={qrAmount} selectedQrBankId={selectedQrBankId} setCardAmount={setCardAmount} setCashAmount={setCashAmount} setQrAmount={setQrAmount} setSelectedQrBankId={setSelectedQrBankId} setTransferAmount={setTransferAmount} transferAmount={transferAmount}/>

            <dl className="mt-3 grid grid-cols-3 gap-2 text-sm">
              <Metric label="Paid" value={`${formatLak(paidAmount)} LAK`}/>
              <Metric label="Due" value={`${formatLak(dueAmount)} LAK`}/>
              <Metric label="Change" value={`${formatLak(changeAmount)} LAK`}/>
            </dl>
            <button className="mt-3 h-12 w-full rounded-md bg-primary text-sm font-semibold text-primary-foreground disabled:opacity-60" type="button" onClick={completeSale} disabled={isPending}>
              {isPending ? t("ui.completing") : "Complete Sale"}
            </button>

            <div className="mt-3 grid gap-3">
              <div className="rounded-md border border-border bg-background p-2">
                <div className="grid gap-2 sm:grid-cols-2 2xl:grid-cols-1">
                  <ActionButton icon={RotateCcw} label="Resume Bill" onClick={resumeSale}/>
                  <ActionButton icon={ReceiptText} label="Hold Bill" onClick={holdSale}/>
                </div>
                <div className="mt-2 grid gap-2">
                  <select className="field-input h-10 text-sm" value={selectedHeldSaleId} onChange={(event) => setSelectedHeldSaleId(event.target.value)}>
                    <option value="">Held bills</option>
                    {heldSales.map((sale) => (<option key={sale.id} value={sale.id}>
                        {sale.saleNo} - {formatLak(sale.totalLak)} LAK - {sale.itemCount} items
                      </option>))}
                  </select>
                  <button className="h-10 rounded-md border border-danger/40 px-3 text-sm font-semibold text-danger" type="button" onClick={deleteHeldSale}>
                    Delete Held Bill
                  </button>
                </div>
              </div>
            </div>
          </Panel>

          <StaffControl businessDate={businessDate} expanded={staffControlExpanded} actualClosingCash={actualClosingCash} cashDifference={cashDifference} cashSales={cashSales} closingSummaryVisible={closingSummaryVisible} expectedCash={expectedCash} openingCashCounts={openingCashCounts} openingCashTotal={openingCashTotal} otEndedAt={otEndedAt} otHours={otHours} otStartedAt={otStartedAt} selectedStaffName={selectedStaffName} staffOptions={staffOptions} staffStatus={staffStatus} workEndedAt={workEndedAt} workHours={workHours} workStartedAt={workStartedAt} onEndOt={recordEndOt} onEndWork={recordEndWork} onSetActualClosingCash={setActualClosingCash} onSelectStaff={setSelectedStaffName} onStartOt={recordStartOt} onStartWork={recordStartWork} onToggleExpanded={() => setStaffControlExpanded((current) => !current)} onUpdateOpeningCashCount={updateOpeningCashCount} qrTransferSales={qrTransferSales}/>
        </aside>
      </section>

      {mixedPaymentOpen ? (<MixedPaymentModal cardAmount={cardAmount} cashAmount={cashAmount} onClose={() => setMixedPaymentOpen(false)} qrAmount={qrAmount} setCardAmount={setCardAmount} setCashAmount={setCashAmount} setPaymentMode={setPaymentMode} setQrAmount={setQrAmount} setTransferAmount={setTransferAmount} totalAmount={totalAmount} transferAmount={transferAmount}/>) : null}

      {unitSelectionProduct ? (<UnitSelectorModal product={unitSelectionProduct} onClose={() => setUnitSelectionProduct(null)} onSelect={(unit) => addToCart(unitSelectionProduct, unit)}/>) : null}

      {receiptOpen ? (<ReceiptPreview branchName={branchName} cashierName={cashierName} cartItems={cartItems} changeAmount={changeAmount} discountTotal={discountTotal} onClose={() => setReceiptOpen(false)} paidAmount={paidAmount} paymentMode={paymentMode} subtotal={subtotal} taxAmount={taxAmount} totalAmount={totalAmount}/>) : null}
    </div>);
}
function Panel({ children, className }: {
    children: React.ReactNode;
    className?: string;
}) {
    return <section className={cn("min-w-0 rounded-lg border border-border bg-card", className)}>{children}</section>;
}
function CustomerCard({ customer }: {
    customer: PosCustomer | null;
}) {
    if (!customer) {
        return (<div className="mt-2 rounded-md border border-dashed border-border px-2 py-1.5 text-xs text-muted-foreground">{t("ui.guest.sale.search.for.member.pricing")}</div>);
    }
    const active = isMembershipActive(customer);
    return (<div className="mt-2 rounded-md border border-border bg-background p-2 text-xs">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="font-semibold">{customer.name}</div>
          <div className="text-[11px] text-muted-foreground">{customer.phone}</div>
        </div>
        <span className={cn("rounded-full px-2 py-0.5 text-[11px] font-semibold", active ? "bg-success/10 text-success" : "bg-danger/10 text-danger")}>
          {customer.membershipStatus}
        </span>
      </div>
      <div className="mt-1.5 grid grid-cols-2 gap-x-2 gap-y-1 text-[11px]">
        <InfoLine label="Type" value={customer.membershipType}/>
        <InfoLine label={t("ui.member.no")} value={customer.membershipNumber}/>
        <InfoLine label="Expiry" value={customer.membershipExpiry}/>
        <InfoLine label="Points" value={String(customer.pointsBalance)}/>
      </div>
      {customer.membershipType === "Student" ? (<div className="mt-1.5 rounded-md bg-primary/10 p-1.5 text-[11px] text-primary">
          <div className="flex items-center gap-1 font-semibold"><GraduationCap className="size-4" aria-hidden="true"/> Student verified</div>
          <div className="line-clamp-1">{customer.schoolName} - {customer.studentIdNumber}</div>
          <div>Card upload: {customer.studentCardUrl ? "Stored" : "Missing"}</div>
        </div>) : null}
    </div>);
}
function InfoLine({ label, value }: {
    label: string;
    value: string;
}) {
    return (<div>
      <div className="text-muted-foreground">{label}</div>
      <div className="font-semibold">{value}</div>
    </div>);
}
function ProductGridItem({ onClick, product, stockReferenceDate, }: {
    onClick: () => void;
    product: PosProduct;
    stockReferenceDate: Date;
}) {
    return (<>
      <button className="min-h-[176px] rounded-lg border border-border bg-card p-3 text-left transition hover:border-primary hover:shadow-sm" type="button" onClick={onClick}>
        <PosProductImage imageKey={product.imageKey} imageUrl={product.unitImageUrl} label={product.nameEn}/>
        <div className="mt-3 min-h-12">
          <div className="line-clamp-1 text-sm font-semibold">{product.nameEn}</div>
          <div className="line-clamp-1 text-xs text-muted-foreground">{product.sku}</div>
        </div>
        <div className="mt-3 flex items-end justify-between gap-2">
          <div>
            <div className="text-base font-semibold">{formatLak(product.priceLak)}</div>
            <div className="text-xs text-muted-foreground">LAK / {product.unitName}</div>
          </div>
          <StockBadge product={product} stockReferenceDate={stockReferenceDate}/>
        </div>
      </button>
    </>);
}
function CartMeta({ label, value }: {
    label: string;
    value: string;
}) {
    return (<div className="min-w-0">
      <span className="text-muted-foreground">{label}: </span>
      <span className="truncate font-semibold">{value}</span>
    </div>);
}
function StockBadge({ product, stockReferenceDate }: {
    product: PosProduct;
    stockReferenceDate: Date;
}) {
    const warning = getStockWarning(product, stockReferenceDate);
    return (<span className={cn("rounded-md px-2 py-1 text-xs font-semibold", warning ? warningBadgeClass(warning.tone) : "bg-primary/10 text-primary")}>
      {warning ? warning.label : `${product.stockQty} left`}
    </span>);
}
function QuantityStepper({ item, onChange }: {
    item: PosCartItem;
    onChange: (productId: string, quantity: number, unitId?: string) => void;
}) {
    const maxSaleQty = Math.max(1, Math.floor(item.stockQty / (item.conversionQty ?? 1)));
    return (<div className="inline-flex h-10 items-center rounded-md border border-border">
      <button className="grid size-10 place-items-center" type="button" onClick={() => onChange(item.id, item.quantity - 1, item.unitId)} aria-label="Decrease quantity">
        <Minus aria-hidden="true"/>
      </button>
      <PosNumberInput className="h-10 w-14 border-x border-border bg-transparent text-center text-sm font-semibold outline-none" max={maxSaleQty} min={1} value={item.quantity} onValueChange={(value) => onChange(item.id, value, item.unitId)}/>
      <button className="grid size-10 place-items-center" type="button" onClick={() => onChange(item.id, item.quantity + 1, item.unitId)} aria-label="Increase quantity">
        <Plus aria-hidden="true"/>
      </button>
    </div>);
}
function Field({ children, label }: {
    children: React.ReactNode;
    label: string;
}) {
    return (<label className="flex flex-col gap-1 text-xs font-semibold">
      {label}
      {children}
    </label>);
}
function PaymentFields({ availableQrBanks, cardAmount, cashAmount, mode, qrAmount, selectedQrBankId, setCardAmount, setCashAmount, setQrAmount, setSelectedQrBankId, setTransferAmount, transferAmount, }: {
    availableQrBanks: QrBank[];
    cardAmount: number;
    cashAmount: number;
    mode: PaymentMode;
    qrAmount: number;
    selectedQrBankId: string;
    setCardAmount: (value: number) => void;
    setCashAmount: (value: number) => void;
    setQrAmount: (value: number) => void;
    setSelectedQrBankId: (value: string) => void;
    setTransferAmount: (value: number) => void;
    transferAmount: number;
}) {
    return (<div className="mt-3 grid gap-2 sm:grid-cols-2">
      {(mode === "cash" || mode === "mixed") ? (<Field label="Cash Amount">
          <PosNumberInput className="field-input" value={cashAmount} onValueChange={setCashAmount}/>
        </Field>) : null}
      {(mode === "qr" || mode === "mixed") ? (<>
          <Field label="QR Bank">
            <select className="field-input" value={selectedQrBankId} onChange={(event) => setSelectedQrBankId(event.target.value)}>
              {availableQrBanks.map((bank) => (<option key={bank.id} value={bank.id}>{bank.bankName}</option>))}
            </select>
          </Field>
          <Field label="QR Amount">
            <PosNumberInput className="field-input" value={qrAmount} onValueChange={setQrAmount}/>
          </Field>
        </>) : null}
      {(mode === "transfer" || mode === "mixed") ? (<Field label="Bank Transfer">
          <PosNumberInput className="field-input" value={transferAmount} onValueChange={setTransferAmount}/>
        </Field>) : null}
      {(mode === "card" || mode === "mixed") ? (<Field label="Card Amount">
          <PosNumberInput className="field-input" value={cardAmount} onValueChange={setCardAmount}/>
        </Field>) : null}
    </div>);
}
function Metric({ label, value }: {
    label: string;
    value: string;
}) {
    return (<div className="rounded-md border border-border bg-background p-2">
      <dt className="text-[11px] text-muted-foreground">{label}</dt>
      <dd className="mt-1 text-sm font-semibold">{value}</dd>
    </div>);
}
function StaffControl({ actualClosingCash, businessDate, cashDifference, cashSales, closingSummaryVisible, expanded, expectedCash, openingCashCounts, openingCashTotal, onEndOt, onEndWork, onSetActualClosingCash, onSelectStaff, onStartOt, onStartWork, onToggleExpanded, onUpdateOpeningCashCount, otEndedAt, otHours, otStartedAt, selectedStaffName, staffOptions, staffStatus, workEndedAt, workHours, workStartedAt, qrTransferSales, }: {
    actualClosingCash: number;
    businessDate: string;
    cashDifference: number;
    cashSales: number;
    closingSummaryVisible: boolean;
    expanded: boolean;
    expectedCash: number;
    openingCashCounts: Record<number, number>;
    openingCashTotal: number;
    otEndedAt: Date | null;
    otHours: number;
    otStartedAt: Date | null;
    selectedStaffName: string;
    staffOptions: string[];
    staffStatus: string;
    workEndedAt: Date | null;
    workHours: number;
    workStartedAt: Date | null;
    onEndOt: () => void;
    onEndWork: () => void;
    onSetActualClosingCash: (value: number) => void;
    onSelectStaff: (staffName: string) => void;
    onStartOt: () => void;
    onStartWork: () => void;
    onToggleExpanded: () => void;
    onUpdateOpeningCashCount: (denomination: number, quantity: number) => void;
    qrTransferSales: number;
}) {
    const CollapseIcon = expanded ? ChevronUp : ChevronDown;
    const isWorking = staffStatus === "Working";
    const isOt = staffStatus === "OT";
    return (<section className="min-w-0 scroll-mt-24 rounded-lg border border-border bg-card p-3" id="staff-control">
      <button className="flex w-full items-center justify-between gap-3 text-left" type="button" onClick={onToggleExpanded} aria-expanded={expanded}>
        <div className="flex min-w-0 items-center gap-2">
          <CalendarDays className="size-4 shrink-0 text-primary" aria-hidden="true"/>
          <div className="min-w-0 text-xs">
            <div className="flex min-w-0 flex-wrap items-center gap-x-2 gap-y-1">
              <h3 className="text-sm font-semibold">Staff Control</h3>
              <span className="text-muted-foreground">|</span>
              <span className="text-muted-foreground">{businessDate}</span>
              <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-semibold", staffStatusClassName(staffStatus))}>{staffStatus}</span>
            </div>
            <div className="mt-1 text-[11px] font-semibold text-muted-foreground">
              Work {workHours.toFixed(2)}h | OT {otHours.toFixed(2)}h
            </div>
          </div>
        </div>
        <CollapseIcon className="size-4 shrink-0 text-muted-foreground" aria-hidden="true"/>
      </button>

      {!expanded ? null : (<>
          <div className="mt-3 rounded-md border border-[#FFD700]/35 bg-[#FFD700]/10 p-2">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-[#FFD700]">Opening Cash Total</div>
            <div className="mt-1 text-2xl font-black leading-none text-[#FFD700]">{formatLak(openingCashTotal)} LAK</div>
          </div>

          <label className="mt-3 grid gap-1 text-xs font-semibold">
            Staff
            <select className="field-input h-9 text-xs" value={selectedStaffName} onChange={(event) => onSelectStaff(event.target.value)}>
              {staffOptions.map((staffName) => (<option key={staffName} value={staffName}>
                  {staffName}
                </option>))}
            </select>
          </label>

          <div className="mt-2 grid grid-cols-2 gap-1">
            <StaffButton active={isWorking} tone="success" label="Start Work" onClick={onStartWork}/>
            <StaffButton label="End Work" onClick={onEndWork}/>
            <StaffButton active={isOt} tone="warning" label="Start OT" onClick={onStartOt}/>
            <StaffButton label="End OT" onClick={onEndOt}/>
          </div>

          <div className="mt-2 grid grid-cols-2 gap-2 rounded-md border border-border bg-background p-2 text-[11px]">
            <StaffTime label="Start Work" value={formatStaffTime(workStartedAt)}/>
            <StaffTime label="End Work" value={formatStaffTime(workEndedAt)}/>
            <StaffTime label="Start OT" value={formatStaffTime(otStartedAt)}/>
            <StaffTime label="End OT" value={formatStaffTime(otEndedAt)}/>
            <StaffTime label="Work Hours" value={workHours.toFixed(2)} strong/>
            <StaffTime label="OT Hours" value={otHours.toFixed(2)} strong/>
          </div>

          <div className="mt-2 rounded-md border border-border bg-background p-2">
            <div className="mb-2 text-xs font-semibold">
              <span>Opening Cash Count</span>
            </div>
            <div className="grid grid-cols-2 gap-x-3 gap-y-1">
              {OPENING_CASH_DENOMINATIONS.map((denomination) => (<label className="grid grid-cols-[58px_minmax(0,1fr)] items-center gap-2 text-[11px]" key={denomination}>
                  <span className="font-semibold">{formatLak(denomination)}</span>
                  <PosNumberInput className="h-8 min-w-0 rounded-md border border-border bg-card px-1 text-center text-[11px] font-semibold outline-none transition focus:border-primary" min={0} value={openingCashCounts[denomination] ?? 0} onValueChange={(value) => onUpdateOpeningCashCount(denomination, value)}/>
                </label>))}
            </div>
          </div>

          <div className="mt-2 rounded-md border border-border bg-background p-2">
            <div className="mb-2 flex items-center justify-between gap-2">
              <div className="text-xs font-semibold">Closing Summary</div>
              {closingSummaryVisible ? (<span className="rounded-full border border-warning/40 bg-warning/10 px-2 py-0.5 text-[10px] font-semibold text-warning">Confirm required</span>) : null}
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <SettlementValue label="Cash Sales" value={`${formatLak(cashSales)} LAK`}/>
              <SettlementValue label="QR / Transfer" value={`${formatLak(qrTransferSales)} LAK`}/>
              <SettlementValue label="Expected Cash" value={`${formatLak(expectedCash)} LAK`} strong/>
              <label className="grid gap-1">
                <span className="text-muted-foreground">Actual Cash</span>
                <PosNumberInput className="h-9 rounded-md border border-border bg-card px-2 text-xs font-semibold outline-none transition focus:border-primary" value={actualClosingCash} onValueChange={onSetActualClosingCash}/>
              </label>
            </div>
            <div className={cn("mt-2 rounded-md border px-2 py-2 text-xs font-semibold", cashDifference === 0
                ? "border-success/30 bg-success/10 text-success"
                : "border-danger/40 bg-danger/10 text-danger")}>
              Cash Difference: {formatLak(cashDifference)} LAK
            </div>
            {closingSummaryVisible ? (<button className="mt-2 h-9 w-full rounded-md border border-primary/40 bg-primary/10 text-xs font-semibold text-primary transition hover:bg-primary hover:text-primary-foreground" type="button">
                Confirm Closing Summary
              </button>) : null}
          </div>
        </>)}
    </section>);
}
function StaffTime({ label, strong = false, value }: {
    label: string;
    strong?: boolean;
    value: string;
}) {
    return (<div>
      <div className="text-muted-foreground">{label}</div>
      <div className={cn("font-semibold", strong && "text-primary")}>{value}</div>
    </div>);
}
function StaffButton({ active = false, label, onClick, tone = "neutral" }: {
    active?: boolean;
    label: string;
    onClick: () => void;
    tone?: "neutral" | "success" | "warning";
}) {
    return (<button className={cn("h-8 rounded-md border px-2 text-[11px] font-semibold transition hover:border-primary", active && tone === "success"
            ? "border-success bg-success text-white shadow-sm"
            : active && tone === "warning"
                ? "border-warning bg-warning text-black shadow-sm"
                : "border-border bg-card")} type="button" onClick={onClick}>
      {label}
    </button>);
}
function SettlementValue({ label, strong = false, value }: {
    label: string;
    strong?: boolean;
    value: string;
}) {
    return (<div>
      <div className="text-muted-foreground">{label}</div>
      <div className={cn("font-semibold", strong && t("ui.text.ffd700"))}>{value}</div>
    </div>);
}
function staffStatusClassName(status: string) {
    if (status === "Working")
        return "bg-success/15 text-success";
    if (status === "OT")
        return "bg-warning/15 text-warning";
    if (status === "Closed")
        return "bg-danger/15 text-danger";
    return "bg-muted text-muted-foreground";
}
function PosNumberInput({ className, max, min = 0, onValueChange, value, }: {
    className?: string;
    max?: number;
    min?: number;
    value: number;
    onValueChange: (value: number) => void;
}) {
    const [draft, setDraft] = useState(String(value));
    useEffect(() => {
        setDraft(String(value));
    }, [value]);
    function normalize(rawValue: string) {
        const digits = rawValue.replace(/[^\d]/g, "");
        if (!digits)
            return "";
        return digits.replace(/^0+(?=\d)/, "");
    }
    function commit(rawValue: string) {
        const normalized = normalize(rawValue);
        const numericValue = normalized ? Number(normalized) : 0;
        const clampedValue = Math.min(Math.max(numericValue, min), max ?? Number.MAX_SAFE_INTEGER);
        onValueChange(clampedValue);
        setDraft(String(clampedValue));
    }
    return (<input className={className} inputMode="numeric" type="text" value={draft} onBlur={() => commit(draft)} onChange={(event) => {
            const normalized = normalize(event.target.value);
            setDraft(normalized);
            onValueChange(normalized ? Number(normalized) : 0);
        }} onFocus={() => {
            if (value === 0)
                setDraft("");
        }}/>);
}
function PaymentButton({ active, icon: Icon, label, onClick }: {
    active: boolean;
    icon: typeof Banknote;
    label: string;
    onClick: () => void;
}) {
    const isMixed = label === "Mixed";
    return (<button className={cn("flex min-h-12 flex-col items-center justify-center gap-1 rounded-md border px-1 text-[11px] font-semibold transition", active
            ? isMixed
                ? "border-success bg-success text-white shadow-sm"
                : "border-primary bg-primary text-primary-foreground"
            : isMixed
                ? "border-success/50 bg-success/10 text-success hover:bg-success hover:text-white"
                : "border-border text-muted-foreground hover:border-primary hover:text-foreground")} type="button" onClick={onClick}>
      <Icon className="size-4" aria-hidden="true"/>
      {label}
    </button>);
}
function UnitSelectorModal({ onClose, onSelect, product, }: {
    onClose: () => void;
    onSelect: (unit: PosProductUnit) => void;
    product: PosProduct;
}) {
    const units = getSaleUnits(product);
    return (<div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4">
      <section className="w-full max-w-lg rounded-lg border border-border bg-card p-5 shadow-2xl">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold">Select sale unit</h2>
            <p className="mt-1 text-sm text-muted-foreground">{product.nameEn || product.nameLo}</p>
          </div>
          <button className="grid size-9 place-items-center rounded-md border border-border" type="button" onClick={onClose} aria-label="Close unit selector">
            <X className="size-4" aria-hidden="true"/>
          </button>
        </div>
        <div className="mt-5 grid gap-2">
          {units.map((unit) => (<button className="flex items-center justify-between gap-3 rounded-md border border-border bg-background p-3 text-left transition hover:border-primary" key={unit.id} type="button" onClick={() => onSelect(unit)}>
              <span>
                <span className="block font-semibold">{unit.unitName}</span>
                <span className="mt-1 block text-xs text-muted-foreground">
                  {unit.conversionQty} base units {unit.barcode ? `| ${unit.barcode}` : t("ui.manual.select")}
                </span>
              </span>
              <span className="text-right font-semibold text-primary">{formatLak(unit.sellingPriceLak)} LAK</span>
            </button>))}
        </div>
      </section>
    </div>);
}
function ActionButton({ icon: Icon, label, onClick }: {
    icon: LucideIcon;
    label: string;
    onClick: () => void;
}) {
    return (<button className="inline-flex min-h-11 items-center justify-center gap-2 rounded-md border border-border bg-background px-3 text-sm font-semibold transition hover:border-primary" type="button" onClick={onClick}>
      <Icon className="size-4" aria-hidden="true"/>
      {label}
    </button>);
}
function MixedPaymentModal({ cardAmount, cashAmount, onClose, qrAmount, setCardAmount, setCashAmount, setPaymentMode, setQrAmount, setTransferAmount, totalAmount, transferAmount, }: {
    cardAmount: number;
    cashAmount: number;
    onClose: () => void;
    qrAmount: number;
    setCardAmount: (value: number) => void;
    setCashAmount: (value: number) => void;
    setPaymentMode: (mode: PaymentMode) => void;
    setQrAmount: (value: number) => void;
    setTransferAmount: (value: number) => void;
    totalAmount: number;
    transferAmount: number;
}) {
    const paid = cashAmount + qrAmount + cardAmount + transferAmount;
    const valid = paid >= totalAmount;
    return (<div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
      <div className="w-full max-w-lg rounded-lg border border-border bg-card p-5 shadow-2xl">
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-lg font-semibold">Mixed Payment</h2>
          <button className="grid size-9 place-items-center rounded-md border border-border" type="button" onClick={onClose} aria-label="Close mixed payment">
            <X aria-hidden="true"/>
          </button>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <Field label="Cash Amount">
            <PosNumberInput className="field-input" value={cashAmount} onValueChange={setCashAmount}/>
          </Field>
          <Field label="QR Amount">
            <PosNumberInput className="field-input" value={qrAmount} onValueChange={setQrAmount}/>
          </Field>
          <Field label="Card Amount">
            <PosNumberInput className="field-input" value={cardAmount} onValueChange={setCardAmount}/>
          </Field>
          <Field label="Transfer Amount">
            <PosNumberInput className="field-input" value={transferAmount} onValueChange={setTransferAmount}/>
          </Field>
        </div>
        <div className={cn("mt-4 rounded-md border p-3 text-sm font-semibold", valid ? "border-success/40 bg-success/10 text-success" : "border-warning/40 bg-warning/10 text-warning")}>
          Paid {formatLak(paid)} LAK / Total {formatLak(totalAmount)} LAK
        </div>
        <button className="mt-4 h-11 w-full rounded-md bg-primary text-sm font-semibold text-primary-foreground" type="button" onClick={() => { setPaymentMode("mixed"); onClose(); }}>
          Apply Mixed Payment
        </button>
      </div>
    </div>);
}
function ReceiptPreview({ branchName, cashierName, cartItems, changeAmount, discountTotal, onClose, paidAmount, paymentMode, subtotal, taxAmount, totalAmount, }: {
    branchName: string;
    cashierName: string;
    cartItems: PosCartItem[];
    changeAmount: number;
    discountTotal: number;
    onClose: () => void;
    paidAmount: number;
    paymentMode: PaymentMode;
    subtotal: number;
    taxAmount: number;
    totalAmount: number;
}) {
    return (<div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
      <div className="max-h-[92vh] w-full max-w-md overflow-y-auto rounded-lg border border-border bg-card p-5 shadow-2xl">
        <div className="flex items-center justify-between gap-3 print:hidden">
          <h2 className="text-lg font-semibold">Receipt preview</h2>
          <button className="h-10 rounded-md border border-border px-3 text-sm font-semibold" type="button" onClick={onClose}>Close</button>
        </div>
        <div className="mt-4 rounded-md border border-border bg-background p-5 font-mono text-sm">
          <div className="text-center">
            <div className="text-lg font-bold">EGO POS</div>
            <div>{branchName}</div>
            <div>{t("ui.cashier")}{cashierName}</div>
            <div>{new Date().toLocaleString("en-GB")}</div>
          </div>
          <div className="my-4 border-t border-dashed border-border"/>
          <div className="flex flex-col gap-3">
            {cartItems.map((item) => (<div key={item.id}>
                <div className="flex justify-between gap-3">
                  <span>{item.nameEn}</span>
                  <span>{formatLak(item.priceLak * item.quantity)}</span>
                </div>
                <div className="text-muted-foreground">{item.quantity} x {formatLak(item.priceLak)} LAK</div>
              </div>))}
          </div>
          <div className="my-4 border-t border-dashed border-border"/>
          <ReceiptRow label="Subtotal" value={subtotal}/>
          <ReceiptRow label="Discount" value={-discountTotal}/>
          <ReceiptRow label="Tax" value={taxAmount}/>
          <ReceiptRow label="Total" value={totalAmount} strong/>
          <ReceiptRow label={`Paid ${paymentMode.toUpperCase()}`} value={paidAmount}/>
          <ReceiptRow label="Change" value={changeAmount}/>
          <div className="my-4 border-t border-dashed border-border"/>
          <div className="text-center">Thank you</div>
        </div>
        <button className="mt-4 inline-flex h-11 w-full items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground print:hidden" type="button" onClick={() => window.print()}>
          <Printer aria-hidden="true"/>
          Print receipt
        </button>
      </div>
    </div>);
}
function ReceiptRow({ label, strong = false, value }: {
    label: string;
    strong?: boolean;
    value: number;
}) {
    return (<div className={cn("flex justify-between gap-3", strong && "font-bold")}>
      <span>{label}</span>
      <span>{formatLak(value)} LAK</span>
    </div>);
}
function isMembershipActive(customer: PosCustomer | null | undefined) {
    if (!customer || customer.membershipStatus !== "Active")
        return false;
    const expiry = new Date(`${customer.membershipExpiry}T23:59:59`);
    return expiry.getTime() >= Date.now();
}
function getSaleUnits(product: PosProduct) {
    const units = (product.units ?? []).filter((unit) => unit.status !== "inactive" && unit.allowManualUnitSelect !== false);
    if (units.length === 0) {
        return [{
                allowManualUnitSelect: true,
                barcode: product.barcode,
                conversionQty: 1,
                costPriceLak: product.costPriceLak ?? 0,
                id: `${product.id}-default-unit`,
                isBaseUnit: true,
                isDefaultSaleUnit: true,
                isPurchaseUnit: true,
                sellingPriceLak: product.priceLak,
                sortOrder: 0,
                status: "active" as const,
                unitName: product.unitName,
            }];
    }
    return units;
}
function productWithSelectedUnit(product: PosProduct, unit: PosProductUnit): PosProduct {
    return {
        ...product,
        barcode: unit.barcode || product.barcode,
        conversionQty: unit.conversionQty,
        costPriceLak: unit.costPriceLak,
        priceLak: unit.sellingPriceLak,
        unitId: unit.id,
        unitImageUrl: unit.imageUrl || product.unitImageUrl,
        unitName: unit.unitName,
    } as PosProduct;
}
function productWithSortedMatchedUnit(product: PosProduct, unit: PosProductUnit) {
    return {
        ...product,
        units: [...(product.units ?? [])].sort((left, right) => {
            if (left.id === unit.id)
                return -1;
            if (right.id === unit.id)
                return 1;
            return left.sortOrder - right.sortOrder;
        }),
    };
}
function applyCustomerPricing(product: PosProduct, customer: PosCustomer | null): PosCartItem {
    const retailPriceLak = product.priceLak;
    if (!customer) {
        return { ...product, priceLak: retailPriceLak, quantity: 1, retailPriceLak };
    }
    if (customer.membershipType === "Student" && product.specialStudentPriceLak) {
        return {
            ...product,
            priceLak: product.specialStudentPriceLak,
            quantity: 1,
            retailPriceLak,
            pricingNote: "Student special price",
        };
    }
    if (customer.discountPercent && customer.discountPercent > 0) {
        return {
            ...product,
            priceLak: Math.round(retailPriceLak * (1 - customer.discountPercent / 100)),
            quantity: 1,
            retailPriceLak,
            pricingNote: `${customer.discountPercent}% member discount`,
        };
    }
    return { ...product, priceLak: retailPriceLak, quantity: 1, retailPriceLak };
}
function getStockWarning(product: PosProduct, referenceDate: Date): PosCartItem["stockWarning"] {
    if (product.expiryDate) {
        const expiry = new Date(`${product.expiryDate}T00:00:00`);
        const days = Math.ceil((expiry.getTime() - referenceDate.getTime()) / 86400000);
        if (days < 0)
            return { label: "Expired", tone: "red" };
        if (days <= 7)
            return { label: "Near Expiry", tone: "yellow" };
    }
    if (product.stockQty <= (product.lowStockThreshold ?? 5)) {
        return { label: "Low Stock", tone: "orange" };
    }
    return undefined;
}
function warningBadgeClass(tone: "orange" | "yellow" | "red") {
    if (tone === "red")
        return "bg-danger/10 text-danger";
    if (tone === "yellow")
        return "bg-warning/10 text-warning";
    return "bg-orange-500/10 text-orange-500";
}
function warningTextClass(tone: "orange" | "yellow" | "red") {
    if (tone === "red")
        return "text-danger";
    if (tone === "yellow")
        return "text-warning";
    return "text-orange-500";
}
function nextHoldName(index: number) {
    let value = index;
    let name = "";
    do {
        name = String.fromCharCode(65 + (value % 26)) + name;
        value = Math.floor(value / 26) - 1;
    } while (value >= 0);
    return name;
}
function formatPosTime(date: Date) {
    return new Intl.DateTimeFormat("en-GB", {
        hour: "2-digit",
        minute: "2-digit",
    }).format(date);
}
function formatBusinessDate(date: Date) {
    return new Intl.DateTimeFormat("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
    }).format(date);
}
function formatStaffTime(date: Date | null) {
    return date ? formatPosTime(date) : "-";
}
function calculateHours(start: Date | null, end: Date | null) {
    if (!start || !end)
        return 0;
    return Math.max(0, (end.getTime() - start.getTime()) / 3600000);
}
