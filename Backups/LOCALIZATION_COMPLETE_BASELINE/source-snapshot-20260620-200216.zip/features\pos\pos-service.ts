import { mockPosCustomers, mockPosProducts, mockPromotionBanners, mockQrBanks } from "@/features/pos/mock-data";
import type { PosCustomer, PosProduct, QrBank } from "@/features/pos/types";
import { isDemoMode } from "@/lib/demo-mode";
import { requireSession } from "@/lib/auth/session";
import { tenantFromSession } from "@/lib/db/write-context";
import { getPrismaPosSnapshot } from "@/features/pos/prisma-repository";

export async function getPosSnapshot(): Promise<{
  products: PosProduct[];
  taxInclusive: boolean;
  taxRatePercent: number;
  cashierName: string;
  branchName: string;
  branchId: string;
  warehouseId: string;
  customers: PosCustomer[];
  promotionBanners: string[];
  qrBanks: QrBank[];
}> {
  if (!isDemoMode()) {
    const snapshot = await getPrismaPosSnapshot(tenantFromSession(await requireSession()));
    return {
      ...snapshot,
      customers: mockPosCustomers,
      promotionBanners: mockPromotionBanners,
      qrBanks: mockQrBanks,
    };
  }

    return {
      branchId: "gobox-main-branch",
      customers: mockPosCustomers,
      products: mockPosProducts,
      promotionBanners: mockPromotionBanners,
      qrBanks: mockQrBanks,
      taxInclusive: false,
      taxRatePercent: 10,
      cashierName: "IGO Store Owner",
      branchName: "Main Branch",
      warehouseId: "gobox-default-warehouse",
    };
}
