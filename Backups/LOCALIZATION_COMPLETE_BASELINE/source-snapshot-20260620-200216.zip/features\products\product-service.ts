import {
  mockCategories,
  mockProductImages,
  mockProducts,
} from "@/features/products/mock-data";
import type { Category, MockProductImage, Product } from "@/features/products/types";
import { isDemoMode } from "@/lib/demo-mode";
import { requireSession } from "@/lib/auth/session";
import { tenantFromSession } from "@/lib/db/write-context";
import {
  getPrismaCategories,
  getPrismaProductById,
  getPrismaProductImages,
  getPrismaProducts,
} from "@/features/products/prisma-repository";

export async function getProducts(): Promise<Product[]> {
  if (!isDemoMode()) {
    return getPrismaProducts(tenantFromSession(await requireSession()));
  }

  return mockProducts;
}

export async function getProductById(productId: string): Promise<Product | null> {
  if (!isDemoMode()) {
    return getPrismaProductById(productId, tenantFromSession(await requireSession()));
  }

  return mockProducts.find((product) => product.id === productId) ?? null;
}

export async function getCategories(): Promise<Category[]> {
  if (!isDemoMode()) {
    return getPrismaCategories(tenantFromSession(await requireSession()));
  }

  return mockCategories;
}

export async function getMockProductImages(): Promise<MockProductImage[]> {
  if (!isDemoMode()) {
    return getPrismaProductImages();
  }

  return mockProductImages;
}
