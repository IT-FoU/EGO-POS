import { PosPageClient } from "@/features/pos/components/pos-page-client";
import { getPosSnapshot } from "@/features/pos/pos-service";

export default async function PosPage() {
  const { branchId, branchName, cashierName, customers, products, promotionBanners, qrBanks, taxInclusive, taxRatePercent, warehouseId } =
    await getPosSnapshot();

  return (
    <PosPageClient
      branchId={branchId}
      branchName={branchName}
      cashierName={cashierName}
      customers={customers}
      products={products}
      promotionBanners={promotionBanners}
      qrBanks={qrBanks}
      taxInclusive={taxInclusive}
      taxRatePercent={taxRatePercent}
      warehouseId={warehouseId}
    />
  );
}
