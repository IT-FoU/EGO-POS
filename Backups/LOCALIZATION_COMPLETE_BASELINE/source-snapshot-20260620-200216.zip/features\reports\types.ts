export type PeriodKey = "daily" | "weekly" | "monthly" | "yearly";

export type SalesMetric = {
  period: PeriodKey;
  label: string;
  revenueLak: number;
  profitLak: number;
  taxLak: number;
  transactions: number;
};

export type TrendPoint = {
  label: string;
  revenueLak: number;
  salesCount: number;
};

export type ProductReportRow = {
  productName: string;
  categoryName: string;
  quantitySold: number;
  revenueLak: number;
  profitLak: number;
};

export type PurchaseTrendPoint = {
  label: string;
  purchaseValueLak: number;
  orderCount: number;
};
