import type { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { compare } from "bcryptjs";
import { prisma } from "@/lib/db/prisma";
import { isDemoMode } from "@/lib/demo-mode";

const demoLoginUsers = [
  {
    activeBranchId: "gobox-main-branch",
    activeCompanyId: "gobox-company",
    activeCompanyName: "GO BOX",
    activeWarehouseId: "gobox-default-warehouse",
    email: "owner@igopos.local",
    id: "demo-owner-login",
    name: "IGO Store Owner",
    password: "AdminChangeMe123!",
    roles: ["Owner"],
    username: "igo-admin",
  },
  {
    activeBranchId: "gobox-main-branch",
    activeCompanyId: "gobox-company",
    activeCompanyName: "GO BOX",
    activeWarehouseId: "gobox-default-warehouse",
    email: "manager@igopos.local",
    id: "demo-manager-login",
    name: "IGO Store Manager",
    password: "Manager123!",
    roles: ["Manager"],
    username: "manager",
  },
  {
    activeBranchId: "gobox-main-branch",
    activeCompanyId: "gobox-company",
    activeCompanyName: "GO BOX",
    activeWarehouseId: "gobox-default-warehouse",
    email: "cashier@igopos.local",
    id: "demo-cashier-login",
    name: "IGO Store Cashier",
    password: "Cashier123!",
    roles: ["Cashier"],
    username: "cashier",
  },
] as const;

function authorizeDemoUser(username: string, password: string) {
  if (!isDemoMode()) {
    return null;
  }

  const demoUser = demoLoginUsers.find((user) => user.username === username || user.email === username);
  if (!demoUser) {
    return null;
  }
  if (demoUser.password !== password) {
    return false;
  }

  return {
    id: demoUser.id,
    name: demoUser.name,
    email: demoUser.email,
    username: demoUser.username,
    activeBranchId: demoUser.activeBranchId,
    activeWarehouseId: demoUser.activeWarehouseId,
    activeCompanyId: demoUser.activeCompanyId,
    activeCompanyName: demoUser.activeCompanyName,
    locale: "lo",
    roles: [...demoUser.roles],
  };
}

export const authOptions: NextAuthOptions = {
  session: {
    strategy: "jwt",
  },
  pages: {
    signIn: "/login",
  },
  providers: [
    CredentialsProvider({
      name: "Username and Password",
      credentials: {
        username: { label: "Username", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const username = credentials?.username?.trim();
        const password = credentials?.password;

        if (!username || !password) {
          return null;
        }

        const demoUser = authorizeDemoUser(username, password);
        if (demoUser) {
          return demoUser;
        }
        if (demoUser === false) {
          return null;
        }

        const user = await prisma.user.findFirst({
          where: {
            OR: [{ username }, { email: username }],
          },
          include: {
            companies: {
              where: { status: "active" },
              include: { company: true },
              take: 1,
            },
            roles: {
              include: { role: true },
            },
          },
        });

        if (!user) {
          return null;
        }

        if (user.status !== "active") {
          throw new Error("UserDisabled");
        }

        const isValidPassword = await compare(password, user.passwordHash);

        if (!isValidPassword) {
          await prisma.loginHistory.create({
            data: {
              userId: user.id,
              status: "failed",
            },
          });
          return null;
        }

        await prisma.loginHistory.create({
          data: {
            userId: user.id,
            status: "success",
          },
        });

        const activeCompany = user.companies[0]?.company;
        const activeBranch = activeCompany
          ? await prisma.branch.findFirst({
              orderBy: [{ isMainBranch: "desc" }, { createdAt: "asc" }],
              where: { companyId: activeCompany.id },
            })
          : null;
        const activeWarehouse = activeBranch
          ? await prisma.warehouse.findFirst({
              orderBy: { createdAt: "asc" },
              where: { branchId: activeBranch.id, companyId: activeCompany?.id },
            })
          : null;

        return {
          id: user.id,
          name: user.fullName,
          email: user.email,
          username: user.username,
          activeBranchId: activeBranch?.id,
          activeWarehouseId: activeWarehouse?.id,
          activeCompanyId: activeCompany?.id,
          activeCompanyName: activeCompany?.name,
          locale: user.preferredLocale,
          roles: user.roles.map((entry) => entry.role.name),
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.username = user.username;
        token.activeBranchId = user.activeBranchId;
        token.activeWarehouseId = user.activeWarehouseId;
        token.activeCompanyId = user.activeCompanyId;
        token.activeCompanyName = user.activeCompanyName;
        token.locale = user.locale;
        token.roles = user.roles;
      }

      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.sub ?? "";
        session.user.username = token.username;
        session.user.activeBranchId = token.activeBranchId;
        session.user.activeWarehouseId = token.activeWarehouseId;
        session.user.activeCompanyId = token.activeCompanyId;
        session.user.activeCompanyName = token.activeCompanyName;
        session.user.locale = token.locale;
        session.user.roles = token.roles;
      }

      return session;
    },
  },
};
