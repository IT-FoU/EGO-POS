import { notFound } from "next/navigation";
import { PromotionDetailClient } from "@/features/promotions/components/promotion-detail-client";
import {
  getPromotionDetail,
  getPromotions,
} from "@/features/promotions/promotion-service";

export async function generateStaticParams() {
  const promotions = await getPromotions();

  return promotions.map((promotion) => ({
    id: promotion.id,
  }));
}

export default async function PromotionDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const { categories, products, promotion, simulation } = await getPromotionDetail(id);

  if (!promotion || !simulation) {
    notFound();
  }

  return (
    <PromotionDetailClient
      categories={categories}
      products={products}
      promotion={promotion}
      simulation={simulation}
    />
  );
}
