import {
  mockSupplierPayments,
  mockSupplierPurchaseOrders,
  mockSupplierReceivings,
  mockSuppliers,
} from "@/features/suppliers/mock-data";
import type { Supplier, SupplierPayment, SupplierPurchaseOrder, SupplierReceiving } from "@/features/suppliers/types";
import { isDemoMode } from "@/lib/demo-mode";
import { requireSession } from "@/lib/auth/session";
import { tenantFromSession } from "@/lib/db/write-context";
import {
  getPrismaSupplierById,
  getPrismaSupplierDetail,
  getPrismaSuppliers,
  getPrismaSuppliersSnapshot,
} from "@/features/suppliers/prisma-repository";

export async function getSuppliersSnapshot(): Promise<{
  payments: SupplierPayment[];
  purchaseOrders: SupplierPurchaseOrder[];
  receivings: SupplierReceiving[];
  suppliers: Supplier[];
}> {
  if (!isDemoMode()) {
    return getPrismaSuppliersSnapshot(tenantFromSession(await requireSession()));
  }

  return {
    payments: mockSupplierPayments,
    purchaseOrders: mockSupplierPurchaseOrders,
    receivings: mockSupplierReceivings,
    suppliers: mockSuppliers,
  };
}

export async function getSuppliers(): Promise<Supplier[]> {
  if (!isDemoMode()) {
    return getPrismaSuppliers(tenantFromSession(await requireSession()));
  }

  return mockSuppliers;
}

export async function getSupplierById(supplierId: string): Promise<Supplier | undefined> {
  if (!isDemoMode()) {
    return getPrismaSupplierById(supplierId, tenantFromSession(await requireSession()));
  }

  return mockSuppliers.find((supplier) => supplier.id === supplierId);
}

export async function getSupplierDetail(supplierId: string): Promise<{
  payments: SupplierPayment[];
  purchaseOrders: SupplierPurchaseOrder[];
  receivings: SupplierReceiving[];
  supplier: Supplier | undefined;
}> {
  if (!isDemoMode()) {
    return getPrismaSupplierDetail(supplierId, tenantFromSession(await requireSession()));
  }

  const supplier = await getSupplierById(supplierId);

  return {
    payments: mockSupplierPayments.filter((payment) => payment.supplierId === supplierId),
    purchaseOrders: mockSupplierPurchaseOrders.filter(
      (purchaseOrder) => purchaseOrder.supplierId === supplierId,
    ),
    receivings: mockSupplierReceivings.filter(
      (receiving) => receiving.supplierId === supplierId,
    ),
    supplier,
  };
}
