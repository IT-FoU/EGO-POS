import { notFound } from "next/navigation";
import { ProductForm } from "@/features/products/components/product-form";
import {
  getCategories,
  getMockProductImages,
  getProductById,
  getProducts,
} from "@/features/products/product-service";

export async function generateStaticParams() {
  const products = await getProducts();

  return products.map((product) => ({
    productId: product.id,
  }));
}

export default async function EditProductPage({
  params,
}: {
  params: Promise<{ productId: string }>;
}) {
  const { productId } = await params;
  const [product, categories, images] = await Promise.all([
    getProductById(productId),
    getCategories(),
    getMockProductImages(),
  ]);

  if (!product) {
    notFound();
  }

  return (
    <ProductForm
      mode="edit"
      product={product}
      categories={categories}
      images={images}
    />
  );
}
