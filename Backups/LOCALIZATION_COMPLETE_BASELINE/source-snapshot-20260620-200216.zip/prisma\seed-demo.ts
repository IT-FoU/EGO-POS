import { hash } from "bcryptjs";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { mockCustomers, mockMembershipLevels } from "../features/customers/mock-data";
import { mockInventoryItems, mockWarehouses } from "../features/inventory/mock-data";
import { mockProducts, mockCategories } from "../features/products/mock-data";
import { mockPromotions } from "../features/promotions/mock-data";
import { mockSupplierPayments, mockSupplierPurchaseOrders, mockSupplierReceivings, mockSuppliers } from "../features/suppliers/mock-data";
import { databaseUrl } from "../lib/db/database-url";

const prisma = new PrismaClient({
  adapter: new PrismaPg({ connectionString: databaseUrl }),
});

const companyId = "gobox-company";
const branchId = "gobox-main-branch";
const ownerId = "gobox-owner";

async function seedFoundation(db: any) {
  const superAdminPasswordHash = await hash("AdminChangeMe123!", 12);

  await db.superAdmin.upsert({
    create: {
      email: "admin@igopos.local",
      passwordHash: superAdminPasswordHash,
      status: "active",
      username: "igo-admin",
    },
    update: {
      email: "admin@igopos.local",
      passwordHash: superAdminPasswordHash,
      status: "active",
    },
    where: { id: ownerId },
  });

  const plan = await db.plan.upsert({
    create: { planName: "Free" },
    update: {},
    where: { planName: "Free" },
  });
  const owner = await db.user.upsert({
    create: {
      email: "owner@igopos.local",
      fullName: "IGO Store Owner",
      id: ownerId,
      passwordHash: await hash("AdminChangeMe123!", 12),
      preferredLocale: "lo",
      status: "active",
      username: "igo-admin",
    },
    update: {
      passwordHash: await hash("AdminChangeMe123!", 12),
      status: "active",
    },
    where: { username: "igo-admin" },
  });
  const company = await db.company.upsert({
    create: {
      baseCurrency: "LAK",
      defaultLocale: "lo",
      id: companyId,
      name: "Go BOX",
      ownerUserId: owner.id,
      planId: plan.id,
    },
    update: { ownerUserId: owner.id, planId: plan.id },
    where: { id: companyId },
  });
  const branch = await db.branch.upsert({
    create: { companyId: company.id, id: branchId, isMainBranch: true, name: "Go BOX Main Branch" },
    update: {},
    where: { id: branchId },
  });

  await db.companyUser.upsert({
    create: { companyId: company.id, isOwner: true, userId: owner.id },
    update: { isOwner: true, status: "active" },
    where: { companyId_userId: { companyId: company.id, userId: owner.id } },
  });

  const ownerRole = await db.role.upsert({
    create: { companyId: company.id, description: "Full access for store owner", isSystem: true, name: "Owner" },
    update: {},
    where: { companyId_name: { companyId: company.id, name: "Owner" } },
  });
  const managerRole = await db.role.upsert({
    create: { companyId: company.id, description: "Manager access with configurable permissions", isSystem: true, name: "Manager" },
    update: {},
    where: { companyId_name: { companyId: company.id, name: "Manager" } },
  });
  const cashierRole = await db.role.upsert({
    create: { companyId: company.id, description: "Cashier POS access", isSystem: true, name: "Cashier" },
    update: {},
    where: { companyId_name: { companyId: company.id, name: "Cashier" } },
  });

  await db.userRole.upsert({
    create: { companyId: company.id, roleId: ownerRole.id, userId: owner.id },
    update: { companyId: company.id },
    where: { userId_roleId: { roleId: ownerRole.id, userId: owner.id } },
  });

  const staffUsers = [
    { email: "manager@igopos.local", fullName: "IGO Store Manager", password: "Manager123!", role: managerRole, username: "manager" },
    { email: "cashier@igopos.local", fullName: "IGO Store Cashier", password: "Cashier123!", role: cashierRole, username: "cashier" },
  ];

  for (const staff of staffUsers) {
    const user = await db.user.upsert({
      create: {
        email: staff.email,
        fullName: staff.fullName,
        passwordHash: await hash(staff.password, 12),
        preferredLocale: "lo",
        status: "active",
        username: staff.username,
      },
      update: {
        passwordHash: await hash(staff.password, 12),
        status: "active",
      },
      where: { username: staff.username },
    });
    await db.companyUser.upsert({
      create: { companyId: company.id, isOwner: false, status: "active", userId: user.id },
      update: { status: "active" },
      where: { companyId_userId: { companyId: company.id, userId: user.id } },
    });
    await db.userRole.upsert({
      create: { companyId: company.id, roleId: staff.role.id, userId: user.id },
      update: { companyId: company.id },
      where: { userId_roleId: { roleId: staff.role.id, userId: user.id } },
    });
  }

  return { branch, company, owner };
}

async function seedWarehouses(db: any) {
  for (const warehouse of mockWarehouses) {
    await db.warehouse.upsert({
      create: {
        branchId,
        companyId,
        id: warehouse.id,
        name: warehouse.name,
        type: warehouse.type,
      },
      update: { name: warehouse.name, type: warehouse.type },
      where: { id: warehouse.id },
    });
  }
}

async function seedCustomers(db: any) {
  for (const level of mockMembershipLevels) {
    await db.membershipLevel.upsert({
      create: {
        companyId,
        discountPercent: level.discountPercent,
        id: level.id,
        minSpendLak: level.minSpendLak,
        name: level.name,
      },
      update: {
        discountPercent: level.discountPercent,
        minSpendLak: level.minSpendLak,
      },
      where: { id: level.id },
    });
  }

  for (const customer of mockCustomers) {
    const level = mockMembershipLevels.find((entry) => entry.name === customer.membershipLevel);
    await db.customer.upsert({
      create: {
        address: customer.address,
        birthday: customer.birthday ? new Date(customer.birthday) : undefined,
        companyId,
        creditLimit: customer.creditLimitLak,
        customerCode: customer.customerCode,
        email: customer.email,
        fullName: customer.fullName,
        id: customer.id,
        membershipLevelId: level?.id,
        notes: customer.notes,
        openingBalance: customer.openingBalanceLak,
        outstandingBalance: customer.outstandingBalanceLak,
        phone: customer.phone,
        pointsBalance: customer.earnedPoints - customer.redeemedPoints,
        status: customer.status,
        totalSpent: customer.totalPurchasesLak,
      },
      update: {},
      where: { id: customer.id },
    });
  }
}

async function seedSuppliersAndCatalog(db: any) {
  for (const supplier of mockSuppliers) {
    await db.supplier.upsert({
      create: {
        address: supplier.address,
        averageDeliveryDays: supplier.averageDeliveryDays,
        companyId,
        companyName: supplier.companyName,
        contactPerson: supplier.contactPerson,
        creditLimit: supplier.creditLimitLak,
        creditTerms: supplier.creditTerms,
        email: supplier.email,
        id: supplier.id,
        name: supplier.companyName,
        note: supplier.notes,
        openingBalance: supplier.openingBalanceLak,
        outstandingBalance: supplier.outstandingBalanceLak,
        phone: supplier.phone,
        status: supplier.status,
        supplierCode: supplier.supplierCode,
        taxNumber: supplier.taxNumber,
      },
      update: {},
      where: { id: supplier.id },
    });
  }

  for (const category of mockCategories) {
    await db.category.upsert({
      create: {
        companyId,
        id: category.id,
        nameEn: category.nameEn,
        nameLo: category.nameLo,
      },
      update: { nameEn: category.nameEn, nameLo: category.nameLo },
      where: { id: category.id },
    });
  }

  const brandNames = Array.from(new Set(mockProducts.map((product) => product.brandName).filter(Boolean)));
  for (const brandName of brandNames) {
    await db.brand.upsert({
      create: { companyId, name: brandName },
      update: {},
      where: { companyId_name: { companyId, name: brandName } },
    });
  }

  for (const product of mockProducts) {
    const brand = await db.brand.findUnique({ where: { companyId_name: { companyId, name: product.brandName } } });
    const supplier = mockSuppliers.find((entry) => entry.companyName === product.supplierName);
    await db.product.upsert({
      create: {
        barcode: product.barcode,
        brandId: brand?.id,
        categoryId: product.categoryId,
        companyId,
        costPriceLak: product.costPriceLak,
        description: product.description,
        id: product.id,
        minStock: product.minStock,
        nameEn: product.nameEn,
        nameLo: product.nameLo,
        productCode: product.productCode,
        sellingPriceLak: product.sellingPriceLak,
        sku: product.sku,
        status: product.status,
        supplierId: supplier?.id,
        tags: product.tags ?? [],
      },
      update: {},
      where: { id: product.id },
    });

    for (const unit of product.units) {
      await db.productUnit.upsert({
        create: {
          barcode: unit.barcode,
          conversionQty: unit.conversionQty,
          id: unit.id,
          isBaseUnit: unit.isBaseUnit,
          productId: product.id,
          sellingPriceLak: unit.sellingPriceLak,
          unitName: unit.unitName,
        },
        update: {},
        where: { id: unit.id },
      });
    }
  }
}

async function seedInventory(db: any) {
  for (const item of mockInventoryItems) {
    const product = await db.product.findFirst({ where: { sku: item.sku } });
    if (!product) continue;

    await db.inventoryBalance.upsert({
      create: {
        companyId,
        productId: product.id,
        quantity: item.quantity,
        warehouseId: item.warehouseId,
      },
      update: { quantity: item.quantity },
      where: { warehouseId_productId: { productId: product.id, warehouseId: item.warehouseId } },
    });

    await db.inventoryLot.create({
      data: {
        companyId,
        expiryDate: item.expiryDate ? new Date(item.expiryDate) : undefined,
        lotNumber: `OPEN-${item.sku}`,
        productId: product.id,
        quantity: item.quantity,
        receivedAt: new Date(),
        warehouseId: item.warehouseId,
      },
    });
  }
}

async function seedPromotions(db: any) {
  for (const promotion of mockPromotions) {
    await db.promotion.upsert({
      create: {
        id: promotion.id,
        categories: { create: promotion.applicableCategoryIds.map((categoryId) => ({ categoryId })) },
        companyId,
        description: promotion.description,
        discountAmountLak: promotion.discountAmountLak,
        discountPercent: promotion.discountPercent,
        endDate: new Date(promotion.endDate),
        membershipLevels: {
          create: promotion.membershipLevels
            .map((name) => mockMembershipLevels.find((level) => level.name === name)?.id)
            .filter(Boolean)
            .map((membershipLevelId) => ({ membershipLevelId })),
        },
        priority: promotion.priority,
        products: { create: promotion.applicableProductIds.map((productId) => ({ productId })) },
        promotionCode: promotion.promotionCode,
        promotionName: promotion.promotionName,
        promotionType: promotion.type,
        startDate: new Date(promotion.startDate),
        status: promotion.status,
        totalDiscountLak: promotion.totalDiscountLak,
        usageCount: promotion.usageCount,
      },
      update: {},
      where: { id: promotion.id },
    });
  }
}

async function seedPurchasingHistory(db: any, actorUserId: string) {
  for (const order of mockSupplierPurchaseOrders) {
    await db.purchase.upsert({
      create: {
        balanceAmount: 0,
        companyId,
        id: order.id,
        purchaseNo: order.purchaseNo,
        status: order.status,
        subtotal: order.totalLak,
        supplierId: order.supplierId,
        totalAmount: order.totalLak,
        warehouseId: mockWarehouses[0]?.id ?? "wh-main",
      },
      update: {},
      where: { id: order.id },
    });
  }

  for (const receiving of mockSupplierReceivings) {
    const purchase = await db.purchase.findFirst({ where: { purchaseNo: receiving.purchaseNo } });
    if (!purchase) continue;
    await db.goodsReceipt.upsert({
      create: {
        companyId,
        id: receiving.id,
        purchaseId: purchase.id,
        receiptNo: receiving.receiveNo,
        receivedBy: actorUserId,
        status: receiving.status,
        warehouseId: mockWarehouses[0]?.id ?? "wh-main",
      },
      update: {},
      where: { id: receiving.id },
    });
  }

  for (const payment of mockSupplierPayments) {
    const purchase = await db.purchase.findFirst({ where: { supplierId: payment.supplierId } });
    if (!purchase) continue;
    await db.purchasePayment.create({
      data: {
        amount: payment.amountLak,
        note: payment.note,
        paymentDate: new Date(payment.paymentDate),
        paymentMethod: payment.method === "bank" ? "transfer" : payment.method,
        purchaseId: purchase.id,
      },
    });
  }
}

async function main() {
  await prisma.$transaction(
    async (tx: any) => {
      const { owner } = await seedFoundation(tx);
      await seedWarehouses(tx);
      await seedCustomers(tx);
      await seedSuppliersAndCatalog(tx);
      await seedInventory(tx);
      await seedPromotions(tx);
      await seedPurchasingHistory(tx, owner.id);
      await tx.auditLog.create({
        data: {
          action: "seed_demo",
          companyId,
          module: "system",
          newData: { message: "Go BOX demo data seeded" },
          userId: owner.id,
        },
      });
    },
    { timeout: 60000 },
  );

  console.info("Go BOX demo seed complete. Owner: igo-admin / AdminChangeMe123!. Manager: manager / Manager123!. Cashier: cashier / Cashier123!.");
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
