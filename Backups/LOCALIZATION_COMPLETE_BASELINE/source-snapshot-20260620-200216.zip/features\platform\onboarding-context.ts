import type { BusinessTemplateType } from "@/features/platform/platform-data";

export type OnboardingBusinessContext = {
  activeBusinessId: string;
  activeTenantId: string;
  currency: string;
  defaultModules: string[];
  email: string;
  language: string;
  logoFileName?: string;
  logoUrl?: string;
  ownerName: string;
  phoneNumber: string;
  setupCompletedAt: string;
  setupStatus: "complete";
  storeAddress?: string;
  storeName: string;
  templateId: BusinessTemplateType;
  template: BusinessTemplateType;
  businessTemplateId: BusinessTemplateType;
  businessType: BusinessTemplateType;
  templateName: string;
};

export type OnboardingSetupDraft = {
  businessTemplateId: BusinessTemplateType;
  businessType: BusinessTemplateType;
  defaultModules: string[];
  locale: string;
  selectedAt: string;
  setupStatus: "draft";
  templateName: string;
};

const BUSINESS_KEY = "igo-pos:onboarding-business";
const COMPLETE_KEY = "igo-pos:onboarding-complete";
const DRAFT_KEY = "igo-pos:onboarding-draft";
const TEMPLATE_KEY = "igo-pos:onboarding-template";

export function getTemplateEntryPath(template: BusinessTemplateType) {
  return template === "mini_mart" ? "/dashboard" : `/template-shell/${template}`;
}

export function getStoredBusinessContext() {
  if (typeof window === "undefined") {
    return null;
  }

  const isComplete = window.localStorage.getItem(COMPLETE_KEY) === "true";
  const rawBusiness = window.localStorage.getItem(BUSINESS_KEY);

  if (!isComplete || !rawBusiness) {
    return null;
  }

  try {
    return JSON.parse(rawBusiness) as OnboardingBusinessContext;
  } catch {
    return null;
  }
}

export function getStoredEntryPath() {
  const business = getStoredBusinessContext();
  return business ? getTemplateEntryPath(business.template) : "/businesses";
}

export function getStoredSetupDraft() {
  if (typeof window === "undefined") {
    return null;
  }

  const rawDraft = window.localStorage.getItem(DRAFT_KEY);

  if (!rawDraft) {
    return null;
  }

  try {
    return JSON.parse(rawDraft) as OnboardingSetupDraft;
  } catch {
    return null;
  }
}

export function saveSelectedTemplateDraft(draft: OnboardingSetupDraft) {
  window.localStorage.setItem(TEMPLATE_KEY, draft.businessTemplateId);
  window.localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
}

export function completeOnboarding(business: OnboardingBusinessContext) {
  window.localStorage.setItem(BUSINESS_KEY, JSON.stringify(business));
  window.localStorage.setItem(COMPLETE_KEY, "true");
}

export function createLocalId(prefix: string) {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return `${prefix}_${crypto.randomUUID()}`;
  }

  return `${prefix}_${Date.now()}`;
}
