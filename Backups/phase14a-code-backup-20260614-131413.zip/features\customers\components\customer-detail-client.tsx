import Link from "next/link";
import { ArrowLeft, CircleDollarSign, CreditCard, Gift, Phone, ReceiptText, User } from "lucide-react";
import type {
  Customer,
  CustomerPayment,
  CustomerPurchase,
} from "@/features/customers/types";
import { CustomerStatusBadge } from "@/features/customers/components/customer-status-badge";
import { MembershipBadge } from "@/features/customers/components/membership-badge";
import { calculateAvailablePoints, formatLak } from "@/features/customers/format";

export function CustomerDetailClient({
  customer,
  payments,
  purchases,
}: {
  customer: Customer;
  payments: CustomerPayment[];
  purchases: CustomerPurchase[];
}) {
  const availablePoints = calculateAvailablePoints(
    customer.earnedPoints,
    customer.redeemedPoints,
  );
  const remainingCredit = Math.max(
    customer.creditLimitLak - customer.outstandingBalanceLak,
    0,
  );

  return (
    <div className="flex flex-col gap-6">
      <section className="rounded-lg border border-border bg-card p-6">
        <Link
          className="inline-flex items-center gap-2 text-sm text-muted-foreground transition hover:text-foreground"
          href="/customers"
        >
          <ArrowLeft aria-hidden="true" />
          Back to customers
        </Link>
        <div className="mt-5 flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
          <div className="flex items-start gap-4">
            <div className="grid size-14 shrink-0 place-items-center rounded-md bg-primary/10 text-primary">
              <User aria-hidden="true" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-3xl font-semibold">{customer.fullName}</h1>
                <MembershipBadge level={customer.membershipLevel} />
                <CustomerStatusBadge status={customer.status} />
              </div>
              <p className="mt-2 font-mono text-sm text-muted-foreground">
                {customer.customerCode}
              </p>
              <div className="mt-4 grid gap-2 text-sm text-muted-foreground md:grid-cols-2">
                <span className="inline-flex items-center gap-2">
                  <Phone aria-hidden="true" />
                  {customer.phone}
                </span>
                <span>{customer.email}</span>
                <span className="md:col-span-2">{customer.address}</span>
              </div>
            </div>
          </div>
          <div className="rounded-md border border-border bg-background p-4 text-sm lg:w-80">
            <div className="text-muted-foreground">Notes</div>
            <p className="mt-2 leading-6">{customer.notes}</p>
          </div>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <Metric icon={ReceiptText} label="Total purchases" value={`${formatLak(customer.totalPurchasesLak)} LAK`} />
        <Metric icon={Gift} label="Current points" value={formatLak(availablePoints)} />
        <Metric icon={CircleDollarSign} label="Outstanding balance" value={`${formatLak(customer.outstandingBalanceLak)} LAK`} />
        <Metric icon={CreditCard} label="Remaining credit" value={`${formatLak(remainingCredit)} LAK`} />
      </section>

      <section className="grid gap-6 xl:grid-cols-[360px_1fr]">
        <aside className="flex flex-col gap-6">
          <section className="rounded-lg border border-border bg-card p-5">
            <h2 className="text-lg font-semibold">Loyalty points</h2>
            <dl className="mt-5 flex flex-col gap-4 text-sm">
              <Summary label="Earned points" value={formatLak(customer.earnedPoints)} />
              <Summary label="Redeemed points" value={formatLak(customer.redeemedPoints)} />
              <Summary label="Available points" value={formatLak(availablePoints)} />
              <Summary label="Calculation" value="1 point / 10,000 LAK spent" />
            </dl>
          </section>

          <section className="rounded-lg border border-border bg-card p-5">
            <h2 className="text-lg font-semibold">Customer credit</h2>
            <dl className="mt-5 flex flex-col gap-4 text-sm">
              <Summary label="Credit limit" value={`${formatLak(customer.creditLimitLak)} LAK`} />
              <Summary label="Outstanding balance" value={`${formatLak(customer.outstandingBalanceLak)} LAK`} />
              <Summary label="Remaining credit" value={`${formatLak(remainingCredit)} LAK`} />
              <Summary label="Opening balance" value={`${formatLak(customer.openingBalanceLak)} LAK`} />
            </dl>
          </section>
        </aside>

        <div className="flex flex-col gap-6">
          <section className="rounded-lg border border-border bg-card p-5">
            <h2 className="text-lg font-semibold">Purchase history</h2>
            <div className="mt-5 overflow-x-auto">
              <table className="w-full min-w-[760px] text-left text-sm">
                <thead className="border-b border-border text-xs uppercase text-muted-foreground">
                  <tr>
                    <th className="px-3 py-3">Sale no</th>
                    <th className="px-3 py-3">Date</th>
                    <th className="px-3 py-3">Payment</th>
                    <th className="px-3 py-3 text-right">Total</th>
                    <th className="px-3 py-3 text-right">Points earned</th>
                  </tr>
                </thead>
                <tbody>
                  {purchases.map((purchase) => (
                    <tr className="border-b border-border last:border-b-0" key={purchase.id}>
                      <td className="px-3 py-3 font-mono">{purchase.saleNo}</td>
                      <td className="px-3 py-3">{purchase.saleDate}</td>
                      <td className="px-3 py-3 capitalize">{purchase.paymentType}</td>
                      <td className="px-3 py-3 text-right font-semibold">{formatLak(purchase.totalLak)} LAK</td>
                      <td className="px-3 py-3 text-right">{formatLak(purchase.pointsEarned)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {purchases.length === 0 ? (
              <p className="mt-4 text-sm text-muted-foreground">No mock purchases for this customer.</p>
            ) : null}
          </section>

          <section className="rounded-lg border border-border bg-card p-5">
            <h2 className="text-lg font-semibold">Payment history</h2>
            <div className="mt-5 overflow-x-auto">
              <table className="w-full min-w-[760px] text-left text-sm">
                <thead className="border-b border-border text-xs uppercase text-muted-foreground">
                  <tr>
                    <th className="px-3 py-3">Payment no</th>
                    <th className="px-3 py-3">Date</th>
                    <th className="px-3 py-3">Method</th>
                    <th className="px-3 py-3">Note</th>
                    <th className="px-3 py-3 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {payments.map((payment) => (
                    <tr className="border-b border-border last:border-b-0" key={payment.id}>
                      <td className="px-3 py-3 font-mono">{payment.paymentNo}</td>
                      <td className="px-3 py-3">{payment.paymentDate}</td>
                      <td className="px-3 py-3 capitalize">{payment.method}</td>
                      <td className="px-3 py-3 text-muted-foreground">{payment.note}</td>
                      <td className="px-3 py-3 text-right font-semibold">{formatLak(payment.amountLak)} LAK</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {payments.length === 0 ? (
              <p className="mt-4 text-sm text-muted-foreground">No mock payments for this customer.</p>
            ) : null}
          </section>
        </div>
      </section>
    </div>
  );
}

function Metric({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof ReceiptText;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-lg border border-border bg-card p-5">
      <div className="flex items-center justify-between gap-4">
        <div>
          <div className="text-sm text-muted-foreground">{label}</div>
          <div className="mt-2 text-2xl font-semibold">{value}</div>
        </div>
        <div className="grid size-11 place-items-center rounded-md bg-primary/10 text-primary">
          <Icon aria-hidden="true" />
        </div>
      </div>
    </div>
  );
}

function Summary({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="mt-1 font-semibold">{value}</dd>
    </div>
  );
}
