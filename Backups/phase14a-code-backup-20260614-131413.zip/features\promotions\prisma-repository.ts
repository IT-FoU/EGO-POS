import { prisma } from "@/lib/db/prisma";
import type { TenantContext } from "@/lib/db/write-context";
import { numberValue, optionalString, stringValue, withTenantTransaction } from "@/lib/db/write-context";
import { getPrismaCategories, getPrismaProducts } from "@/features/products/prisma-repository";
import { getPrismaCustomersSnapshot } from "@/features/customers/prisma-repository";
import { mapPrismaPromotion } from "@/features/promotions/dto-mapper";
import type { Promotion, PromotionSimulation } from "@/features/promotions/types";

const db = prisma as any;

export async function getPrismaPromotionsSnapshot() {
  const [promotions, products, categories, customers] = await Promise.all([
    db.promotion.findMany({
      include: {
        categories: true,
        membershipLevels: { include: { membershipLevel: true } },
        products: true,
      },
      orderBy: [{ priority: "desc" }, { startDate: "desc" }],
    }),
    getPrismaProducts(),
    getPrismaCategories(),
    getPrismaCustomersSnapshot(),
  ]);

  return {
    categories,
    membershipLevels: customers.levels,
    products,
    promotions: promotions.map(mapPrismaPromotion),
  };
}

export async function getPrismaPromotions() {
  const { promotions } = await getPrismaPromotionsSnapshot();
  return promotions;
}

export async function getPrismaPromotionById(promotionId: string) {
  const promotion = await db.promotion.findUnique({
    include: {
      categories: true,
      membershipLevels: { include: { membershipLevel: true } },
      products: true,
    },
    where: { id: promotionId },
  });

  return promotion ? mapPrismaPromotion(promotion) : undefined;
}

export async function getPrismaPromotionDetail(promotionId: string) {
  const [snapshot, promotion] = await Promise.all([
    getPrismaPromotionsSnapshot(),
    getPrismaPromotionById(promotionId),
  ]);

  return {
    categories: snapshot.categories,
    membershipLevels: snapshot.membershipLevels,
    products: snapshot.products,
    promotion,
    simulation: promotion ? emptyPromotionSimulation(promotion) : undefined,
  };
}

function emptyPromotionSimulation(promotion: Promotion): PromotionSimulation {
  return {
    cartSubtotalLak: 0,
    discountLak: promotion.discountAmountLak ?? 0,
    finalTotalLak: 0,
    lineResults: [],
  };
}

export async function createPrismaPromotion(input: {
  applicableCategoryIds?: string[];
  applicableProductIds?: string[];
  description?: string;
  discountAmountLak?: number;
  discountPercent?: number;
  endDate: string;
  membershipLevelIds?: string[];
  priority?: number;
  promotionCode?: string;
  promotionName: string;
  promotionType?: string;
  startDate: string;
  status?: string;
}, tenant: TenantContext) {
  return withTenantTransaction({
    action: "create",
    module: "promotions",
    newData: input,
    tenant,
    write: async (tx) => tx.promotion.create({
      data: {
        categories: { create: (input.applicableCategoryIds ?? []).map((categoryId) => ({ categoryId })) },
        companyId: tenant.companyId,
        description: optionalString(input.description),
        discountAmountLak: input.discountAmountLak === undefined ? undefined : numberValue(input.discountAmountLak),
        discountPercent: input.discountPercent === undefined ? undefined : numberValue(input.discountPercent),
        endDate: new Date(input.endDate),
        membershipLevels: { create: (input.membershipLevelIds ?? []).map((membershipLevelId) => ({ membershipLevelId })) },
        priority: numberValue(input.priority),
        products: { create: (input.applicableProductIds ?? []).map((productId) => ({ productId })) },
        promotionCode: optionalString(input.promotionCode),
        promotionName: stringValue(input.promotionName),
        promotionType: input.promotionType ?? "percentage",
        startDate: new Date(input.startDate),
        status: input.status ?? "active",
      },
    }),
  });
}

export async function updatePrismaPromotion(promotionId: string, input: Record<string, unknown>, tenant: TenantContext) {
  return withTenantTransaction({
    action: "update",
    module: "promotions",
    newData: { promotionId, ...input },
    tenant,
    write: async (tx) => {
      const existing = await tx.promotion.findFirstOrThrow({ where: { companyId: tenant.companyId, id: promotionId } });
      return tx.promotion.update({ data: input, where: { id: existing.id } });
    },
  });
}

export async function archivePrismaPromotion(promotionId: string, tenant: TenantContext) {
  return updatePrismaPromotion(promotionId, { status: "inactive", isActive: false }, tenant);
}
