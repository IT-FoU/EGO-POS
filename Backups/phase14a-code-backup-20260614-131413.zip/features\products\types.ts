export type ProductStatus = "active" | "inactive" | "draft" | "deleted";

export type ProductUnit = {
  id: string;
  unitName: string;
  conversionQty: number;
  barcode: string;
  sellingPriceLak: number;
  isBaseUnit: boolean;
};

export type Product = {
  id: string;
  imageUrl?: string;
  productCode?: string;
  barcode: string;
  sku: string;
  nameLo: string;
  nameEn: string;
  description?: string;
  tags?: string[];
  categoryId: string;
  categoryName: string;
  supplierName: string;
  brandName: string;
  costPriceLak: number;
  sellingPriceLak: number;
  minStock: number;
  status: ProductStatus;
  units: ProductUnit[];
  updatedAt: string;
};

export type Category = {
  id: string;
  nameLo: string;
  nameEn: string;
  parentName?: string;
  productCount: number;
  status: "active" | "inactive";
};

export type MockProductImage = {
  id: string;
  title: string;
  keyword: string;
  color: string;
};
