import { getCustomers } from "@/features/customers/customer-service";
import { createPrismaCustomer } from "@/features/customers/prisma-repository";
import { runWrite } from "@/lib/api/write-response";

export async function GET() {
  return Response.json({ data: await getCustomers(), ok: true });
}

export async function POST(request: Request) {
  return runWrite((tenant, body) => createPrismaCustomer(body, tenant), request);
}
