"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  CircleDollarSign,
  ClipboardList,
  PackageCheck,
  Plus,
  Search,
  Truck,
} from "lucide-react";
import type {
  PurchaseOrder,
  Supplier,
  SupplierPayable,
} from "@/features/purchasing/types";
import { formatMoney } from "@/features/purchasing/format";
import { PayableStatusBadge, PurchaseStatusBadge, SupplierStatusBadge } from "@/features/purchasing/components/purchasing-status";

export function PurchasingPageClient({
  purchaseOrders,
  suppliers,
  payables,
}: {
  purchaseOrders: PurchaseOrder[];
  suppliers: Supplier[];
  payables: SupplierPayable[];
}) {
  const [query, setQuery] = useState("");

  const filteredOrders = useMemo(() => {
    const normalized = query.toLowerCase();
    return purchaseOrders.filter(
      (order) =>
        order.purchaseNo.toLowerCase().includes(normalized) ||
        order.supplierName.toLowerCase().includes(normalized),
    );
  }, [purchaseOrders, query]);

  const outstandingLak = payables.reduce((total, payable) => total + payable.balanceAmountLak, 0);
  const orderedCount = purchaseOrders.filter((order) => order.status === "ordered").length;
  const partialCount = purchaseOrders.filter((order) => order.status === "partial").length;

  return (
    <div className="flex flex-col gap-6">
      <section className="rounded-lg border border-border bg-card p-6">
        <div className="flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between">
          <div>
            <p className="text-sm font-medium text-primary">Purchasing Management</p>
            <h1 className="mt-2 text-3xl font-semibold">Purchasing / ຈັດຊື້</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">
              Supplier purchasing workspace for purchase orders, receiving,
              supplier credit, currencies, exchange rates, and warehouses. Mock
              data only.
            </p>
          </div>
          <div className="flex flex-col gap-2 sm:flex-row">
            <Link
              className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground transition hover:opacity-90"
              href="/purchasing/new"
            >
              <Plus aria-hidden="true" />
              New PO
            </Link>
            <Link
              className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-border px-4 text-sm font-semibold transition hover:border-primary"
              href="/purchasing/receiving"
            >
              <PackageCheck aria-hidden="true" />
              Receive
            </Link>
          </div>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <SummaryCard icon={Truck} label="Active suppliers" value={String(suppliers.filter((supplier) => supplier.status === "active").length)} />
        <SummaryCard icon={ClipboardList} label="Open purchase orders" value={String(orderedCount + partialCount)} />
        <SummaryCard icon={PackageCheck} label="Partial receives" value={String(partialCount)} />
        <SummaryCard icon={CircleDollarSign} label="Outstanding balance" value={formatMoney(outstandingLak, "LAK")} />
      </section>

      <nav className="flex flex-wrap gap-2">
        <Link className="inline-flex h-10 items-center gap-2 rounded-md border border-border px-3 text-sm font-semibold hover:border-primary" href="/purchasing/suppliers">
          <Truck aria-hidden="true" />
          Suppliers
        </Link>
        <Link className="inline-flex h-10 items-center gap-2 rounded-md border border-border px-3 text-sm font-semibold hover:border-primary" href="/purchasing/new">
          <Plus aria-hidden="true" />
          Purchase Order
        </Link>
        <Link className="inline-flex h-10 items-center gap-2 rounded-md border border-border px-3 text-sm font-semibold hover:border-primary" href="/purchasing/receiving">
          <PackageCheck aria-hidden="true" />
          Receiving
        </Link>
        <Link className="inline-flex h-10 items-center gap-2 rounded-md border border-border px-3 text-sm font-semibold hover:border-primary" href="/purchasing/payables">
          <CircleDollarSign aria-hidden="true" />
          Payables
        </Link>
      </nav>

      <section className="grid gap-6 xl:grid-cols-[1fr_360px]">
        <div className="rounded-lg border border-border bg-card p-5">
          <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-lg font-semibold">Purchase orders</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Multi-currency order list with LAK exchange rate visibility.
              </p>
            </div>
            <label className="relative w-full md:w-72">
              <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
              <input
                className="field-input pl-10"
                placeholder="Search PO or supplier"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
              />
            </label>
          </div>
          <div className="mt-5 overflow-x-auto">
            <table className="w-full min-w-[860px] text-left text-sm">
              <thead className="border-b border-border text-xs uppercase text-muted-foreground">
                <tr>
                  <th className="px-3 py-3">PO</th>
                  <th className="px-3 py-3">Supplier</th>
                  <th className="px-3 py-3">Warehouse</th>
                  <th className="px-3 py-3">Currency</th>
                  <th className="px-3 py-3">Subtotal</th>
                  <th className="px-3 py-3">Status</th>
                  <th className="px-3 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredOrders.map((order) => (
                  <tr className="border-b border-border last:border-b-0" key={order.id}>
                    <td className="px-3 py-3 font-mono font-semibold">{order.purchaseNo}</td>
                    <td className="px-3 py-3">{order.supplierName}</td>
                    <td className="px-3 py-3 text-muted-foreground">{order.warehouseName}</td>
                    <td className="px-3 py-3">
                      {order.currency} x {order.exchangeRate.toLocaleString("en-US")}
                    </td>
                    <td className="px-3 py-3 font-semibold">{formatMoney(order.subtotal, order.currency)}</td>
                    <td className="px-3 py-3"><PurchaseStatusBadge status={order.status} /></td>
                    <td className="px-3 py-3 text-right">
                      <Link className="inline-flex items-center gap-2 text-sm font-semibold text-primary" href="/purchasing/receiving">
                        Receive <ArrowRight aria-hidden="true" />
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <aside className="flex flex-col gap-6">
          <section className="rounded-lg border border-border bg-card p-5">
            <h2 className="text-lg font-semibold">Supplier snapshot</h2>
            <div className="mt-4 flex flex-col gap-3">
              {suppliers.slice(0, 3).map((supplier) => (
                <div className="rounded-md border border-border p-3" key={supplier.id}>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-semibold">{supplier.name}</div>
                      <div className="mt-1 text-xs text-muted-foreground">{supplier.supplierCode}</div>
                    </div>
                    <SupplierStatusBadge status={supplier.status} />
                  </div>
                  <div className="mt-3 text-sm text-muted-foreground">Outstanding</div>
                  <div className="font-semibold">{formatMoney(supplier.outstandingBalanceLak, "LAK")}</div>
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-lg border border-border bg-card p-5">
            <h2 className="text-lg font-semibold">Supplier credit</h2>
            <div className="mt-4 flex flex-col gap-3">
              {payables.slice(0, 3).map((payable) => (
                <div className="rounded-md border border-border p-3" key={payable.id}>
                  <div className="flex items-center justify-between gap-3">
                    <div className="font-mono text-sm font-semibold">{payable.purchaseNo}</div>
                    <PayableStatusBadge status={payable.status} />
                  </div>
                  <div className="mt-2 text-sm text-muted-foreground">{payable.supplierName}</div>
                  <div className="mt-2 font-semibold">{formatMoney(payable.balanceAmountLak, "LAK")} unpaid</div>
                </div>
              ))}
            </div>
          </section>
        </aside>
      </section>
    </div>
  );
}

function SummaryCard({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Truck;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-lg border border-border bg-card p-5">
      <div className="flex items-center justify-between gap-4">
        <div>
          <div className="text-sm text-muted-foreground">{label}</div>
          <div className="mt-2 text-2xl font-semibold">{value}</div>
        </div>
        <div className="grid size-11 place-items-center rounded-md bg-primary/10 text-primary">
          <Icon aria-hidden="true" />
        </div>
      </div>
    </div>
  );
}
