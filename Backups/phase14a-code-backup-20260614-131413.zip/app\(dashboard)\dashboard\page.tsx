import { requireSession } from "@/lib/auth/session";
import { getDictionary } from "@/lib/i18n/dictionaries";
import { BASE_CURRENCY, PRIMARY_STORE } from "@/lib/constants";

const cards = [
  { label: "Today Sales", value: "0 LAK" },
  { label: "Today Profit", value: "0 LAK" },
  { label: "Bill Count", value: "0" },
  { label: "Items Sold", value: "0" },
  { label: "Low Stock", value: "0" },
  { label: "Supplier Due", value: "0 LAK" },
];

const phaseZeroItems = [
  "Project structure",
  "Authentication",
  "Database schema skeleton",
  "Multi-company foundation",
  "Role and permission foundation",
  "Audit log foundation",
  "Dark / light theme",
  "Lao / English language support",
];

export default async function DashboardPage() {
  const session = await requireSession();
  const dictionary = getDictionary(session.user.locale);

  return (
    <div className="flex flex-col gap-6">
      <section className="rounded-lg border border-border bg-card p-6">
        <div className="flex flex-col gap-2">
          <p className="text-sm font-medium text-primary">{PRIMARY_STORE}</p>
          <h1 className="text-3xl font-semibold text-card-foreground">
            {dictionary.dashboard}
          </h1>
          <p className="max-w-3xl text-sm leading-6 text-muted-foreground">
            Phase 0 foundation is ready for cloud deployment, PostgreSQL data
            ownership, and future POS modules. Business modules are intentionally
            placeholders until their approved phases.
          </p>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {cards.map((card) => (
          <article
            className="rounded-lg border border-border bg-card p-5"
            key={card.label}
          >
            <div className="text-sm text-muted-foreground">{card.label}</div>
            <div className="mt-3 text-2xl font-semibold text-card-foreground">
              {card.value}
            </div>
          </article>
        ))}
      </section>

      <section className="grid gap-4 lg:grid-cols-[1.2fr_0.8fr]">
        <article className="rounded-lg border border-border bg-card p-6">
          <h2 className="text-xl font-semibold">Phase 0 Scope</h2>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            {phaseZeroItems.map((item) => (
              <div
                className="rounded-md border border-border bg-background px-4 py-3 text-sm"
                key={item}
              >
                {item}
              </div>
            ))}
          </div>
        </article>
        <article className="rounded-lg border border-border bg-card p-6">
          <h2 className="text-xl font-semibold">Company Context</h2>
          <dl className="mt-5 flex flex-col gap-4 text-sm">
            <div>
              <dt className="text-muted-foreground">Active company</dt>
              <dd className="mt-1 font-medium">
                {session.user.activeCompanyName ?? "Not assigned"}
              </dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Base currency</dt>
              <dd className="mt-1 font-medium">{BASE_CURRENCY}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Roles</dt>
              <dd className="mt-1 font-medium">
                {session.user.roles?.join(", ") || "No role assigned"}
              </dd>
            </div>
          </dl>
        </article>
      </section>
    </div>
  );
}
