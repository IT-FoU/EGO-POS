import { SupplierForm } from "@/features/suppliers/components/supplier-form";

export default function NewSupplierPage() {
  return <SupplierForm />;
}
