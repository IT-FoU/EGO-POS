import { archivePrismaSupplier, updatePrismaSupplier } from "@/features/suppliers/prisma-repository";
import { runWrite } from "@/lib/api/write-response";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return runWrite((tenant, body) => updatePrismaSupplier(id, body, tenant), request);
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return runWrite((tenant) => archivePrismaSupplier(id, tenant));
}
