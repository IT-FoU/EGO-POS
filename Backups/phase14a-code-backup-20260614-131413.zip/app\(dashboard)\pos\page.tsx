import { PosPageClient } from "@/features/pos/components/pos-page-client";
import { getPosSnapshot } from "@/features/pos/pos-service";

export default async function PosPage() {
  const { branchName, cashierName, products, taxRatePercent } =
    await getPosSnapshot();

  return (
    <PosPageClient
      branchName={branchName}
      cashierName={cashierName}
      products={products}
      taxRatePercent={taxRatePercent}
    />
  );
}
