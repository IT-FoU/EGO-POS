import { mockMembershipLevels } from "@/features/customers/mock-data";
import type { MembershipLevel } from "@/features/customers/types";
import { mockCategories, mockProducts } from "@/features/products/mock-data";
import type { Category, Product } from "@/features/products/types";
import { mockPromotions } from "@/features/promotions/mock-data";
import type { Promotion, PromotionSimulation } from "@/features/promotions/types";
import { isDemoMode } from "@/lib/demo-mode";
import {
  getPrismaPromotionById,
  getPrismaPromotionDetail,
  getPrismaPromotions,
  getPrismaPromotionsSnapshot,
} from "@/features/promotions/prisma-repository";

export async function getPromotionsSnapshot(): Promise<{
  categories: Category[];
  membershipLevels: MembershipLevel[];
  products: Product[];
  promotions: Promotion[];
}> {
  if (!isDemoMode()) {
    return getPrismaPromotionsSnapshot();
  }

  return {
    categories: mockCategories,
    membershipLevels: mockMembershipLevels,
    products: mockProducts,
    promotions: mockPromotions,
  };
}

export async function getPromotions(): Promise<Promotion[]> {
  if (!isDemoMode()) {
    return getPrismaPromotions();
  }

  return mockPromotions;
}

export async function getPromotionById(promotionId: string): Promise<Promotion | undefined> {
  if (!isDemoMode()) {
    return getPrismaPromotionById(promotionId);
  }

  return mockPromotions.find((promotion) => promotion.id === promotionId);
}

export async function getPromotionDetail(promotionId: string): Promise<{
  categories: Category[];
  membershipLevels: MembershipLevel[];
  products: Product[];
  promotion: Promotion | undefined;
  simulation: PromotionSimulation | undefined;
}> {
  if (!isDemoMode()) {
    return getPrismaPromotionDetail(promotionId);
  }

  const promotion = await getPromotionById(promotionId);

  return {
    categories: mockCategories,
    membershipLevels: mockMembershipLevels,
    products: mockProducts,
    promotion,
    simulation: promotion ? simulatePromotion(promotion) : undefined,
  };
}

function simulatePromotion(promotion: Promotion): PromotionSimulation {
  const includedProducts = mockProducts.filter((product) =>
    promotion.applicableProductIds.length > 0
      ? promotion.applicableProductIds.includes(product.id)
      : promotion.applicableCategoryIds.includes(product.categoryId),
  );
  const sampleProducts = includedProducts.slice(0, 2);
  const fallbackProducts = sampleProducts.length > 0 ? sampleProducts : mockProducts.slice(0, 2);
  const cartLines = fallbackProducts.map((product, index) => ({
    product,
    quantity: promotion.type === "buy_x_get_y" && index === 0 ? 3 : 1,
  }));
  const cartSubtotalLak = cartLines.reduce(
    (total, line) => total + line.product.sellingPriceLak * line.quantity,
    0,
  );

  const lineResults = cartLines.map((line) => {
    const originalTotalLak = line.product.sellingPriceLak * line.quantity;
    let discountLak = 0;

    if (promotion.type === "percentage" || promotion.type === "member_discount") {
      discountLak = Math.round(originalTotalLak * ((promotion.discountPercent ?? 0) / 100));
    }

    if (promotion.type === "fixed_amount") {
      discountLak = Math.min(originalTotalLak, promotion.discountAmountLak ?? 0);
    }

    if (promotion.type === "buy_x_get_y") {
      const groupSize = (promotion.buyQuantity ?? 0) + (promotion.getQuantity ?? 0);
      const freeGroups = groupSize > 0 ? Math.floor(line.quantity / groupSize) : 0;
      discountLak = freeGroups * (promotion.getQuantity ?? 0) * line.product.sellingPriceLak;
    }

    return {
      discountLak,
      finalTotalLak: Math.max(originalTotalLak - discountLak, 0),
      label: line.product.nameEn,
      originalTotalLak,
      quantity: line.quantity,
    };
  });

  let discountLak = lineResults.reduce((total, line) => total + line.discountLak, 0);

  if (promotion.type === "combo_set" && cartLines.length >= 2) {
    discountLak = Math.max(cartSubtotalLak - (promotion.comboPriceLak ?? cartSubtotalLak), 0);
    const first = lineResults[0];
    if (first) {
      first.discountLak = discountLak;
      first.finalTotalLak = Math.max(first.originalTotalLak - discountLak, 0);
    }
  }

  return {
    cartSubtotalLak,
    discountLak,
    finalTotalLak: Math.max(cartSubtotalLak - discountLak, 0),
    lineResults,
  };
}
