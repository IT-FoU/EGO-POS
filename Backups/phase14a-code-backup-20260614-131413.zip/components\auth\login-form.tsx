"use client";

import { useState, useTransition } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";

type LoginDictionary = {
  username: string;
  password: string;
  signIn: string;
};

export function LoginForm({ dictionary }: { dictionary: LoginDictionary }) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);

    startTransition(async () => {
      setError(null);

      const health = await fetch("/api/health/database", {
        cache: "no-store",
      });

      if (!health.ok) {
        setError(
          "Database is not available. Start PostgreSQL, then run migration and seed before logging in.",
        );
        return;
      }

      const result = await signIn("credentials", {
        username: formData.get("username"),
        password: formData.get("password"),
        redirect: false,
      });

      if (result?.error) {
        setError(
          result.error === "CredentialsSignin"
            ? "Invalid username or password."
            : "Authentication is not ready. Check the local database and environment settings.",
        );
        return;
      }

      router.push("/dashboard");
      router.refresh();
    });
  }

  return (
    <form className="flex flex-col gap-5" onSubmit={handleSubmit}>
      <label className="flex flex-col gap-2 text-sm font-medium">
        {dictionary.username}
        <input
          className="h-12 rounded-md border border-border bg-background px-4 text-base outline-none transition focus:border-primary"
          name="username"
          type="text"
          autoComplete="username"
          required
        />
      </label>
      <label className="flex flex-col gap-2 text-sm font-medium">
        {dictionary.password}
        <input
          className="h-12 rounded-md border border-border bg-background px-4 text-base outline-none transition focus:border-primary"
          name="password"
          type="password"
          autoComplete="current-password"
          required
        />
      </label>
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <button
        className="h-12 rounded-md bg-primary px-5 text-base font-semibold text-primary-foreground transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-60"
        type="submit"
        disabled={isPending}
      >
        {isPending ? "Signing in..." : dictionary.signIn}
      </button>
    </form>
  );
}
