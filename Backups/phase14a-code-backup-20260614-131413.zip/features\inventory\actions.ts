"use server";

import { requireSession } from "@/lib/auth/session";
import { tenantFromSession, writeFailure, writeSuccess } from "@/lib/db/write-context";
import { createStockAdjustment, createStockCount, createStockIn } from "@/features/inventory/prisma-repository";

async function tenant() {
  return tenantFromSession(await requireSession());
}

export async function stockInAction(input: Parameters<typeof createStockIn>[0]) {
  try { return writeSuccess(await createStockIn(input, await tenant())); } catch (error) { return writeFailure(error); }
}

export async function stockAdjustmentAction(input: Parameters<typeof createStockAdjustment>[0]) {
  try { return writeSuccess(await createStockAdjustment(input, await tenant())); } catch (error) { return writeFailure(error); }
}

export async function stockCountAction(input: Parameters<typeof createStockCount>[0]) {
  try { return writeSuccess(await createStockCount(input, await tenant())); } catch (error) { return writeFailure(error); }
}
