"use client";

import type { Warehouse } from "@/features/inventory/types";

export function WarehouseSelector({
  selectedWarehouseId,
  warehouses,
  onChange,
}: {
  selectedWarehouseId: string;
  warehouses: Warehouse[];
  onChange: (warehouseId: string) => void;
}) {
  return (
    <label className="flex min-w-64 flex-col gap-2 text-sm font-medium">
      Warehouse / ສາງ
      <select
        className="field-input"
        value={selectedWarehouseId}
        onChange={(event) => onChange(event.target.value)}
      >
        <option value="all">All warehouses</option>
        {warehouses.map((warehouse) => (
          <option value={warehouse.id} key={warehouse.id}>
            {warehouse.name} - {warehouse.branchName}
          </option>
        ))}
      </select>
    </label>
  );
}
