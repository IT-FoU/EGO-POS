"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Building2, Eye, Plus, Search, Truck } from "lucide-react";
import type { Supplier, SupplierStatus } from "@/features/suppliers/types";
import { SupplierStatusBadge } from "@/features/suppliers/components/supplier-status-badge";
import { formatLak } from "@/features/suppliers/format";

const statusOptions: Array<SupplierStatus | "all"> = ["all", "active", "inactive"];

export function SuppliersListClient({ suppliers }: { suppliers: Supplier[] }) {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<SupplierStatus | "all">("all");

  const filteredSuppliers = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();

    return suppliers.filter((supplier) => {
      const matchesQuery =
        normalizedQuery.length === 0 ||
        [
          supplier.supplierCode,
          supplier.companyName,
          supplier.contactPerson,
          supplier.phone,
          supplier.email,
          supplier.taxNumber,
        ]
          .join(" ")
          .toLowerCase()
          .includes(normalizedQuery);
      const matchesStatus = status === "all" || supplier.status === status;

      return matchesQuery && matchesStatus;
    });
  }, [query, status, suppliers]);

  const activeSuppliers = suppliers.filter((supplier) => supplier.status === "active").length;
  const totalCreditLimit = suppliers.reduce(
    (total, supplier) => total + supplier.creditLimitLak,
    0,
  );
  const totalOutstanding = suppliers.reduce(
    (total, supplier) => total + supplier.outstandingBalanceLak,
    0,
  );

  return (
    <div className="flex flex-col gap-6">
      <section className="rounded-lg border border-border bg-card p-6">
        <div className="flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between">
          <div>
            <p className="text-sm font-medium text-primary">Supplier Management</p>
            <h1 className="mt-2 text-3xl font-semibold">Suppliers / ຜູ້ສະໜອງ</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">
              Supplier profiles with credit, outstanding balances, purchase
              performance, receiving, and payment history foundations. Mock data
              only.
            </p>
          </div>
          <Link
            className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground transition hover:opacity-90"
            href="/suppliers/new"
          >
            <Plus aria-hidden="true" />
            Create supplier
          </Link>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        <Metric icon={Building2} label="Active suppliers" value={String(activeSuppliers)} />
        <Metric icon={Truck} label="Total credit limit" value={`${formatLak(totalCreditLimit)} LAK`} />
        <Metric icon={Eye} label="Outstanding balance" value={`${formatLak(totalOutstanding)} LAK`} />
      </section>

      <section className="rounded-lg border border-border bg-card p-5">
        <div className="flex min-w-0 flex-col gap-3 md:flex-row">
          <label className="relative flex-1">
            <Search
              aria-hidden="true"
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            />
            <input
              className="field-input pl-10"
              placeholder="Search code, company, contact, phone, email, tax number"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
          </label>
          <select
            className="field-input md:w-48"
            value={status}
            onChange={(event) => setStatus(event.target.value as SupplierStatus | "all")}
            aria-label="Filter by supplier status"
          >
            {statusOptions.map((option) => (
              <option value={option} key={option}>
                {option === "all" ? "All statuses" : option}
              </option>
            ))}
          </select>
        </div>
      </section>

      <section className="overflow-hidden rounded-lg border border-border bg-card">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1120px] border-collapse text-left text-sm">
            <thead className="border-b border-border bg-background text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-semibold">Supplier code</th>
                <th className="px-4 py-3 font-semibold">Company name</th>
                <th className="px-4 py-3 font-semibold">Contact person</th>
                <th className="px-4 py-3 font-semibold">Phone</th>
                <th className="px-4 py-3 font-semibold">Email</th>
                <th className="px-4 py-3 text-right font-semibold">Credit limit</th>
                <th className="px-4 py-3 text-right font-semibold">Outstanding</th>
                <th className="px-4 py-3 font-semibold">Status</th>
                <th className="px-4 py-3 text-right font-semibold">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredSuppliers.map((supplier) => (
                <tr className="border-b border-border last:border-b-0" key={supplier.id}>
                  <td className="px-4 py-4 font-mono text-xs">{supplier.supplierCode}</td>
                  <td className="px-4 py-4">
                    <div className="font-semibold">{supplier.companyName}</div>
                    <div className="mt-1 text-xs text-muted-foreground">{supplier.taxNumber}</div>
                  </td>
                  <td className="px-4 py-4">{supplier.contactPerson}</td>
                  <td className="px-4 py-4">{supplier.phone}</td>
                  <td className="px-4 py-4">{supplier.email}</td>
                  <td className="px-4 py-4 text-right font-semibold">
                    {formatLak(supplier.creditLimitLak)} LAK
                  </td>
                  <td className="px-4 py-4 text-right font-semibold">
                    {formatLak(supplier.outstandingBalanceLak)} LAK
                  </td>
                  <td className="px-4 py-4">
                    <SupplierStatusBadge status={supplier.status} />
                  </td>
                  <td className="px-4 py-4 text-right">
                    <Link
                      className="inline-flex h-9 items-center gap-2 rounded-md border border-border px-3 text-xs font-semibold transition hover:border-primary"
                      href={`/suppliers/${supplier.id}`}
                    >
                      <Eye aria-hidden="true" />
                      View
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredSuppliers.length === 0 ? (
          <div className="p-8 text-center text-sm text-muted-foreground">
            No suppliers match the current search and filters.
          </div>
        ) : null}
      </section>
    </div>
  );
}

function Metric({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Building2;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-lg border border-border bg-card p-5">
      <div className="flex items-center justify-between gap-4">
        <div>
          <div className="text-sm text-muted-foreground">{label}</div>
          <div className="mt-2 text-2xl font-semibold">{value}</div>
        </div>
        <div className="grid size-11 place-items-center rounded-md bg-primary/10 text-primary">
          <Icon aria-hidden="true" />
        </div>
      </div>
    </div>
  );
}
