"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  Barcode,
  Camera,
  Plus,
  RefreshCw,
  Save,
  Trash2,
  Usb,
  X,
} from "lucide-react";
import type {
  Category,
  MockProductImage,
  Product,
  ProductUnit,
} from "@/features/products/types";
import { ProductImageUploadPanel } from "@/features/products/components/product-image-placeholder";
import { formatLak } from "@/features/products/format";

const emptyUnit: ProductUnit = {
  id: "unit-new",
  unitName: "",
  conversionQty: 1,
  barcode: "",
  sellingPriceLak: 0,
  isBaseUnit: false,
};

export function ProductForm({
  mode,
  product,
  categories,
  images,
}: {
  mode: "create" | "edit";
  product?: Product;
  categories: Category[];
  images: MockProductImage[];
}) {
  const [barcode, setBarcode] = useState(product?.barcode ?? "");
  const [sku, setSku] = useState(product?.sku ?? "");
  const [productCode, setProductCode] = useState(product?.productCode ?? "");
  const [selectedImageId, setSelectedImageId] = useState<string | undefined>(
    product?.imageUrl,
  );
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [units, setUnits] = useState<ProductUnit[]>(
    product?.units ?? [
      {
        ...emptyUnit,
        id: "unit-base",
        unitName: "Piece",
        isBaseUnit: true,
      },
    ],
  );
  const [message, setMessage] = useState<string | null>(null);

  const totalDerivedUnits = useMemo(
    () => units.filter((unit) => !unit.isBaseUnit).length,
    [units],
  );

  function updateUnit(unitId: string, patch: Partial<ProductUnit>) {
    setUnits((current) =>
      current.map((unit) => (unit.id === unitId ? { ...unit, ...patch } : unit)),
    );
  }

  function addUnit() {
    setUnits((current) => [
      ...current,
      {
        ...emptyUnit,
        id: `unit-${Date.now()}`,
      },
    ]);
  }

  function applyUnitPreset() {
    setUnits([
      {
        id: "unit-piece",
        unitName: "Piece",
        conversionQty: 1,
        barcode,
        sellingPriceLak: product?.sellingPriceLak ?? 0,
        isBaseUnit: true,
      },
      {
        id: "unit-pack",
        unitName: "Pack",
        conversionQty: 6,
        barcode: barcode ? `${barcode}-P6` : "",
        sellingPriceLak: (product?.sellingPriceLak ?? 0) * 6,
        isBaseUnit: false,
      },
      {
        id: "unit-carton",
        unitName: "Carton",
        conversionQty: 24,
        barcode: barcode ? `${barcode}-C24` : "",
        sellingPriceLak: (product?.sellingPriceLak ?? 0) * 24,
        isBaseUnit: false,
      },
    ]);
  }

  function generateSku() {
    const timestamp = Date.now().toString().slice(-5);
    setSku(`IGO-${timestamp}`);
  }

  function generateProductCode() {
    const timestamp = Date.now().toString().slice(-4);
    setProductCode(`P-${timestamp}`);
  }

  function simulateCameraScan() {
    const scannedBarcode = `885${Date.now().toString().slice(-10)}`;
    setBarcode(scannedBarcode);
    setUnits((current) =>
      current.map((unit) =>
        unit.isBaseUnit ? { ...unit, barcode: scannedBarcode } : unit,
      ),
    );
    setIsScannerOpen(false);
    setMessage("Camera scan simulated. Barcode field was auto-filled.");
  }

  function removeUnit(unitId: string) {
    setUnits((current) => current.filter((unit) => unit.id !== unitId || unit.isBaseUnit));
  }

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage(
      "Product form validated locally. Database save will be connected after PostgreSQL is available.",
    );
  }

  return (
    <form className="flex flex-col gap-6" onSubmit={handleSubmit}>
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <Link
            className="inline-flex items-center gap-2 text-sm text-muted-foreground transition hover:text-foreground"
            href="/products"
          >
            <ArrowLeft aria-hidden="true" />
            Back to products
          </Link>
          <h1 className="mt-3 text-3xl font-semibold">
            {mode === "create" ? "Create product" : "Edit product"}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Lao and English names, barcode/SKU, LAK pricing, image placeholder,
            status, and multi-unit setup.
          </p>
        </div>
        <button
          className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground transition hover:opacity-90"
          type="submit"
        >
          <Save aria-hidden="true" />
          Save locally
        </button>
      </div>

      {isScannerOpen ? (
        <BarcodeScannerModal
          onClose={() => setIsScannerOpen(false)}
          onScan={simulateCameraScan}
        />
      ) : null}

      {message ? (
        <div className="rounded-md border border-success/40 bg-success/10 px-4 py-3 text-sm text-success">
          {message}
        </div>
      ) : null}

      <div className="grid gap-6 xl:grid-cols-[1fr_360px]">
        <div className="flex flex-col gap-6">
          <section className="rounded-lg border border-border bg-card p-5">
            <h2 className="text-lg font-semibold">General</h2>
            <div className="mt-5 grid gap-4 md:grid-cols-2">
              <Field label="Product name Lao">
                <input
                  className="field-input"
                  name="nameLo"
                  defaultValue={product?.nameLo}
                  required
                />
              </Field>
              <Field label="Product name English">
                <input
                  className="field-input"
                  name="nameEn"
                  defaultValue={product?.nameEn}
                  required
                />
              </Field>
              <Field label="Product code">
                <div className="flex gap-2">
                  <input
                    className="field-input font-mono"
                    name="productCode"
                    value={productCode}
                    onChange={(event) => setProductCode(event.target.value)}
                    placeholder="P-0001"
                  />
                  <button
                    className="inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-md border border-border px-3 text-sm font-semibold transition hover:border-primary"
                    type="button"
                    onClick={generateProductCode}
                  >
                    <RefreshCw aria-hidden="true" />
                    Generate
                  </button>
                </div>
              </Field>
              <Field label="Barcode">
                <div className="flex gap-2">
                  <div className="relative min-w-0 flex-1">
                    <Barcode
                      aria-hidden="true"
                      className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                    />
                    <input
                      className="field-input pl-10"
                      name="barcode"
                      value={barcode}
                      onChange={(event) => setBarcode(event.target.value)}
                      placeholder="Scan or type barcode"
                      required
                    />
                  </div>
                  <button
                    className="inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-md border border-border px-3 text-sm font-semibold transition hover:border-primary"
                    type="button"
                    onClick={() => setIsScannerOpen(true)}
                  >
                    <Camera aria-hidden="true" />
                    Scan
                  </button>
                </div>
                <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
                  <Usb aria-hidden="true" />
                  USB scanners are supported by focusing this field and scanning.
                </div>
              </Field>
              <Field label="SKU">
                <div className="flex gap-2">
                  <input
                    className="field-input font-mono"
                    name="sku"
                    value={sku}
                    onChange={(event) => setSku(event.target.value)}
                    required
                  />
                  <button
                    className="inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-md border border-border px-3 text-sm font-semibold transition hover:border-primary"
                    type="button"
                    onClick={generateSku}
                  >
                    <RefreshCw aria-hidden="true" />
                    Auto-generate SKU
                  </button>
                </div>
              </Field>
              <Field label="Category">
                <select
                  className="field-input"
                  name="categoryId"
                  defaultValue={product?.categoryId ?? categories[0]?.id}
                >
                  {categories.map((category) => (
                    <option value={category.id} key={category.id}>
                      {category.nameEn} / {category.nameLo}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Product status">
                <select
                  className="field-input"
                  name="status"
                  defaultValue={product?.status ?? "active"}
                >
                  <option value="active">Active</option>
                  <option value="draft">Draft</option>
                  <option value="inactive">Inactive</option>
                </select>
              </Field>
              <Field label="Brand">
                <input
                  className="field-input"
                  name="brandId"
                  defaultValue={product?.brandName}
                  placeholder="Brand ID"
                />
              </Field>
              <Field label="Supplier">
                <input
                  className="field-input"
                  name="supplierId"
                  defaultValue={product?.supplierName}
                  placeholder="Supplier ID"
                />
              </Field>
              <Field label="Product tags">
                <input
                  className="field-input"
                  name="tags"
                  defaultValue={product?.tags?.join(", ")}
                  placeholder="drink, cold, can"
                />
              </Field>
              <Field label="Minimum stock level">
                <input
                  className="field-input"
                  name="minStock"
                  type="number"
                  min="0"
                  defaultValue={product?.minStock ?? 0}
                />
              </Field>
              <div className="md:col-span-2">
                <Field label="Product description">
                  <textarea
                    className="min-h-28 w-full rounded-md border border-border bg-background p-3 text-sm outline-none transition focus:border-primary"
                    name="description"
                    defaultValue={product?.description}
                    placeholder="Short product description for staff reference"
                  />
                </Field>
              </div>
            </div>
          </section>

          <section className="rounded-lg border border-border bg-card p-5">
            <h2 className="text-lg font-semibold">Pricing</h2>
            <div className="mt-5 grid gap-4 md:grid-cols-2">
              <Field label="Cost price LAK">
                <input
                  className="field-input"
                  name="costPriceLak"
                  type="number"
                  min="0"
                  defaultValue={product?.costPriceLak ?? 0}
                  required
                />
              </Field>
              <Field label="Selling price LAK">
                <input
                  className="field-input"
                  name="sellingPriceLak"
                  type="number"
                  min="0"
                  defaultValue={product?.sellingPriceLak ?? 0}
                  required
                />
              </Field>
            </div>
          </section>

          <section className="rounded-lg border border-border bg-card p-5">
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div>
                <h2 className="text-lg font-semibold">Product units</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Base unit plus pack/carton conversions for barcode selling.
                </p>
              </div>
              <button
                className="inline-flex h-10 items-center justify-center gap-2 rounded-md border border-border px-4 text-sm font-semibold transition hover:border-primary"
                type="button"
                onClick={addUnit}
              >
                <Plus aria-hidden="true" />
                Add unit
              </button>
              <button
                className="inline-flex h-10 items-center justify-center gap-2 rounded-md border border-border px-4 text-sm font-semibold transition hover:border-primary"
                type="button"
                onClick={applyUnitPreset}
              >
                Piece / Pack / Carton
              </button>
            </div>
            <div className="mt-5 overflow-x-auto">
              <table className="w-full min-w-[760px] text-left text-sm">
                <thead className="border-b border-border text-xs uppercase text-muted-foreground">
                  <tr>
                    <th className="px-3 py-3">Unit</th>
                    <th className="px-3 py-3">Conversion qty</th>
                    <th className="px-3 py-3">Barcode</th>
                    <th className="px-3 py-3">Price LAK</th>
                    <th className="px-3 py-3">Base</th>
                    <th className="px-3 py-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {units.map((unit) => (
                    <tr className="border-b border-border last:border-b-0" key={unit.id}>
                      <td className="px-3 py-3">
                        <input
                          className="field-input h-10"
                          value={unit.unitName}
                          onChange={(event) =>
                            updateUnit(unit.id, { unitName: event.target.value })
                          }
                        />
                      </td>
                      <td className="px-3 py-3">
                        <input
                          className="field-input h-10"
                          type="number"
                          min="1"
                          value={unit.conversionQty}
                          onChange={(event) =>
                            updateUnit(unit.id, {
                              conversionQty: Number(event.target.value),
                            })
                          }
                        />
                      </td>
                      <td className="px-3 py-3">
                        <input
                          className="field-input h-10 font-mono"
                          value={unit.barcode}
                          onChange={(event) =>
                            updateUnit(unit.id, { barcode: event.target.value })
                          }
                        />
                      </td>
                      <td className="px-3 py-3">
                        <input
                          className="field-input h-10"
                          type="number"
                          min="0"
                          value={unit.sellingPriceLak}
                          onChange={(event) =>
                            updateUnit(unit.id, {
                              sellingPriceLak: Number(event.target.value),
                            })
                          }
                        />
                      </td>
                      <td className="px-3 py-3">
                        {unit.isBaseUnit ? "Yes" : "No"}
                      </td>
                      <td className="px-3 py-3 text-right">
                        <button
                          className="inline-flex h-9 items-center justify-center rounded-md border border-border px-3 text-danger transition hover:border-danger disabled:cursor-not-allowed disabled:opacity-40"
                          type="button"
                          onClick={() => removeUnit(unit.id)}
                          disabled={unit.isBaseUnit}
                          aria-label="Remove unit"
                        >
                          <Trash2 aria-hidden="true" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </div>

        <aside className="flex flex-col gap-6">
          <ProductImageUploadPanel
            images={images}
            selectedImageId={selectedImageId}
            onSelectImage={(image) => {
              setSelectedImageId(image.id);
              setMessage(`${image.title} selected as product image.`);
            }}
          />
          <section className="rounded-lg border border-border bg-card p-5">
            <h2 className="text-lg font-semibold">Local summary</h2>
            <dl className="mt-5 flex flex-col gap-4 text-sm">
              <div>
                <dt className="text-muted-foreground">Derived units</dt>
                <dd className="mt-1 font-semibold">{totalDerivedUnits}</dd>
              </div>
              <div>
                <dt className="text-muted-foreground">Base unit price</dt>
                <dd className="mt-1 font-semibold">
                  {formatLak(units.find((unit) => unit.isBaseUnit)?.sellingPriceLak ?? 0)} LAK
                </dd>
              </div>
              <div>
                <dt className="text-muted-foreground">Database status</dt>
                <dd className="mt-1 font-semibold text-warning">Mock data mode</dd>
              </div>
            </dl>
          </section>
        </aside>
      </div>
    </form>
  );
}

function BarcodeScannerModal({
  onClose,
  onScan,
}: {
  onClose: () => void;
  onScan: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4">
      <div className="w-full max-w-lg rounded-lg border border-border bg-card p-5 shadow-2xl">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold">Camera barcode scanner</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Mock scanner UI. Camera permissions and real decoding can be
              connected later.
            </p>
          </div>
          <button
            className="grid size-9 place-items-center rounded-md border border-border"
            type="button"
            onClick={onClose}
            aria-label="Close scanner"
          >
            <X aria-hidden="true" />
          </button>
        </div>
        <div className="mt-5 overflow-hidden rounded-md border border-border bg-background">
          <div className="relative grid aspect-video place-items-center">
            <div className="absolute inset-x-10 top-1/2 h-0.5 bg-danger shadow-[0_0_18px_var(--danger)]" />
            <div className="h-28 w-72 rounded-md border-2 border-primary/70" />
            <span className="absolute bottom-4 text-xs text-muted-foreground">
              Align barcode inside the frame
            </span>
          </div>
        </div>
        <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:justify-end">
          <button
            className="h-11 rounded-md border border-border px-4 text-sm font-semibold transition hover:border-primary"
            type="button"
            onClick={onClose}
          >
            Cancel
          </button>
          <button
            className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground transition hover:opacity-90"
            type="button"
            onClick={onScan}
          >
            <Barcode aria-hidden="true" />
            Simulate scan
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({
  children,
  label,
}: {
  children: React.ReactNode;
  label: string;
}) {
  return (
    <label className="flex flex-col gap-2 text-sm font-medium">
      {label}
      {children}
    </label>
  );
}
