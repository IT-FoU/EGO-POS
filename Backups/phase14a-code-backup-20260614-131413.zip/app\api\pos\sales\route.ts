import { completePrismaSale } from "@/features/pos/prisma-repository";
import { runWrite } from "@/lib/api/write-response";

export async function POST(request: Request) {
  return runWrite((tenant, body) => completePrismaSale(body, tenant), request);
}
