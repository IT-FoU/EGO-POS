import type { CurrencyCode } from "@/features/purchasing/types";

export function formatMoney(value: number, currency: CurrencyCode | "LAK" = "LAK") {
  return `${new Intl.NumberFormat("en-US", {
    maximumFractionDigits: currency === "LAK" ? 0 : 2,
  }).format(value)} ${currency}`;
}

export function convertToLak(value: number, exchangeRate: number) {
  return value * exchangeRate;
}
