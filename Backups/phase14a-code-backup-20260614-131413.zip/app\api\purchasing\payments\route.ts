import { createSupplierPayment } from "@/features/purchasing/prisma-repository";
import { runWrite } from "@/lib/api/write-response";

export async function POST(request: Request) {
  return runWrite((tenant, body) => createSupplierPayment(body, tenant), request);
}
