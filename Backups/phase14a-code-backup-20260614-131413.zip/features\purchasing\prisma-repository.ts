import { prisma } from "@/lib/db/prisma";
import type { TenantContext } from "@/lib/db/write-context";
import { numberValue, optionalString, stringValue, withTenantTransaction } from "@/lib/db/write-context";
import { getPrismaInventorySnapshot } from "@/features/inventory/prisma-repository";
import { getPrismaProducts } from "@/features/products/prisma-repository";
import {
  mapPrismaPurchaseOrder,
  mapPrismaPurchasingSupplier,
  mapPrismaSupplierPayable,
} from "@/features/purchasing/dto-mapper";

const db = prisma as any;

export async function getPrismaPurchasingSnapshot() {
  const [suppliers, purchaseOrders, payables, products, inventory] = await Promise.all([
    db.supplier.findMany({ orderBy: { name: "asc" } }),
    db.purchase.findMany({
      include: {
        items: { include: { product: true, unit: true } },
        supplier: true,
        warehouse: true,
      },
      orderBy: { purchaseDate: "desc" },
    }),
    db.supplierPayable.findMany({
      include: { purchase: true, supplier: true },
      orderBy: { dueDate: "asc" },
    }),
    getPrismaProducts(),
    getPrismaInventorySnapshot(),
  ]);

  return {
    inventoryItems: inventory.items,
    payables: payables.map(mapPrismaSupplierPayable),
    products,
    purchaseOrders: purchaseOrders.map(mapPrismaPurchaseOrder),
    suppliers: suppliers.map(mapPrismaPurchasingSupplier),
    warehouses: inventory.warehouses,
  };
}

export async function createPurchaseOrder(input: {
  currency?: string;
  exchangeRate?: number;
  items: Array<{ expiryDate?: string; lotNumber?: string; productId: string; quantity: number; unitCost: number; unitId?: string }>;
  paidAmount?: number;
  purchaseNo: string;
  supplierId: string;
  warehouseId: string;
}, tenant: TenantContext) {
  const subtotal = input.items.reduce((total, item) => total + numberValue(item.quantity) * numberValue(item.unitCost), 0);
  const paidAmount = numberValue(input.paidAmount);
  return withTenantTransaction({
    action: "create",
    module: "purchasing",
    newData: input,
    tenant,
    write: async (tx) => tx.purchase.create({
      data: {
        balanceAmount: Math.max(subtotal - paidAmount, 0),
        companyId: tenant.companyId,
        currency: input.currency ?? "LAK",
        exchangeRate: numberValue(input.exchangeRate, 1),
        items: {
          create: input.items.map((item) => ({
            expiryDate: item.expiryDate ? new Date(item.expiryDate) : undefined,
            lotNumber: optionalString(item.lotNumber),
            productId: item.productId,
            quantity: numberValue(item.quantity),
            totalCost: numberValue(item.quantity) * numberValue(item.unitCost),
            unitCost: numberValue(item.unitCost),
            unitId: optionalString(item.unitId),
          })),
        },
        paidAmount,
        purchaseNo: stringValue(input.purchaseNo),
        status: "draft",
        subtotal,
        supplierId: input.supplierId,
        totalAmount: subtotal,
        warehouseId: input.warehouseId,
      },
      include: { items: true },
    }),
  });
}

export async function receiveGoods(input: {
  items: Array<{ expiryDate?: string; lotNumber?: string; productId: string; purchaseItemId?: string; quantity: number; unitId?: string }>;
  purchaseId: string;
  receiptNo: string;
  status?: "draft" | "partial" | "received" | "cancelled";
  warehouseId: string;
}, tenant: TenantContext) {
  return withTenantTransaction({
    action: "receive",
    module: "purchasing",
    newData: input,
    tenant,
    write: async (tx) => tx.goodsReceipt.create({
      data: {
        companyId: tenant.companyId,
        items: {
          create: input.items.map((item) => ({
            expiryDate: item.expiryDate ? new Date(item.expiryDate) : undefined,
            lotNumber: optionalString(item.lotNumber),
            productId: item.productId,
            purchaseItemId: optionalString(item.purchaseItemId),
            quantity: numberValue(item.quantity),
            unitId: optionalString(item.unitId),
          })),
        },
        purchaseId: input.purchaseId,
        receiptNo: stringValue(input.receiptNo),
        receivedBy: tenant.userId,
        status: input.status ?? "received",
        warehouseId: input.warehouseId,
      },
      include: { items: true },
    }),
  });
}

export async function createSupplierPayment(input: {
  amount: number;
  note?: string;
  paymentMethod?: string;
  purchaseId: string;
}, tenant: TenantContext) {
  return withTenantTransaction({
    action: "payment",
    module: "purchasing",
    newData: input,
    tenant,
    write: async (tx) => tx.purchasePayment.create({
      data: {
        amount: numberValue(input.amount),
        note: optionalString(input.note),
        paymentMethod: input.paymentMethod ?? "cash",
        purchaseId: input.purchaseId,
      },
    }),
  });
}
