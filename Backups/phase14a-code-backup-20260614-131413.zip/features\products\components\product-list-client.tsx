"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Edit3, Plus, Search, SlidersHorizontal } from "lucide-react";
import type { Category, Product, ProductStatus } from "@/features/products/types";
import { ProductImagePlaceholder } from "@/features/products/components/product-image-placeholder";
import { StatusBadge } from "@/features/products/components/status-badge";
import { formatLak } from "@/features/products/format";

const statusOptions: Array<ProductStatus | "all"> = [
  "all",
  "active",
  "draft",
  "inactive",
  "deleted",
];

export function ProductListClient({
  products,
  categories,
}: {
  products: Product[];
  categories: Category[];
}) {
  const [query, setQuery] = useState("");
  const [categoryId, setCategoryId] = useState("all");
  const [status, setStatus] = useState<ProductStatus | "all">("all");

  const filteredProducts = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();

    return products.filter((product) => {
      const matchesQuery =
        normalizedQuery.length === 0 ||
        [
          product.barcode,
          product.sku,
          product.nameLo,
          product.nameEn,
          product.categoryName,
          product.supplierName,
        ]
          .join(" ")
          .toLowerCase()
          .includes(normalizedQuery);
      const matchesCategory = categoryId === "all" || product.categoryId === categoryId;
      const matchesStatus = status === "all" || product.status === status;

      return matchesQuery && matchesCategory && matchesStatus;
    });
  }, [categoryId, products, query, status]);

  return (
    <div className="flex flex-col gap-5">
      <section className="rounded-lg border border-border bg-card p-5">
        <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
          <div className="flex min-w-0 flex-1 flex-col gap-3 md:flex-row">
            <label className="relative flex-1">
              <Search
                aria-hidden="true"
                className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
              />
              <input
                className="h-11 w-full rounded-md border border-border bg-background pl-10 pr-3 text-sm outline-none transition focus:border-primary"
                placeholder="Search barcode, SKU, Lao/English name, category, supplier"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
              />
            </label>
            <select
              className="h-11 rounded-md border border-border bg-background px-3 text-sm outline-none transition focus:border-primary"
              value={categoryId}
              onChange={(event) => setCategoryId(event.target.value)}
              aria-label="Filter by category"
            >
              <option value="all">All categories</option>
              {categories.map((category) => (
                <option value={category.id} key={category.id}>
                  {category.nameEn}
                </option>
              ))}
            </select>
            <select
              className="h-11 rounded-md border border-border bg-background px-3 text-sm capitalize outline-none transition focus:border-primary"
              value={status}
              onChange={(event) => setStatus(event.target.value as ProductStatus | "all")}
              aria-label="Filter by status"
            >
              {statusOptions.map((option) => (
                <option value={option} key={option}>
                  {option === "all" ? "All statuses" : option}
                </option>
              ))}
            </select>
          </div>
          <div className="flex items-center gap-3">
            <Link
              className="inline-flex h-11 items-center gap-2 rounded-md border border-border px-4 text-sm font-semibold transition hover:border-primary"
              href="/products/categories"
            >
              <SlidersHorizontal aria-hidden="true" />
              Categories
            </Link>
            <Link
              className="inline-flex h-11 items-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground transition hover:opacity-90"
              href="/products/new"
            >
              <Plus aria-hidden="true" />
              Create product
            </Link>
          </div>
        </div>
      </section>

      <section className="overflow-hidden rounded-lg border border-border bg-card">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[980px] border-collapse text-left text-sm">
            <thead className="border-b border-border bg-background text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-semibold">Image</th>
                <th className="px-4 py-3 font-semibold">Barcode</th>
                <th className="px-4 py-3 font-semibold">SKU</th>
                <th className="px-4 py-3 font-semibold">Name</th>
                <th className="px-4 py-3 font-semibold">Category</th>
                <th className="px-4 py-3 text-right font-semibold">Cost</th>
                <th className="px-4 py-3 text-right font-semibold">Price</th>
                <th className="px-4 py-3 font-semibold">Units</th>
                <th className="px-4 py-3 font-semibold">Status</th>
                <th className="px-4 py-3 text-right font-semibold">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredProducts.map((product) => (
                <tr className="border-b border-border last:border-b-0" key={product.id}>
                  <td className="px-4 py-4">
                    <ProductImagePlaceholder />
                  </td>
                  <td className="px-4 py-4 font-mono text-xs">{product.barcode}</td>
                  <td className="px-4 py-4 font-mono text-xs">{product.sku}</td>
                  <td className="px-4 py-4">
                    <div className="font-semibold">{product.nameLo}</div>
                    <div className="mt-1 text-xs text-muted-foreground">
                      {product.nameEn}
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <div>{product.categoryName}</div>
                    <div className="mt-1 text-xs text-muted-foreground">
                      {product.supplierName}
                    </div>
                  </td>
                  <td className="px-4 py-4 text-right">{formatLak(product.costPriceLak)}</td>
                  <td className="px-4 py-4 text-right font-semibold">
                    {formatLak(product.sellingPriceLak)}
                  </td>
                  <td className="px-4 py-4">{product.units.length}</td>
                  <td className="px-4 py-4">
                    <StatusBadge status={product.status} />
                  </td>
                  <td className="px-4 py-4 text-right">
                    <Link
                      className="inline-flex h-9 items-center gap-2 rounded-md border border-border px-3 text-xs font-semibold transition hover:border-primary"
                      href={`/products/${product.id}/edit`}
                    >
                      <Edit3 aria-hidden="true" />
                      Edit
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredProducts.length === 0 ? (
          <div className="p-8 text-center text-sm text-muted-foreground">
            No products match the current search and filters.
          </div>
        ) : null}
      </section>
    </div>
  );
}
