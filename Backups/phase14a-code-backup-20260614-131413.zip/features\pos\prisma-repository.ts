import { prisma } from "@/lib/db/prisma";
import { mapPrismaPosProduct } from "@/features/pos/dto-mapper";
import { mapPaymentModeToSalePayments } from "@/features/pos/dto-mapper";
import type { PaymentMode } from "@/features/pos/types";
import type { TenantContext } from "@/lib/db/write-context";
import { numberValue, stringValue, withTenantTransaction } from "@/lib/db/write-context";

const db = prisma as any;

export async function getPrismaPosSnapshot() {
  const products = await db.product.findMany({
    include: { balances: true, category: true, units: true },
    orderBy: { nameEn: "asc" },
    where: { isActive: true },
  });

  return {
    branchName: "Active Branch",
    cashierName: "Current Cashier",
    products: products.map(mapPrismaPosProduct),
    taxRatePercent: 0,
  };
}

export async function completePrismaSale(input: {
  branchId: string;
  cashAmount: number;
  changeAmount: number;
  customerId?: string;
  discountAmount: number;
  discountPercent: number;
  items: Array<{ costPrice?: number; productId: string; promotionDiscount?: number; promotionId?: string; quantity: number; sellingPrice: number; unitId?: string }>;
  paymentMode: PaymentMode;
  qrAmount: number;
  saleNo: string;
  taxAmount: number;
  taxRate: number;
  totalAmount: number;
  warehouseId: string;
}, tenant: TenantContext) {
  return withTenantTransaction({
    action: "complete",
    module: "pos",
    newData: input,
    tenant,
    write: async (tx) => tx.sale.create({
      data: {
        branchId: input.branchId,
        changeAmount: numberValue(input.changeAmount),
        companyId: tenant.companyId,
        createdBy: tenant.userId,
        customerId: input.customerId,
        discountAmount: numberValue(input.discountAmount),
        discountPercent: numberValue(input.discountPercent),
        items: {
          create: input.items.map((item) => {
            const totalAmount = numberValue(item.quantity) * numberValue(item.sellingPrice) - numberValue(item.promotionDiscount);
            return {
              costPrice: numberValue(item.costPrice),
              discountAmount: numberValue(item.promotionDiscount),
              productId: item.productId,
              profitAmount: totalAmount - numberValue(item.costPrice) * numberValue(item.quantity),
              promotionDiscount: numberValue(item.promotionDiscount),
              promotionId: item.promotionId,
              quantity: numberValue(item.quantity),
              sellingPrice: numberValue(item.sellingPrice),
              totalAmount,
              unitId: item.unitId,
            };
          }),
        },
        payments: {
          create: mapPaymentModeToSalePayments({
            cashAmount: numberValue(input.cashAmount),
            changeAmount: numberValue(input.changeAmount),
            paymentMode: input.paymentMode,
            qrAmount: numberValue(input.qrAmount),
          }),
        },
        saleNo: stringValue(input.saleNo),
        saleStatus: "completed",
        subtotal: input.items.reduce((total, item) => total + numberValue(item.quantity) * numberValue(item.sellingPrice), 0),
        taxAmount: numberValue(input.taxAmount),
        taxRate: numberValue(input.taxRate),
        totalAmount: numberValue(input.totalAmount),
        warehouseId: input.warehouseId,
      },
      include: { items: true, payments: true },
    }),
  });
}
