import { cn } from "@/lib/utils";

const imageStyles: Record<string, string> = {
  carton: "from-purple-400 to-fuchsia-700",
  cold: "from-indigo-300 to-blue-700",
  pepsi: "from-cyan-500 to-blue-700",
  snack: "from-yellow-300 to-orange-600",
  soap: "from-emerald-300 to-green-700",
  water: "from-sky-300 to-cyan-600",
};

export function PosProductImage({
  imageKey,
  label,
}: {
  imageKey: string;
  label: string;
}) {
  return (
    <div
      className={cn(
        "grid aspect-square place-items-center rounded-md bg-gradient-to-br p-2 text-center text-xs font-semibold text-white shadow-inner",
        imageStyles[imageKey] ?? "from-slate-400 to-slate-700",
      )}
    >
      {label}
    </div>
  );
}
