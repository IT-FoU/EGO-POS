"use server";

import { requireSession } from "@/lib/auth/session";
import { tenantFromSession, writeFailure, writeSuccess } from "@/lib/db/write-context";
import { completePrismaSale } from "@/features/pos/prisma-repository";

export async function completeSaleAction(input: Parameters<typeof completePrismaSale>[0]) {
  try {
    return writeSuccess(await completePrismaSale(input, tenantFromSession(await requireSession())));
  } catch (error) {
    return writeFailure(error);
  }
}
