export type PosProduct = {
  id: string;
  barcode: string;
  sku: string;
  nameLo: string;
  nameEn: string;
  categoryName: string;
  imageKey: string;
  unitName: string;
  priceLak: number;
  stockQty: number;
};

export type PosCartItem = PosProduct & {
  quantity: number;
};

export type HeldSale = {
  id: string;
  saleNo: string;
  createdAt: string;
  itemCount: number;
  totalLak: number;
  items: PosCartItem[];
};

export type PaymentMode = "cash" | "qr" | "mixed";
