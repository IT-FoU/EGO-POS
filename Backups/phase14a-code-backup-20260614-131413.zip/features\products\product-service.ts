import {
  mockCategories,
  mockProductImages,
  mockProducts,
} from "@/features/products/mock-data";
import type { Category, MockProductImage, Product } from "@/features/products/types";
import { isDemoMode } from "@/lib/demo-mode";
import {
  getPrismaCategories,
  getPrismaProductById,
  getPrismaProductImages,
  getPrismaProducts,
} from "@/features/products/prisma-repository";

export async function getProducts(): Promise<Product[]> {
  if (!isDemoMode()) {
    return getPrismaProducts();
  }

  return mockProducts;
}

export async function getProductById(productId: string): Promise<Product | null> {
  if (!isDemoMode()) {
    return getPrismaProductById(productId);
  }

  return mockProducts.find((product) => product.id === productId) ?? null;
}

export async function getCategories(): Promise<Category[]> {
  if (!isDemoMode()) {
    return getPrismaCategories();
  }

  return mockCategories;
}

export async function getMockProductImages(): Promise<MockProductImage[]> {
  if (!isDemoMode()) {
    return getPrismaProductImages();
  }

  return mockProductImages;
}
