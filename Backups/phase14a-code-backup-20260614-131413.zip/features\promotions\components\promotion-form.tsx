"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { ArrowLeft, Gift, Save } from "lucide-react";
import type { MembershipLevel } from "@/features/customers/types";
import type { Category, Product } from "@/features/products/types";
import { formatLak, formatPromotionType } from "@/features/promotions/format";
import type { PromotionType } from "@/features/promotions/types";

const promotionTypes: PromotionType[] = [
  "percentage",
  "fixed_amount",
  "buy_x_get_y",
  "combo_set",
  "member_discount",
];

export function PromotionForm({
  categories,
  membershipLevels,
  products,
}: {
  categories: Category[];
  membershipLevels: MembershipLevel[];
  products: Product[];
}) {
  const [message, setMessage] = useState<string | null>(null);
  const [type, setType] = useState<PromotionType>("percentage");
  const [priority, setPriority] = useState(10);
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>([
    products[0]?.id ?? "",
  ].filter(Boolean));
  const [selectedCategoryIds, setSelectedCategoryIds] = useState<string[]>([
    categories[0]?.id ?? "",
  ].filter(Boolean));
  const [selectedLevels, setSelectedLevels] = useState<string[]>(
    membershipLevels.map((level) => level.id),
  );

  const preview = useMemo(() => {
    const selectedProducts = products.filter((product) =>
      selectedProductIds.includes(product.id),
    );
    const subtotal = selectedProducts.reduce(
      (total, product) => total + product.sellingPriceLak,
      0,
    );
    const discount =
      type === "percentage" || type === "member_discount"
        ? Math.round(subtotal * 0.1)
        : type === "fixed_amount"
          ? Math.min(subtotal, 5000)
          : type === "combo_set"
            ? Math.max(subtotal - 15000, 0)
            : selectedProducts[0]?.sellingPriceLak ?? 0;

    return {
      discount,
      subtotal,
      total: Math.max(subtotal - discount, 0),
    };
  }, [products, selectedProductIds, type]);

  function toggleValue(value: string, current: string[], setter: (values: string[]) => void) {
    setter(
      current.includes(value)
        ? current.filter((item) => item !== value)
        : [...current, value],
    );
  }

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage("Promotion saved locally with mock data. Prisma persistence can be connected later.");
  }

  return (
    <form className="flex flex-col gap-6" onSubmit={handleSubmit}>
      <section className="rounded-lg border border-border bg-card p-6">
        <Link
          className="inline-flex items-center gap-2 text-sm text-muted-foreground transition hover:text-foreground"
          href="/promotions"
        >
          <ArrowLeft aria-hidden="true" />
          Back to promotions
        </Link>
        <div className="mt-5 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <div className="grid size-12 place-items-center rounded-md bg-primary/10 text-primary">
              <Gift aria-hidden="true" />
            </div>
            <h1 className="mt-4 text-3xl font-semibold">Create promotion</h1>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">
              Create percentage, fixed amount, buy-x-get-y, combo set, or member
              discount promotions with product, category, and membership targeting.
            </p>
          </div>
          <button
            className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground transition hover:opacity-90"
            type="submit"
          >
            <Save aria-hidden="true" />
            Save locally
          </button>
        </div>
      </section>

      {message ? (
        <div className="rounded-md border border-success/40 bg-success/10 px-4 py-3 text-sm text-success">
          {message}
        </div>
      ) : null}

      <section className="grid gap-6 xl:grid-cols-[1fr_360px]">
        <div className="flex flex-col gap-6">
          <section className="rounded-lg border border-border bg-card p-5">
            <h2 className="text-lg font-semibold">Promotion information</h2>
            <div className="mt-5 grid gap-4 md:grid-cols-2">
              <Field label="Promotion Code">
                <input className="field-input font-mono" name="promotionCode" placeholder="PROMO-NEW" required />
              </Field>
              <Field label="Promotion Name">
                <input className="field-input" name="promotionName" placeholder="Promotion name" required />
              </Field>
              <Field label="Promotion Type">
                <select className="field-input" name="promotionType" value={type} onChange={(event) => setType(event.target.value as PromotionType)}>
                  {promotionTypes.map((promotionType) => (
                    <option key={promotionType} value={promotionType}>
                      {formatPromotionType(promotionType)}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Priority">
                <input className="field-input" min="1" name="priority" type="number" value={priority} onChange={(event) => setPriority(Number(event.target.value))} />
              </Field>
              <Field label="Start Date">
                <input className="field-input" name="startDate" type="date" required />
              </Field>
              <Field label="End Date">
                <input className="field-input" name="endDate" type="date" required />
              </Field>
              <Field label="Status">
                <select className="field-input" name="status" defaultValue="active">
                  <option value="active">Active</option>
                  <option value="scheduled">Scheduled</option>
                  <option value="inactive">Inactive</option>
                  <option value="expired">Expired</option>
                </select>
              </Field>
              <div className="md:col-span-2">
                <Field label="Description">
                  <textarea className="min-h-28 w-full rounded-md border border-border bg-background p-3 text-sm outline-none transition focus:border-primary" name="description" placeholder="Promotion description" />
                </Field>
              </div>
            </div>
          </section>

          <TargetSelector
            label="Applicable Products"
            values={products.map((product) => ({
              id: product.id,
              label: `${product.nameEn} / ${product.sku}`,
            }))}
            selectedValues={selectedProductIds}
            onToggle={(value) => toggleValue(value, selectedProductIds, setSelectedProductIds)}
          />
          <TargetSelector
            label="Applicable Categories"
            values={categories.map((category) => ({
              id: category.id,
              label: category.nameEn,
            }))}
            selectedValues={selectedCategoryIds}
            onToggle={(value) => toggleValue(value, selectedCategoryIds, setSelectedCategoryIds)}
          />
          <TargetSelector
            label="Membership Levels"
            values={membershipLevels.map((level) => ({
              id: level.id,
              label: `${level.name} (${level.discountPercent}% default)`,
            }))}
            selectedValues={selectedLevels}
            onToggle={(value) => toggleValue(value, selectedLevels, setSelectedLevels)}
          />
        </div>

        <aside className="rounded-lg border border-border bg-card p-5 xl:sticky xl:top-28 xl:self-start">
          <h2 className="text-lg font-semibold">Simulation preview</h2>
          <dl className="mt-5 flex flex-col gap-4 text-sm">
            <Summary label="Example cart subtotal" value={`${formatLak(preview.subtotal)} LAK`} />
            <Summary label="Example discount" value={`-${formatLak(preview.discount)} LAK`} />
            <Summary label="Example cart total" value={`${formatLak(preview.total)} LAK`} />
            <Summary label="Selected products" value={String(selectedProductIds.length)} />
            <Summary label="Selected categories" value={String(selectedCategoryIds.length)} />
            <Summary label="Membership levels" value={String(selectedLevels.length)} />
            <Summary label="Database status" value="Mock data mode" />
          </dl>
        </aside>
      </section>
    </form>
  );
}

function Field({ children, label }: { children: React.ReactNode; label: string }) {
  return (
    <label className="flex flex-col gap-2 text-sm font-medium">
      {label}
      {children}
    </label>
  );
}

function Summary({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="mt-1 font-semibold">{value}</dd>
    </div>
  );
}

function TargetSelector({
  label,
  onToggle,
  selectedValues,
  values,
}: {
  label: string;
  onToggle: (value: string) => void;
  selectedValues: string[];
  values: Array<{ id: string; label: string }>;
}) {
  return (
    <section className="rounded-lg border border-border bg-card p-5">
      <h2 className="text-lg font-semibold">{label}</h2>
      <div className="mt-4 grid gap-3 md:grid-cols-2">
        {values.map((value) => (
          <label
            className="flex items-center gap-3 rounded-md border border-border bg-background p-3 text-sm"
            key={value.id}
          >
            <input
              className="size-5 accent-[var(--primary)]"
              type="checkbox"
              checked={selectedValues.includes(value.id)}
              onChange={() => onToggle(value.id)}
            />
            <span>{value.label}</span>
          </label>
        ))}
      </div>
    </section>
  );
}
