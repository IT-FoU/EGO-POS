import type { InventoryItem } from "@/features/inventory/types";
import { formatQuantity } from "@/features/inventory/format";
import { InventoryImage } from "@/features/inventory/components/inventory-image";
import { ExpiryBadge, StockAlert } from "@/features/inventory/components/inventory-status";

export function StockOverviewTable({ items }: { items: InventoryItem[] }) {
  return (
    <section className="overflow-hidden rounded-lg border border-border bg-card">
      <div className="border-b border-border p-5">
        <h2 className="text-lg font-semibold">Stock overview / ພາບລວມສະຕັອກ</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Quantity is shown by product base unit and selected warehouse.
        </p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[1040px] text-left text-sm">
          <thead className="border-b border-border bg-background text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Image</th>
              <th className="px-4 py-3">Product</th>
              <th className="px-4 py-3">Barcode</th>
              <th className="px-4 py-3">SKU</th>
              <th className="px-4 py-3">Category</th>
              <th className="px-4 py-3 text-right">Quantity</th>
              <th className="px-4 py-3 text-right">Min</th>
              <th className="px-4 py-3">Expiry</th>
              <th className="px-4 py-3">Alert</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr className="border-b border-border last:border-b-0" key={item.id}>
                <td className="px-4 py-4">
                  <InventoryImage imageKey={item.imageKey} label={item.productNameEn} />
                </td>
                <td className="px-4 py-4">
                  <div className="font-semibold">{item.productNameLo}</div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    {item.productNameEn}
                  </div>
                </td>
                <td className="px-4 py-4 font-mono text-xs">{item.barcode}</td>
                <td className="px-4 py-4 font-mono text-xs">{item.sku}</td>
                <td className="px-4 py-4">{item.category}</td>
                <td className="px-4 py-4 text-right font-semibold">
                  {formatQuantity(item.quantity, item.baseUnit)}
                </td>
                <td className="px-4 py-4 text-right">
                  {formatQuantity(item.minStock, item.baseUnit)}
                </td>
                <td className="px-4 py-4">
                  <ExpiryBadge expiryDate={item.expiryDate} />
                </td>
                <td className="px-4 py-4">
                  <StockAlert quantity={item.quantity} minStock={item.minStock} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
