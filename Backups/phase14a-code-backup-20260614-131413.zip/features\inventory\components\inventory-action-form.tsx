"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { ArrowLeft, Barcode, ClipboardCheck, PackagePlus, Save, SlidersHorizontal } from "lucide-react";
import type { InventoryItem, Warehouse } from "@/features/inventory/types";
import { WarehouseSelector } from "@/features/inventory/components/warehouse-selector";

type Mode = "stock-in" | "adjustment" | "count";

const modeConfig: Record<
  Mode,
  {
    title: string;
    subtitle: string;
    icon: typeof PackagePlus;
    quantityLabel: string;
    noteLabel: string;
  }
> = {
  "stock-in": {
    title: "Stock In",
    subtitle: "Receive products into a selected warehouse using mock data.",
    icon: PackagePlus,
    quantityLabel: "Quantity received",
    noteLabel: "Receiving note",
  },
  adjustment: {
    title: "Stock Adjustment",
    subtitle: "Adjust stock for damaged, expired, lost, or correction reasons.",
    icon: SlidersHorizontal,
    quantityLabel: "Adjustment quantity",
    noteLabel: "Adjustment reason",
  },
  count: {
    title: "Stock Count",
    subtitle: "Record counted quantity and calculate variance locally.",
    icon: ClipboardCheck,
    quantityLabel: "Counted quantity",
    noteLabel: "Count note",
  },
};

export function InventoryActionForm({
  items,
  mode,
  warehouses,
}: {
  items: InventoryItem[];
  mode: Mode;
  warehouses: Warehouse[];
}) {
  const config = modeConfig[mode];
  const Icon = config.icon;
  const [selectedWarehouseId, setSelectedWarehouseId] = useState(warehouses[0]?.id ?? "all");
  const [selectedItemId, setSelectedItemId] = useState("");
  const [quantity, setQuantity] = useState(0);
  const [message, setMessage] = useState<string | null>(null);

  const warehouseItems = useMemo(
    () => items.filter((item) => item.warehouseId === selectedWarehouseId),
    [items, selectedWarehouseId],
  );
  const selectedItem = warehouseItems.find((item) => item.id === selectedItemId);
  const variance = selectedItem ? quantity - selectedItem.quantity : 0;

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage(`${config.title} saved locally with mock data. Movement history wiring comes with PostgreSQL.`);
  }

  return (
    <form className="flex flex-col gap-6" onSubmit={handleSubmit}>
      <section className="rounded-lg border border-border bg-card p-6">
        <Link
          className="inline-flex items-center gap-2 text-sm text-muted-foreground transition hover:text-foreground"
          href="/inventory"
        >
          <ArrowLeft aria-hidden="true" />
          Back to inventory
        </Link>
        <div className="mt-5 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <div className="grid size-12 place-items-center rounded-md bg-primary/10 text-primary">
              <Icon aria-hidden="true" />
            </div>
            <h1 className="mt-4 text-3xl font-semibold">{config.title}</h1>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">
              {config.subtitle}
            </p>
          </div>
          <button
            className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground transition hover:opacity-90"
            type="submit"
          >
            <Save aria-hidden="true" />
            Save locally
          </button>
        </div>
      </section>

      {message ? (
        <div className="rounded-md border border-success/40 bg-success/10 px-4 py-3 text-sm text-success">
          {message}
        </div>
      ) : null}

      <section className="grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="rounded-lg border border-border bg-card p-5">
          <h2 className="text-lg font-semibold">Transaction details</h2>
          <div className="mt-5 grid gap-4 md:grid-cols-2">
            <WarehouseSelector
              selectedWarehouseId={selectedWarehouseId}
              warehouses={warehouses}
              onChange={(warehouseId) => {
                setSelectedWarehouseId(warehouseId);
                setSelectedItemId("");
              }}
            />
            <label className="flex flex-col gap-2 text-sm font-medium">
              Product
              <select
                className="field-input"
                value={selectedItemId}
                onChange={(event) => setSelectedItemId(event.target.value)}
                required
              >
                <option value="">Select product</option>
                {warehouseItems.map((item) => (
                  <option value={item.id} key={item.id}>
                    {item.productNameEn} / {item.sku}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex flex-col gap-2 text-sm font-medium">
              Barcode / SKU
              <div className="relative">
                <Barcode
                  aria-hidden="true"
                  className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                />
                <input
                  className="field-input pl-10 font-mono"
                  value={selectedItem ? `${selectedItem.barcode} / ${selectedItem.sku}` : ""}
                  readOnly
                  placeholder="Select product to fill"
                />
              </div>
            </label>
            <label className="flex flex-col gap-2 text-sm font-medium">
              {config.quantityLabel}
              <input
                className="field-input"
                type="number"
                min={mode === "adjustment" ? undefined : 0}
                value={quantity}
                onChange={(event) => setQuantity(Number(event.target.value))}
                required
              />
            </label>
            <label className="flex flex-col gap-2 text-sm font-medium md:col-span-2">
              {config.noteLabel}
              <textarea
                className="min-h-28 rounded-md border border-border bg-background p-3 text-sm outline-none transition focus:border-primary"
                placeholder="Add a short note for stock movement history"
              />
            </label>
          </div>
        </div>

        <aside className="rounded-lg border border-border bg-card p-5">
          <h2 className="text-lg font-semibold">Preview</h2>
          <dl className="mt-5 flex flex-col gap-4 text-sm">
            <div>
              <dt className="text-muted-foreground">Current quantity</dt>
              <dd className="mt-1 font-semibold">
                {selectedItem ? `${selectedItem.quantity} ${selectedItem.baseUnit}` : "Select product"}
              </dd>
            </div>
            <div>
              <dt className="text-muted-foreground">
                {mode === "count" ? "Variance" : "New quantity preview"}
              </dt>
              <dd className="mt-1 font-semibold">
                {selectedItem
                  ? mode === "count"
                    ? `${variance > 0 ? "+" : ""}${variance} ${selectedItem.baseUnit}`
                    : `${selectedItem.quantity + quantity} ${selectedItem.baseUnit}`
                  : "Select product"}
              </dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Database status</dt>
              <dd className="mt-1 font-semibold text-warning">Mock data mode</dd>
            </div>
          </dl>
        </aside>
      </section>
    </form>
  );
}
