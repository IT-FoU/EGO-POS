"use server";

import { requireSession } from "@/lib/auth/session";
import { tenantFromSession, writeFailure, writeSuccess } from "@/lib/db/write-context";
import {
  archivePrismaProduct,
  createPrismaProduct,
  deletePrismaCategory,
  deletePrismaProduct,
  updatePrismaProduct,
  upsertPrismaCategory,
  type ProductWriteInput,
} from "@/features/products/prisma-repository";

async function tenant() {
  return tenantFromSession(await requireSession());
}

export async function createProductAction(input: ProductWriteInput) {
  try { return writeSuccess(await createPrismaProduct(input, await tenant())); } catch (error) { return writeFailure(error); }
}

export async function updateProductAction(productId: string, input: Partial<ProductWriteInput>) {
  try { return writeSuccess(await updatePrismaProduct(productId, input, await tenant())); } catch (error) { return writeFailure(error); }
}

export async function archiveProductAction(productId: string) {
  try { return writeSuccess(await archivePrismaProduct(productId, await tenant())); } catch (error) { return writeFailure(error); }
}

export async function deleteProductAction(productId: string) {
  try { return writeSuccess(await deletePrismaProduct(productId, await tenant())); } catch (error) { return writeFailure(error); }
}

export async function upsertCategoryAction(input: { id?: string; nameEn?: string; nameLo: string; parentId?: string }) {
  try { return writeSuccess(await upsertPrismaCategory(input, await tenant())); } catch (error) { return writeFailure(error); }
}

export async function deleteCategoryAction(categoryId: string) {
  try { return writeSuccess(await deletePrismaCategory(categoryId, await tenant())); } catch (error) { return writeFailure(error); }
}
