import type { Category, Product, ProductStatus, ProductUnit } from "@/features/products/types";

type PrismaProduct = Record<string, any>;
type PrismaCategory = Record<string, any>;

function toNumber(value: unknown) {
  return value == null ? 0 : Number(value);
}

export function mapPrismaProductUnit(unit: Record<string, any>): ProductUnit {
  return {
    barcode: unit.barcode ?? "",
    conversionQty: toNumber(unit.conversionQty),
    id: unit.id,
    isBaseUnit: Boolean(unit.isBaseUnit),
    sellingPriceLak: toNumber(unit.sellingPriceLak),
    unitName: unit.unitName ?? "",
  };
}

export function mapPrismaProduct(product: PrismaProduct): Product {
  return {
    barcode: product.barcode ?? "",
    brandName: product.brand?.name ?? "",
    categoryId: product.categoryId ?? "",
    categoryName: product.category?.nameEn ?? product.category?.nameLo ?? "",
    costPriceLak: toNumber(product.costPriceLak),
    description: product.description ?? undefined,
    id: product.id,
    imageUrl: product.imageUrl ?? undefined,
    minStock: toNumber(product.minStock),
    nameEn: product.nameEn ?? "",
    nameLo: product.nameLo,
    productCode: product.productCode ?? undefined,
    sellingPriceLak: toNumber(product.sellingPriceLak),
    sku: product.sku ?? "",
    status: (product.status ?? "active") as ProductStatus,
    supplierName: product.supplier?.companyName ?? product.supplier?.name ?? "",
    tags: Array.isArray(product.tags) ? product.tags.map(String) : [],
    units: (product.units ?? []).map(mapPrismaProductUnit),
    updatedAt: product.updatedAt?.toISOString?.().slice(0, 10) ?? "",
  };
}

export function mapPrismaCategory(category: PrismaCategory): Category {
  return {
    id: category.id,
    nameEn: category.nameEn ?? "",
    nameLo: category.nameLo,
    parentName: category.parent?.nameEn ?? category.parent?.nameLo ?? undefined,
    productCount: category._count?.products ?? 0,
    status: category.isActive === false ? "inactive" : "active",
  };
}
