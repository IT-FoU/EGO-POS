import { deletePrismaCategory, upsertPrismaCategory } from "@/features/products/prisma-repository";
import { runWrite } from "@/lib/api/write-response";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return runWrite((tenant, body) => upsertPrismaCategory({ ...body, id }, tenant), request);
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return runWrite((tenant) => deletePrismaCategory(id, tenant));
}
