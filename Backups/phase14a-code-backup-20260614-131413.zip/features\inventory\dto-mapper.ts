import type { InventoryItem, StockMovement, Warehouse } from "@/features/inventory/types";

type Row = Record<string, any>;

function toNumber(value: unknown) {
  return value == null ? 0 : Number(value);
}

function formatDate(value: unknown) {
  return value instanceof Date ? value.toISOString().slice(0, 10) : undefined;
}

export function mapPrismaWarehouse(warehouse: Row): Warehouse {
  return {
    branchName: warehouse.branch?.name ?? "",
    id: warehouse.id,
    name: warehouse.name,
    type: warehouse.type,
  };
}

export function mapPrismaInventoryBalance(balance: Row): InventoryItem {
  const product = balance.product ?? {};
  const baseUnit = product.units?.find((unit: Row) => unit.isBaseUnit) ?? product.units?.[0];
  const lot = product.inventoryLots?.[0];

  return {
    barcode: product.barcode ?? "",
    baseUnit: baseUnit?.unitName ?? "Piece",
    category: product.category?.nameEn ?? product.category?.nameLo ?? "",
    daysWithoutSale: 0,
    expiryDate: formatDate(lot?.expiryDate),
    id: balance.id,
    imageKey: product.imageUrl ?? "generic",
    lastMovementAt: balance.updatedAt?.toISOString?.().slice(0, 10) ?? "",
    minStock: toNumber(product.minStock),
    productNameEn: product.nameEn ?? "",
    productNameLo: product.nameLo ?? "",
    quantity: toNumber(balance.quantity),
    sku: product.sku ?? "",
    warehouseId: balance.warehouseId,
  };
}

export function mapPrismaStockMovement(movement: Row): StockMovement {
  const movementType =
    movement.movementType === "purchase"
      ? "stock_in"
      : movement.movementType === "transfer_in" || movement.movementType === "transfer_out" || movement.movementType === "expired"
        ? movement.movementType
        : "adjustment";

  return {
    afterQty: toNumber(movement.afterQty),
    beforeQty: toNumber(movement.beforeQty),
    createdAt: movement.createdAt?.toISOString?.().replace("T", " ").slice(0, 16) ?? "",
    createdBy: movement.createdBy ?? "",
    id: movement.id,
    movementType,
    note: movement.note ?? "",
    productName: movement.product?.nameEn ?? movement.product?.nameLo ?? "",
    quantity: toNumber(movement.quantity),
    sku: movement.product?.sku ?? "",
    warehouseId: movement.warehouseId,
  };
}
