"use server";

import { requireSession } from "@/lib/auth/session";
import { tenantFromSession, writeFailure, writeSuccess } from "@/lib/db/write-context";
import { archivePrismaPromotion, createPrismaPromotion, updatePrismaPromotion } from "@/features/promotions/prisma-repository";

async function tenant() {
  return tenantFromSession(await requireSession());
}

export async function createPromotionAction(input: Parameters<typeof createPrismaPromotion>[0]) {
  try { return writeSuccess(await createPrismaPromotion(input, await tenant())); } catch (error) { return writeFailure(error); }
}

export async function updatePromotionAction(promotionId: string, input: Record<string, unknown>) {
  try { return writeSuccess(await updatePrismaPromotion(promotionId, input, await tenant())); } catch (error) { return writeFailure(error); }
}

export async function archivePromotionAction(promotionId: string) {
  try { return writeSuccess(await archivePrismaPromotion(promotionId, await tenant())); } catch (error) { return writeFailure(error); }
}
