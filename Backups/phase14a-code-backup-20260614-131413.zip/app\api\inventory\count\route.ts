import { createStockCount } from "@/features/inventory/prisma-repository";
import { runWrite } from "@/lib/api/write-response";

export async function POST(request: Request) {
  return runWrite((tenant, body) => createStockCount(body, tenant), request);
}
