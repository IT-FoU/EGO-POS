import { redirect } from "next/navigation";
import { getCurrentSession } from "@/lib/auth/session";
import { LoginForm } from "@/components/auth/login-form";
import { APP_NAME, PRIMARY_STORE, SLOGAN } from "@/lib/constants";
import { getDictionary } from "@/lib/i18n/dictionaries";

export default async function LoginPage({
  searchParams,
}: {
  searchParams?: Promise<{ locale?: string }>;
}) {
  const session = await getCurrentSession();

  if (session?.user) {
    redirect("/dashboard");
  }

  const params = await searchParams;
  const dictionary = getDictionary(params?.locale);

  return (
    <main className="flex min-h-screen items-center justify-center bg-background px-4 py-10">
      <section className="grid w-full max-w-5xl overflow-hidden rounded-lg border border-border bg-card shadow-xl md:grid-cols-[1fr_420px]">
        <div className="flex min-h-[540px] flex-col justify-between bg-[#0b1522] p-8 text-white md:p-10">
          <div>
            <div className="text-sm font-semibold text-primary">{APP_NAME}</div>
            <h1 className="mt-8 max-w-lg text-4xl font-semibold leading-tight md:text-5xl">
              {SLOGAN}
            </h1>
            <p className="mt-5 max-w-md text-base leading-7 text-slate-300">
              Modern POS foundation for {PRIMARY_STORE}, built for multi-company,
              multi-branch retail operations in Laos.
            </p>
          </div>
          <div className="grid gap-3 text-sm text-slate-300">
            <div>Base currency: LAK</div>
            <div>Languages: Lao / English</div>
            <div>Cloud-ready: Next.js + PostgreSQL + Prisma</div>
          </div>
        </div>
        <div className="flex flex-col justify-center p-6 md:p-8">
          <div className="mb-8">
            <h2 className="text-2xl font-semibold text-card-foreground">
              {dictionary.loginTitle}
            </h2>
            <p className="mt-2 text-sm text-muted-foreground">
              {dictionary.loginSubtitle}
            </p>
          </div>
          <LoginForm dictionary={dictionary} />
        </div>
      </section>
    </main>
  );
}
