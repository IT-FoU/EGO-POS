import { prisma } from "@/lib/db/prisma";
import type { CustomerPayment, CustomerPurchase } from "@/features/customers/types";
import type { TenantContext } from "@/lib/db/write-context";
import { numberValue, optionalString, stringValue, withTenantTransaction } from "@/lib/db/write-context";
import {
  mapPrismaCustomer,
  mapPrismaCustomerPayment,
  mapPrismaCustomerPurchase,
  mapPrismaMembershipLevel,
} from "@/features/customers/dto-mapper";

const db = prisma as any;

export async function getPrismaCustomersSnapshot() {
  const [customers, levels, payments, purchases] = await Promise.all([
    db.customer.findMany({
      include: { loyaltyPointLedger: true, membershipLevel: true },
      orderBy: { createdAt: "desc" },
    }),
    db.membershipLevel.findMany({ orderBy: { minSpendLak: "asc" } }),
    db.customerPayment.findMany({ orderBy: { paidAt: "desc" } }),
    db.sale.findMany({ include: { payments: true }, orderBy: { createdAt: "desc" } }),
  ]);

  return {
    customers: customers.map(mapPrismaCustomer),
    levels: levels.map(mapPrismaMembershipLevel),
    payments: payments.map(mapPrismaCustomerPayment),
    purchases: purchases.map(mapPrismaCustomerPurchase),
  };
}

export async function getPrismaCustomers() {
  const { customers } = await getPrismaCustomersSnapshot();
  return customers;
}

export async function getPrismaCustomerById(customerId: string) {
  const customer = await db.customer.findUnique({
    include: { loyaltyPointLedger: true, membershipLevel: true },
    where: { id: customerId },
  });

  return customer ? mapPrismaCustomer(customer) : undefined;
}

export async function getPrismaCustomerDetail(customerId: string) {
  const [snapshot, customer] = await Promise.all([
    getPrismaCustomersSnapshot(),
    getPrismaCustomerById(customerId),
  ]);

  return {
    customer,
    levels: snapshot.levels,
    payments: snapshot.payments.filter((payment: CustomerPayment) => payment.customerId === customerId),
    purchases: snapshot.purchases.filter((purchase: CustomerPurchase) => purchase.customerId === customerId),
  };
}

export async function createPrismaCustomer(input: {
  address?: string;
  birthday?: string;
  creditLimit?: number;
  customerCode?: string;
  email?: string;
  fullName: string;
  membershipLevelId?: string;
  notes?: string;
  openingBalance?: number;
  phone?: string;
}, tenant: TenantContext) {
  return withTenantTransaction({
    action: "create",
    module: "customers",
    newData: input,
    tenant,
    write: async (tx) => tx.customer.create({
      data: {
        address: optionalString(input.address),
        birthday: input.birthday ? new Date(input.birthday) : undefined,
        companyId: tenant.companyId,
        creditLimit: numberValue(input.creditLimit),
        customerCode: optionalString(input.customerCode),
        email: optionalString(input.email),
        fullName: stringValue(input.fullName),
        membershipLevelId: optionalString(input.membershipLevelId),
        notes: optionalString(input.notes),
        openingBalance: numberValue(input.openingBalance),
        outstandingBalance: numberValue(input.openingBalance),
        phone: optionalString(input.phone),
      },
    }),
  });
}

export async function updatePrismaCustomer(customerId: string, input: Record<string, unknown>, tenant: TenantContext) {
  return withTenantTransaction({
    action: "update",
    module: "customers",
    newData: { customerId, ...input },
    tenant,
    write: async (tx) => {
      const existing = await tx.customer.findFirstOrThrow({ where: { companyId: tenant.companyId, id: customerId } });
      return tx.customer.update({ data: input, where: { id: existing.id } });
    },
  });
}

export async function archivePrismaCustomer(customerId: string, tenant: TenantContext) {
  return updatePrismaCustomer(customerId, { status: "inactive" }, tenant);
}

export async function createPrismaCustomerPayment(input: {
  amountLak: number;
  customerId: string;
  note?: string;
  paymentMethod?: string;
  paymentNo?: string;
}, tenant: TenantContext) {
  return withTenantTransaction({
    action: "payment",
    module: "customers",
    newData: input,
    tenant,
    write: async (tx) => tx.customerPayment.create({
      data: {
        amountLak: numberValue(input.amountLak),
        companyId: tenant.companyId,
        customerId: input.customerId,
        note: optionalString(input.note),
        paymentMethod: input.paymentMethod === "bank" ? "transfer" : (input.paymentMethod ?? "cash"),
        paymentNo: optionalString(input.paymentNo),
      },
    }),
  });
}
