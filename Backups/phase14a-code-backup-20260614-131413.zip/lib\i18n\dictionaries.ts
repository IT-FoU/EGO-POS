import type { SupportedLocale } from "@/lib/constants";

export const dictionaries = {
  lo: {
    loginTitle: "ເຂົ້າສູ່ລະບົບ IGO POS",
    loginSubtitle: "ສໍາລັບ Go BOX ແລະຮ້ານຄ້າປີກ",
    username: "ຊື່ຜູ້ໃຊ້",
    password: "ລະຫັດຜ່ານ",
    signIn: "ເຂົ້າລະບົບ",
    dashboard: "ໜ້າຫຼັກ",
    pos: "POS",
    products: "ສິນຄ້າ",
    inventory: "ສາງສິນຄ້າ",
    customers: "ລູກຄ້າ",
    suppliers: "ຜູ້ສະໜອງ",
    promotions: "ໂປຣໂມຊັນ",
    reports: "ລາຍງານ",
    finance: "ການເງິນ",
    settings: "ຕັ້ງຄ່າ",
  },
  en: {
    loginTitle: "Sign in to IGO POS",
    loginSubtitle: "For Go BOX and retail stores",
    username: "Username",
    password: "Password",
    signIn: "Sign in",
    dashboard: "Dashboard",
    pos: "POS",
    products: "Products",
    inventory: "Inventory",
    customers: "Customers",
    suppliers: "Suppliers",
    promotions: "Promotions",
    reports: "Reports",
    finance: "Finance",
    settings: "Settings",
  },
} satisfies Record<SupportedLocale, Record<string, string>>;

export function getDictionary(locale: string | undefined) {
  return dictionaries[locale === "en" ? "en" : "lo"];
}
