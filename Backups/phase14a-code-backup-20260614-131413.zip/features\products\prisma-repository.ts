import { prisma } from "@/lib/db/prisma";
import { mapPrismaCategory, mapPrismaProduct } from "@/features/products/dto-mapper";
import type { TenantContext } from "@/lib/db/write-context";
import { numberValue, optionalString, stringValue, withTenantTransaction } from "@/lib/db/write-context";

const db = prisma as any;

export async function getPrismaProducts() {
  const products = await db.product.findMany({
    include: { brand: true, category: true, supplier: true, units: true },
    orderBy: { updatedAt: "desc" },
  });

  return products.map(mapPrismaProduct);
}

export async function getPrismaProductById(productId: string) {
  const product = await db.product.findUnique({
    include: { brand: true, category: true, supplier: true, units: true },
    where: { id: productId },
  });

  return product ? mapPrismaProduct(product) : null;
}

export async function getPrismaCategories() {
  const categories = await db.category.findMany({
    include: { _count: { select: { products: true } }, parent: true },
    orderBy: [{ nameEn: "asc" }, { nameLo: "asc" }],
  });

  return categories.map(mapPrismaCategory);
}

export async function getPrismaProductImages() {
  return [];
}

export type ProductWriteInput = {
  barcode?: string;
  brandId?: string;
  categoryId?: string;
  costPriceLak?: number;
  description?: string;
  imageUrl?: string;
  minStock?: number;
  nameEn?: string;
  nameLo: string;
  productCode?: string;
  sellingPriceLak?: number;
  sku?: string;
  status?: string;
  supplierId?: string;
  tags?: string[];
};

export async function createPrismaProduct(input: ProductWriteInput, tenant: TenantContext) {
  return withTenantTransaction({
    action: "create",
    module: "products",
    newData: input,
    tenant,
    write: async (tx) => tx.product.create({
      data: {
        barcode: optionalString(input.barcode),
        brandId: optionalString(input.brandId),
        categoryId: optionalString(input.categoryId),
        companyId: tenant.companyId,
        costPriceLak: numberValue(input.costPriceLak),
        description: optionalString(input.description),
        imageUrl: optionalString(input.imageUrl),
        minStock: numberValue(input.minStock),
        nameEn: optionalString(input.nameEn),
        nameLo: stringValue(input.nameLo),
        productCode: optionalString(input.productCode),
        sellingPriceLak: numberValue(input.sellingPriceLak),
        sku: optionalString(input.sku),
        status: input.status ?? "active",
        supplierId: optionalString(input.supplierId),
        tags: input.tags ?? [],
      },
    }),
  });
}

export async function updatePrismaProduct(productId: string, input: Partial<ProductWriteInput>, tenant: TenantContext) {
  return withTenantTransaction({
    action: "update",
    module: "products",
    newData: { productId, ...input },
    tenant,
    write: async (tx) => {
      const existing = await tx.product.findFirstOrThrow({ where: { companyId: tenant.companyId, id: productId } });
      return tx.product.update({
        data: {
          barcode: input.barcode === undefined ? undefined : optionalString(input.barcode),
          brandId: input.brandId === undefined ? undefined : optionalString(input.brandId),
          categoryId: input.categoryId === undefined ? undefined : optionalString(input.categoryId),
          costPriceLak: input.costPriceLak === undefined ? undefined : numberValue(input.costPriceLak),
          description: input.description === undefined ? undefined : optionalString(input.description),
          imageUrl: input.imageUrl === undefined ? undefined : optionalString(input.imageUrl),
          minStock: input.minStock === undefined ? undefined : numberValue(input.minStock),
          nameEn: input.nameEn === undefined ? undefined : optionalString(input.nameEn),
          nameLo: input.nameLo === undefined ? undefined : stringValue(input.nameLo),
          productCode: input.productCode === undefined ? undefined : optionalString(input.productCode),
          sellingPriceLak: input.sellingPriceLak === undefined ? undefined : numberValue(input.sellingPriceLak),
          sku: input.sku === undefined ? undefined : optionalString(input.sku),
          status: input.status,
          supplierId: input.supplierId === undefined ? undefined : optionalString(input.supplierId),
          tags: input.tags,
        },
        where: { id: existing.id },
      });
    },
  });
}

export async function archivePrismaProduct(productId: string, tenant: TenantContext) {
  return updatePrismaProduct(productId, { status: "deleted" }, tenant);
}

export async function deletePrismaProduct(productId: string, tenant: TenantContext) {
  return withTenantTransaction({
    action: "delete",
    module: "products",
    oldData: { productId },
    tenant,
    write: async (tx) => {
      const existing = await tx.product.findFirstOrThrow({ where: { companyId: tenant.companyId, id: productId } });
      return tx.product.delete({ where: { id: existing.id } });
    },
  });
}

export async function upsertPrismaCategory(input: {
  id?: string;
  nameEn?: string;
  nameLo: string;
  parentId?: string;
}, tenant: TenantContext) {
  return withTenantTransaction({
    action: input.id ? "update" : "create",
    module: "categories",
    newData: input,
    tenant,
    write: async (tx) => input.id
      ? tx.category.update({
          data: {
            nameEn: optionalString(input.nameEn),
            nameLo: stringValue(input.nameLo),
            parentId: optionalString(input.parentId),
          },
          where: { id: input.id },
        })
      : tx.category.create({
          data: {
            companyId: tenant.companyId,
            nameEn: optionalString(input.nameEn),
            nameLo: stringValue(input.nameLo),
            parentId: optionalString(input.parentId),
          },
        }),
  });
}

export async function deletePrismaCategory(categoryId: string, tenant: TenantContext) {
  return withTenantTransaction({
    action: "delete",
    module: "categories",
    oldData: { categoryId },
    tenant,
    write: async (tx) => {
      const existing = await tx.category.findFirstOrThrow({ where: { companyId: tenant.companyId, id: categoryId } });
      return tx.category.delete({ where: { id: existing.id } });
    },
  });
}
