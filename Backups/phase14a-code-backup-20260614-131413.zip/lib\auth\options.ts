import type { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { compare } from "bcryptjs";
import { prisma } from "@/lib/db/prisma";

export const authOptions: NextAuthOptions = {
  session: {
    strategy: "jwt",
  },
  pages: {
    signIn: "/login",
  },
  providers: [
    CredentialsProvider({
      name: "Username and Password",
      credentials: {
        username: { label: "Username", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const username = credentials?.username?.trim();
        const password = credentials?.password;

        if (!username || !password) {
          return null;
        }

        const user = await prisma.user.findFirst({
          where: {
            OR: [{ username }, { email: username }],
            status: "active",
          },
          include: {
            companies: {
              where: { status: "active" },
              include: { company: true },
              take: 1,
            },
            roles: {
              include: { role: true },
            },
          },
        });

        if (!user) {
          return null;
        }

        const isValidPassword = await compare(password, user.passwordHash);

        if (!isValidPassword) {
          await prisma.loginHistory.create({
            data: {
              userId: user.id,
              status: "failed",
            },
          });
          return null;
        }

        await prisma.loginHistory.create({
          data: {
            userId: user.id,
            status: "success",
          },
        });

        const activeCompany = user.companies[0]?.company;

        return {
          id: user.id,
          name: user.fullName,
          email: user.email,
          username: user.username,
          activeCompanyId: activeCompany?.id,
          activeCompanyName: activeCompany?.name,
          locale: user.preferredLocale,
          roles: user.roles.map((entry) => entry.role.name),
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.username = user.username;
        token.activeCompanyId = user.activeCompanyId;
        token.activeCompanyName = user.activeCompanyName;
        token.locale = user.locale;
        token.roles = user.roles;
      }

      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.sub ?? "";
        session.user.username = token.username;
        session.user.activeCompanyId = token.activeCompanyId;
        session.user.activeCompanyName = token.activeCompanyName;
        session.user.locale = token.locale;
        session.user.roles = token.roles;
      }

      return session;
    },
  },
};
