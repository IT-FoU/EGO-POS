"use server";

import { requireSession } from "@/lib/auth/session";
import { tenantFromSession, writeFailure, writeSuccess } from "@/lib/db/write-context";
import {
  archivePrismaCustomer,
  createPrismaCustomer,
  createPrismaCustomerPayment,
  updatePrismaCustomer,
} from "@/features/customers/prisma-repository";

async function tenant() {
  return tenantFromSession(await requireSession());
}

export async function createCustomerAction(input: Parameters<typeof createPrismaCustomer>[0]) {
  try { return writeSuccess(await createPrismaCustomer(input, await tenant())); } catch (error) { return writeFailure(error); }
}

export async function updateCustomerAction(customerId: string, input: Record<string, unknown>) {
  try { return writeSuccess(await updatePrismaCustomer(customerId, input, await tenant())); } catch (error) { return writeFailure(error); }
}

export async function archiveCustomerAction(customerId: string) {
  try { return writeSuccess(await archivePrismaCustomer(customerId, await tenant())); } catch (error) { return writeFailure(error); }
}

export async function createCustomerPaymentAction(input: Parameters<typeof createPrismaCustomerPayment>[0]) {
  try { return writeSuccess(await createPrismaCustomerPayment(input, await tenant())); } catch (error) { return writeFailure(error); }
}
