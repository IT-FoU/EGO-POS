import { NextResponse } from "next/server";
import { requireSession } from "@/lib/auth/session";
import { tenantFromSession, writeFailure, writeSuccess } from "@/lib/db/write-context";

export async function runWrite<T>(handler: (tenant: ReturnType<typeof tenantFromSession>, body: any) => Promise<T>, request?: Request) {
  try {
    const session = await requireSession();
    const tenant = tenantFromSession(session);
    const body = request ? await request.json().catch(() => ({})) : {};
    return NextResponse.json(writeSuccess(await handler(tenant, body)));
  } catch (error) {
    return NextResponse.json(writeFailure(error), { status: 400 });
  }
}
