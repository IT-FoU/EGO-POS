"use client";

import type { Session } from "next-auth";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BarChart3,
  Boxes,
  Building2,
  CircleDollarSign,
  Gift,
  LayoutDashboard,
  Package,
  Settings,
  ShoppingCart,
  Truck,
  Users,
} from "lucide-react";
import { SignOutButton } from "@/components/layout/sign-out-button";
import { APP_NAME, SLOGAN } from "@/lib/constants";

const navigation = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { label: "POS", href: "/pos", icon: ShoppingCart },
  { label: "Products", href: "/products", icon: Package },
  { label: "Inventory", href: "/inventory", icon: Boxes },
  { label: "Purchasing", href: "/purchasing", icon: Truck },
  { label: "Customers", href: "/customers", icon: Users },
  { label: "Suppliers", href: "/suppliers", icon: Building2 },
  { label: "Promotions", href: "/promotions", icon: Gift },
  { label: "Reports", href: "/reports", icon: BarChart3 },
  { label: "Finance", href: "#", icon: CircleDollarSign },
  { label: "Settings", href: "#", icon: Settings },
];

export function DashboardShell({
  children,
  demoMode,
  session,
}: {
  children: React.ReactNode;
  demoMode: boolean;
  session: Session;
}) {
  const pathname = usePathname();

  return (
    <div className="min-h-screen bg-background text-foreground">
      <aside className="fixed inset-y-0 left-0 hidden w-72 border-r border-border bg-card lg:flex lg:flex-col">
        <div className="border-b border-border p-6">
          <div className="flex items-center gap-3">
            <div className="grid size-11 place-items-center rounded-md bg-primary text-lg font-bold text-primary-foreground">
              I
            </div>
            <div>
              <div className="text-lg font-semibold">{APP_NAME}</div>
              <div className="text-xs text-muted-foreground">{SLOGAN}</div>
            </div>
          </div>
        </div>
        <nav className="flex flex-1 flex-col gap-1 overflow-y-auto p-4">
          {navigation.map((item) => {
            const Icon = item.icon;
            const isActive =
              item.href === "/dashboard"
                ? pathname === "/dashboard"
                : item.href !== "#" && pathname.startsWith(item.href);

            return (
              <Link
                className={
                  isActive
                    ? "flex items-center gap-3 rounded-md bg-primary px-3 py-3 text-sm font-semibold text-primary-foreground"
                    : "flex items-center gap-3 rounded-md px-3 py-3 text-sm text-muted-foreground transition hover:bg-background hover:text-foreground"
                }
                href={item.href}
                key={item.label}
              >
                <Icon aria-hidden="true" />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </aside>
      <div className="lg:pl-72">
        <header className="sticky top-0 z-10 border-b border-border bg-background/95 px-4 py-4 backdrop-blur md:px-8">
          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="text-sm text-muted-foreground">
                {session.user.activeCompanyName ?? "IGO POS"}
              </div>
              <div className="text-base font-semibold">
                {session.user.name ?? session.user.username}
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="hidden text-right text-sm text-muted-foreground sm:block">
                {demoMode ? "Demo mode: mock data" : "Cloud-ready foundation"}
              </div>
              <SignOutButton />
            </div>
          </div>
          <nav className="mt-4 flex gap-2 overflow-x-auto lg:hidden">
            {navigation
              .filter((item) => item.href !== "#")
              .map((item) => {
                const Icon = item.icon;
                const isActive =
                  item.href === "/dashboard"
                    ? pathname === "/dashboard"
                    : pathname.startsWith(item.href);

                return (
                  <Link
                    className={
                      isActive
                        ? "inline-flex h-10 shrink-0 items-center gap-2 rounded-md bg-primary px-3 text-sm font-semibold text-primary-foreground"
                        : "inline-flex h-10 shrink-0 items-center gap-2 rounded-md border border-border px-3 text-sm text-muted-foreground"
                    }
                    href={item.href}
                    key={item.label}
                  >
                    <Icon aria-hidden="true" />
                    {item.label}
                  </Link>
                );
              })}
          </nav>
        </header>
        <main className="mx-auto w-full max-w-7xl px-4 py-6 md:px-8">
          {children}
        </main>
      </div>
    </div>
  );
}
