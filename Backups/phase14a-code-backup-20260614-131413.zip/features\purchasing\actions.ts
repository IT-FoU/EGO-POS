"use server";

import { requireSession } from "@/lib/auth/session";
import { tenantFromSession, writeFailure, writeSuccess } from "@/lib/db/write-context";
import { createPurchaseOrder, createSupplierPayment, receiveGoods } from "@/features/purchasing/prisma-repository";

async function tenant() {
  return tenantFromSession(await requireSession());
}

export async function createPurchaseOrderAction(input: Parameters<typeof createPurchaseOrder>[0]) {
  try { return writeSuccess(await createPurchaseOrder(input, await tenant())); } catch (error) { return writeFailure(error); }
}

export async function receiveGoodsAction(input: Parameters<typeof receiveGoods>[0]) {
  try { return writeSuccess(await receiveGoods(input, await tenant())); } catch (error) { return writeFailure(error); }
}

export async function createSupplierPaymentAction(input: Parameters<typeof createSupplierPayment>[0]) {
  try { return writeSuccess(await createSupplierPayment(input, await tenant())); } catch (error) { return writeFailure(error); }
}
