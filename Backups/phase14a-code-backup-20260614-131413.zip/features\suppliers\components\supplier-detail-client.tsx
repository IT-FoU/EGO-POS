import Link from "next/link";
import {
  ArrowLeft,
  Building2,
  CircleDollarSign,
  Clock3,
  CreditCard,
  PackageCheck,
  ReceiptText,
  Truck,
} from "lucide-react";
import type {
  Supplier,
  SupplierPayment,
  SupplierPurchaseOrder,
  SupplierReceiving,
} from "@/features/suppliers/types";
import { PurchaseStatusBadge } from "@/features/suppliers/components/purchase-status-badge";
import { SupplierStatusBadge } from "@/features/suppliers/components/supplier-status-badge";
import { formatDays, formatLak } from "@/features/suppliers/format";

export function SupplierDetailClient({
  payments,
  purchaseOrders,
  receivings,
  supplier,
}: {
  payments: SupplierPayment[];
  purchaseOrders: SupplierPurchaseOrder[];
  receivings: SupplierReceiving[];
  supplier: Supplier;
}) {
  const totalPurchaseValue = purchaseOrders.reduce(
    (total, purchaseOrder) => total + purchaseOrder.totalLak,
    0,
  );
  const lastPurchaseDate =
    purchaseOrders
      .map((purchaseOrder) => purchaseOrder.purchaseDate)
      .sort()
      .at(-1) ?? "No purchases";
  const remainingCredit = Math.max(
    supplier.creditLimitLak - supplier.outstandingBalanceLak,
    0,
  );

  return (
    <div className="flex flex-col gap-6">
      <section className="rounded-lg border border-border bg-card p-6">
        <Link
          className="inline-flex items-center gap-2 text-sm text-muted-foreground transition hover:text-foreground"
          href="/suppliers"
        >
          <ArrowLeft aria-hidden="true" />
          Back to suppliers
        </Link>
        <div className="mt-5 flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
          <div className="flex items-start gap-4">
            <div className="grid size-14 shrink-0 place-items-center rounded-md bg-primary/10 text-primary">
              <Building2 aria-hidden="true" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-3xl font-semibold">{supplier.companyName}</h1>
                <SupplierStatusBadge status={supplier.status} />
              </div>
              <p className="mt-2 font-mono text-sm text-muted-foreground">
                {supplier.supplierCode} / {supplier.taxNumber}
              </p>
              <div className="mt-4 grid gap-2 text-sm text-muted-foreground md:grid-cols-2">
                <span>Contact: {supplier.contactPerson}</span>
                <span>{supplier.phone}</span>
                <span>{supplier.email}</span>
                <span>{supplier.address}</span>
              </div>
            </div>
          </div>
          <div className="rounded-md border border-border bg-background p-4 text-sm lg:w-80">
            <div className="text-muted-foreground">Notes</div>
            <p className="mt-2 leading-6">{supplier.notes}</p>
          </div>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <Metric icon={ReceiptText} label="Total orders" value={String(purchaseOrders.length)} />
        <Metric icon={CircleDollarSign} label="Total purchase value" value={`${formatLak(totalPurchaseValue)} LAK`} />
        <Metric icon={Clock3} label="Average delivery time" value={formatDays(supplier.averageDeliveryDays)} />
        <Metric icon={Truck} label="Last purchase date" value={lastPurchaseDate} />
      </section>

      <section className="grid gap-6 xl:grid-cols-[360px_1fr]">
        <aside className="flex flex-col gap-6">
          <section className="rounded-lg border border-border bg-card p-5">
            <h2 className="text-lg font-semibold">Supplier profile</h2>
            <dl className="mt-5 flex flex-col gap-4 text-sm">
              <Summary label="Contact person" value={supplier.contactPerson} />
              <Summary label="Phone" value={supplier.phone} />
              <Summary label="Email" value={supplier.email} />
              <Summary label="Tax number" value={supplier.taxNumber} />
            </dl>
          </section>

          <section className="rounded-lg border border-border bg-card p-5">
            <h2 className="text-lg font-semibold">Credit terms</h2>
            <dl className="mt-5 flex flex-col gap-4 text-sm">
              <Summary label="Credit terms" value={supplier.creditTerms} />
              <Summary label="Credit limit" value={`${formatLak(supplier.creditLimitLak)} LAK`} />
              <Summary label="Outstanding balance" value={`${formatLak(supplier.outstandingBalanceLak)} LAK`} />
              <Summary label="Remaining credit" value={`${formatLak(remainingCredit)} LAK`} />
              <Summary label="Opening balance" value={`${formatLak(supplier.openingBalanceLak)} LAK`} />
            </dl>
          </section>
        </aside>

        <div className="flex flex-col gap-6">
          <section className="rounded-lg border border-border bg-card p-5">
            <h2 className="text-lg font-semibold">Purchase orders history</h2>
            <div className="mt-5 overflow-x-auto">
              <table className="w-full min-w-[800px] text-left text-sm">
                <thead className="border-b border-border text-xs uppercase text-muted-foreground">
                  <tr>
                    <th className="px-3 py-3">PO</th>
                    <th className="px-3 py-3">Date</th>
                    <th className="px-3 py-3">Warehouse</th>
                    <th className="px-3 py-3 text-right">Total</th>
                    <th className="px-3 py-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {purchaseOrders.map((purchaseOrder) => (
                    <tr className="border-b border-border last:border-b-0" key={purchaseOrder.id}>
                      <td className="px-3 py-3 font-mono">{purchaseOrder.purchaseNo}</td>
                      <td className="px-3 py-3">{purchaseOrder.purchaseDate}</td>
                      <td className="px-3 py-3">{purchaseOrder.warehouseName}</td>
                      <td className="px-3 py-3 text-right font-semibold">{formatLak(purchaseOrder.totalLak)} LAK</td>
                      <td className="px-3 py-3">
                        <PurchaseStatusBadge status={purchaseOrder.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {purchaseOrders.length === 0 ? (
              <p className="mt-4 text-sm text-muted-foreground">No mock purchase orders for this supplier.</p>
            ) : null}
          </section>

          <section className="rounded-lg border border-border bg-card p-5">
            <h2 className="text-lg font-semibold">Receiving history</h2>
            <div className="mt-5 overflow-x-auto">
              <table className="w-full min-w-[760px] text-left text-sm">
                <thead className="border-b border-border text-xs uppercase text-muted-foreground">
                  <tr>
                    <th className="px-3 py-3">Receive no</th>
                    <th className="px-3 py-3">PO</th>
                    <th className="px-3 py-3">Date</th>
                    <th className="px-3 py-3">Warehouse</th>
                    <th className="px-3 py-3 text-right">Items</th>
                    <th className="px-3 py-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {receivings.map((receiving) => (
                    <tr className="border-b border-border last:border-b-0" key={receiving.id}>
                      <td className="px-3 py-3 font-mono">{receiving.receiveNo}</td>
                      <td className="px-3 py-3 font-mono">{receiving.purchaseNo}</td>
                      <td className="px-3 py-3">{receiving.receivedDate}</td>
                      <td className="px-3 py-3">{receiving.warehouseName}</td>
                      <td className="px-3 py-3 text-right">{receiving.itemCount}</td>
                      <td className="px-3 py-3 capitalize">{receiving.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {receivings.length === 0 ? (
              <p className="mt-4 text-sm text-muted-foreground">No mock receiving records for this supplier.</p>
            ) : null}
          </section>

          <section className="rounded-lg border border-border bg-card p-5">
            <h2 className="text-lg font-semibold">Payment history</h2>
            <div className="mt-5 overflow-x-auto">
              <table className="w-full min-w-[760px] text-left text-sm">
                <thead className="border-b border-border text-xs uppercase text-muted-foreground">
                  <tr>
                    <th className="px-3 py-3">Payment no</th>
                    <th className="px-3 py-3">Date</th>
                    <th className="px-3 py-3">Method</th>
                    <th className="px-3 py-3">Note</th>
                    <th className="px-3 py-3 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {payments.map((payment) => (
                    <tr className="border-b border-border last:border-b-0" key={payment.id}>
                      <td className="px-3 py-3 font-mono">{payment.paymentNo}</td>
                      <td className="px-3 py-3">{payment.paymentDate}</td>
                      <td className="px-3 py-3 capitalize">{payment.method}</td>
                      <td className="px-3 py-3 text-muted-foreground">{payment.note}</td>
                      <td className="px-3 py-3 text-right font-semibold">{formatLak(payment.amountLak)} LAK</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {payments.length === 0 ? (
              <p className="mt-4 text-sm text-muted-foreground">No mock payments for this supplier.</p>
            ) : null}
          </section>
        </div>
      </section>
    </div>
  );
}

function Metric({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof ReceiptText;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-lg border border-border bg-card p-5">
      <div className="flex items-center justify-between gap-4">
        <div>
          <div className="text-sm text-muted-foreground">{label}</div>
          <div className="mt-2 text-2xl font-semibold">{value}</div>
        </div>
        <div className="grid size-11 place-items-center rounded-md bg-primary/10 text-primary">
          <Icon aria-hidden="true" />
        </div>
      </div>
    </div>
  );
}

function Summary({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="mt-1 font-semibold">{value}</dd>
    </div>
  );
}
