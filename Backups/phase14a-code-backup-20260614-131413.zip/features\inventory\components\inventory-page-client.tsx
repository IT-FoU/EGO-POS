"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { ClipboardCheck, PackagePlus, SlidersHorizontal } from "lucide-react";
import type { InventoryItem, StockMovement, Warehouse } from "@/features/inventory/types";
import { InventoryDashboardCards } from "@/features/inventory/components/inventory-dashboard-cards";
import { InventoryAlertLists } from "@/features/inventory/components/inventory-alert-lists";
import { StockMovementHistory } from "@/features/inventory/components/stock-movement-history";
import { StockOverviewTable } from "@/features/inventory/components/stock-overview-table";
import { WarehouseSelector } from "@/features/inventory/components/warehouse-selector";

export function InventoryPageClient({
  items,
  movements,
  warehouses,
}: {
  items: InventoryItem[];
  movements: StockMovement[];
  warehouses: Warehouse[];
}) {
  const [selectedWarehouseId, setSelectedWarehouseId] = useState("all");

  const filteredItems = useMemo(
    () =>
      selectedWarehouseId === "all"
        ? items
        : items.filter((item) => item.warehouseId === selectedWarehouseId),
    [items, selectedWarehouseId],
  );

  const filteredMovements = useMemo(
    () =>
      selectedWarehouseId === "all"
        ? movements
        : movements.filter((movement) => movement.warehouseId === selectedWarehouseId),
    [movements, selectedWarehouseId],
  );

  return (
    <div className="flex flex-col gap-6">
      <section className="rounded-lg border border-border bg-card p-6">
        <div className="flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between">
          <div>
            <p className="text-sm font-medium text-primary">Inventory Management</p>
            <h1 className="mt-2 text-3xl font-semibold">Inventory / ສາງສິນຄ້າ</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">
              Multi-warehouse stock overview with low stock, dead stock, expiry,
              stock movement history, and base-unit quantities. Mock data only.
            </p>
          </div>
          <div className="flex flex-col gap-3 md:flex-row md:items-end">
            <WarehouseSelector
              selectedWarehouseId={selectedWarehouseId}
              warehouses={warehouses}
              onChange={setSelectedWarehouseId}
            />
            <div className="flex gap-2">
              <Link
                className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground transition hover:opacity-90"
                href="/inventory/stock-in"
              >
                <PackagePlus aria-hidden="true" />
                Stock In
              </Link>
              <Link
                className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-border px-4 text-sm font-semibold transition hover:border-primary"
                href="/inventory/count"
              >
                <ClipboardCheck aria-hidden="true" />
                Count
              </Link>
            </div>
          </div>
        </div>
      </section>

      <InventoryDashboardCards items={filteredItems} />

      <nav className="flex flex-wrap gap-2">
        <Link className="inline-flex h-10 items-center gap-2 rounded-md border border-border px-3 text-sm font-semibold hover:border-primary" href="/inventory/stock-in">
          <PackagePlus aria-hidden="true" />
          Stock In
        </Link>
        <Link className="inline-flex h-10 items-center gap-2 rounded-md border border-border px-3 text-sm font-semibold hover:border-primary" href="/inventory/adjustment">
          <SlidersHorizontal aria-hidden="true" />
          Adjustment
        </Link>
        <Link className="inline-flex h-10 items-center gap-2 rounded-md border border-border px-3 text-sm font-semibold hover:border-primary" href="/inventory/count">
          <ClipboardCheck aria-hidden="true" />
          Stock Count
        </Link>
      </nav>

      <StockOverviewTable items={filteredItems} />
      <InventoryAlertLists items={filteredItems} />
      <StockMovementHistory movements={filteredMovements} />
    </div>
  );
}
