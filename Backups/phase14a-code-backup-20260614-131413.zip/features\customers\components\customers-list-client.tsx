"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Eye, Plus, Search, Users } from "lucide-react";
import type { Customer, CustomerStatus } from "@/features/customers/types";
import { CustomerStatusBadge } from "@/features/customers/components/customer-status-badge";
import { MembershipBadge } from "@/features/customers/components/membership-badge";
import { calculateAvailablePoints, formatLak } from "@/features/customers/format";

const statusOptions: Array<CustomerStatus | "all"> = ["all", "active", "inactive"];

export function CustomersListClient({ customers }: { customers: Customer[] }) {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<CustomerStatus | "all">("all");

  const filteredCustomers = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();

    return customers.filter((customer) => {
      const matchesQuery =
        normalizedQuery.length === 0 ||
        [
          customer.customerCode,
          customer.fullName,
          customer.phone,
          customer.email,
          customer.membershipLevel,
        ]
          .join(" ")
          .toLowerCase()
          .includes(normalizedQuery);
      const matchesStatus = status === "all" || customer.status === status;

      return matchesQuery && matchesStatus;
    });
  }, [customers, query, status]);

  const activeCustomers = customers.filter((customer) => customer.status === "active").length;
  const totalOutstanding = customers.reduce(
    (total, customer) => total + customer.outstandingBalanceLak,
    0,
  );
  const totalPoints = customers.reduce(
    (total, customer) =>
      total + calculateAvailablePoints(customer.earnedPoints, customer.redeemedPoints),
    0,
  );

  return (
    <div className="flex flex-col gap-6">
      <section className="rounded-lg border border-border bg-card p-6">
        <div className="flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between">
          <div>
            <p className="text-sm font-medium text-primary">Customer Management</p>
            <h1 className="mt-2 text-3xl font-semibold">Customers / ລູກຄ້າ</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">
              Customer profiles with membership, loyalty points, credit limit,
              outstanding balance, and purchase history foundations. Mock data
              only.
            </p>
          </div>
          <Link
            className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground transition hover:opacity-90"
            href="/customers/new"
          >
            <Plus aria-hidden="true" />
            Create customer
          </Link>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        <Metric icon={Users} label="Active customers" value={String(activeCustomers)} />
        <Metric icon={Search} label="Available points" value={formatLak(totalPoints)} />
        <Metric icon={Eye} label="Outstanding balance" value={`${formatLak(totalOutstanding)} LAK`} />
      </section>

      <section className="rounded-lg border border-border bg-card p-5">
        <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
          <div className="flex min-w-0 flex-1 flex-col gap-3 md:flex-row">
            <label className="relative flex-1">
              <Search
                aria-hidden="true"
                className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
              />
              <input
                className="field-input pl-10"
                placeholder="Search code, name, phone, email, membership"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
              />
            </label>
            <select
              className="field-input md:w-48"
              value={status}
              onChange={(event) => setStatus(event.target.value as CustomerStatus | "all")}
              aria-label="Filter by customer status"
            >
              {statusOptions.map((option) => (
                <option value={option} key={option}>
                  {option === "all" ? "All statuses" : option}
                </option>
              ))}
            </select>
          </div>
        </div>
      </section>

      <section className="overflow-hidden rounded-lg border border-border bg-card">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1040px] border-collapse text-left text-sm">
            <thead className="border-b border-border bg-background text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-semibold">Customer code</th>
                <th className="px-4 py-3 font-semibold">Name</th>
                <th className="px-4 py-3 font-semibold">Phone</th>
                <th className="px-4 py-3 font-semibold">Membership</th>
                <th className="px-4 py-3 text-right font-semibold">Points</th>
                <th className="px-4 py-3 text-right font-semibold">Outstanding</th>
                <th className="px-4 py-3 font-semibold">Status</th>
                <th className="px-4 py-3 text-right font-semibold">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredCustomers.map((customer) => (
                <tr className="border-b border-border last:border-b-0" key={customer.id}>
                  <td className="px-4 py-4 font-mono text-xs">{customer.customerCode}</td>
                  <td className="px-4 py-4">
                    <div className="font-semibold">{customer.fullName}</div>
                    <div className="mt-1 text-xs text-muted-foreground">{customer.email}</div>
                  </td>
                  <td className="px-4 py-4">{customer.phone}</td>
                  <td className="px-4 py-4">
                    <MembershipBadge level={customer.membershipLevel} />
                  </td>
                  <td className="px-4 py-4 text-right font-semibold">
                    {formatLak(
                      calculateAvailablePoints(
                        customer.earnedPoints,
                        customer.redeemedPoints,
                      ),
                    )}
                  </td>
                  <td className="px-4 py-4 text-right font-semibold">
                    {formatLak(customer.outstandingBalanceLak)} LAK
                  </td>
                  <td className="px-4 py-4">
                    <CustomerStatusBadge status={customer.status} />
                  </td>
                  <td className="px-4 py-4 text-right">
                    <Link
                      className="inline-flex h-9 items-center gap-2 rounded-md border border-border px-3 text-xs font-semibold transition hover:border-primary"
                      href={`/customers/${customer.id}`}
                    >
                      <Eye aria-hidden="true" />
                      View
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredCustomers.length === 0 ? (
          <div className="p-8 text-center text-sm text-muted-foreground">
            No customers match the current search and filters.
          </div>
        ) : null}
      </section>
    </div>
  );
}

function Metric({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Users;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-lg border border-border bg-card p-5">
      <div className="flex items-center justify-between gap-4">
        <div>
          <div className="text-sm text-muted-foreground">{label}</div>
          <div className="mt-2 text-2xl font-semibold">{value}</div>
        </div>
        <div className="grid size-11 place-items-center rounded-md bg-primary/10 text-primary">
          <Icon aria-hidden="true" />
        </div>
      </div>
    </div>
  );
}
