"use client";

import { useEffect, useState } from "react";

type Theme = "dark" | "light";

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>("dark");

  useEffect(() => {
    const savedTheme = window.localStorage.getItem("igo-theme") as Theme | null;
    const nextTheme = savedTheme === "light" ? "light" : "dark";
    setTheme(nextTheme);
    document.documentElement.classList.toggle("dark", nextTheme === "dark");
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    window.localStorage.setItem("igo-theme", theme);
  }, [theme]);

  return (
    <div data-theme={theme}>
      {children}
      <button
        className="fixed bottom-4 right-4 rounded-md border border-border bg-card px-3 py-2 text-sm text-card-foreground shadow-sm transition hover:border-primary"
        type="button"
        onClick={() => setTheme((current) => (current === "dark" ? "light" : "dark"))}
        aria-label="Toggle dark and light theme"
      >
        {theme === "dark" ? "Light" : "Dark"}
      </button>
    </div>
  );
}
