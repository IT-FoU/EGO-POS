import { AlertTriangle, Boxes, CalendarClock, PackageSearch } from "lucide-react";
import type { InventoryItem } from "@/features/inventory/types";
import { getDaysUntil } from "@/features/inventory/format";

export function InventoryDashboardCards({ items }: { items: InventoryItem[] }) {
  const totalProducts = items.length;
  const totalQuantity = items.reduce((sum, item) => sum + item.quantity, 0);
  const lowStock = items.filter((item) => item.quantity <= item.minStock).length;
  const deadStock = items.filter((item) => item.daysWithoutSale >= 30).length;
  const expiring = items.filter((item) => {
    const days = getDaysUntil(item.expiryDate);
    return days !== null && days <= 30;
  }).length;

  const cards = [
    { label: "Total products", value: totalProducts, icon: Boxes },
    { label: "Base unit quantity", value: totalQuantity, icon: PackageSearch },
    { label: "Low stock", value: lowStock, icon: AlertTriangle },
    { label: "Dead stock", value: deadStock, icon: PackageSearch },
    { label: "Expiring soon", value: expiring, icon: CalendarClock },
  ];

  return (
    <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
      {cards.map((card) => {
        const Icon = card.icon;

        return (
          <article className="rounded-lg border border-border bg-card p-5" key={card.label}>
            <div className="flex items-center justify-between gap-4">
              <div className="text-sm text-muted-foreground">{card.label}</div>
              <div className="grid size-10 place-items-center rounded-md bg-primary/10 text-primary">
                <Icon aria-hidden="true" />
              </div>
            </div>
            <div className="mt-4 text-2xl font-semibold">{card.value}</div>
          </article>
        );
      })}
    </section>
  );
}
