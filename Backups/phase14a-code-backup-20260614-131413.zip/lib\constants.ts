export const APP_NAME = "IGO POS";
export const COMPANY_NAME = "IGO Technology";
export const PRIMARY_STORE = "Go BOX";
export const SLOGAN = "Simple. Smart. Fast.";
export const BASE_CURRENCY = "LAK";
export const SUPPORTED_LOCALES = ["lo", "en"] as const;
export type SupportedLocale = (typeof SUPPORTED_LOCALES)[number];
