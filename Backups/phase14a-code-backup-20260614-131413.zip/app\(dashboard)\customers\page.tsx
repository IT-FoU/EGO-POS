import { CustomersListClient } from "@/features/customers/components/customers-list-client";
import { getCustomersSnapshot } from "@/features/customers/customer-service";

export default async function CustomersPage() {
  const { customers } = await getCustomersSnapshot();

  return <CustomersListClient customers={customers} />;
}
