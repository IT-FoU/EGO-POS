"use client";

import { useMemo, useState } from "react";
import {
  Barcode,
  Banknote,
  CircleDollarSign,
  Clock3,
  Minus,
  Percent,
  Plus,
  Printer,
  QrCode,
  ReceiptText,
  RotateCcw,
  Search,
  ShoppingCart,
  Trash2,
} from "lucide-react";
import type { HeldSale, PaymentMode, PosCartItem, PosProduct } from "@/features/pos/types";
import { PosProductImage } from "@/features/pos/components/pos-product-image";
import { formatLak } from "@/features/pos/format";
import { cn } from "@/lib/utils";

export function PosPageClient({
  branchName,
  cashierName,
  products,
  taxRatePercent,
}: {
  branchName: string;
  cashierName: string;
  products: PosProduct[];
  taxRatePercent: number;
}) {
  const [barcodeQuery, setBarcodeQuery] = useState("");
  const [productQuery, setProductQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [cartItems, setCartItems] = useState<PosCartItem[]>([]);
  const [discountAmount, setDiscountAmount] = useState(0);
  const [discountPercent, setDiscountPercent] = useState(0);
  const [taxEnabled, setTaxEnabled] = useState(true);
  const [paymentMode, setPaymentMode] = useState<PaymentMode>("cash");
  const [cashAmount, setCashAmount] = useState(0);
  const [qrAmount, setQrAmount] = useState(0);
  const [heldSales, setHeldSales] = useState<HeldSale[]>([]);
  const [selectedHeldSaleId, setSelectedHeldSaleId] = useState("");
  const [receiptOpen, setReceiptOpen] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const categories = useMemo(
    () => ["All", ...Array.from(new Set(products.map((product) => product.categoryName)))],
    [products],
  );

  const filteredProducts = useMemo(() => {
    const normalized = productQuery.trim().toLowerCase();
    return products.filter((product) => {
      const categoryMatch =
        selectedCategory === "All" || product.categoryName === selectedCategory;
      const queryMatch =
        !normalized ||
        product.nameEn.toLowerCase().includes(normalized) ||
        product.nameLo.toLowerCase().includes(normalized) ||
        product.sku.toLowerCase().includes(normalized) ||
        product.barcode.includes(productQuery.trim());

      return categoryMatch && queryMatch;
    });
  }, [productQuery, products, selectedCategory]);

  const subtotal = cartItems.reduce(
    (total, item) => total + item.priceLak * item.quantity,
    0,
  );
  const percentDiscountValue = Math.round(subtotal * (discountPercent / 100));
  const discountTotal = Math.min(subtotal, discountAmount + percentDiscountValue);
  const taxableAmount = Math.max(subtotal - discountTotal, 0);
  const taxAmount = taxEnabled ? Math.round(taxableAmount * (taxRatePercent / 100)) : 0;
  const totalAmount = taxableAmount + taxAmount;
  const paidAmount =
    paymentMode === "cash"
      ? cashAmount
      : paymentMode === "qr"
        ? qrAmount
        : cashAmount + qrAmount;
  const changeAmount = Math.max(paidAmount - totalAmount, 0);
  const dueAmount = Math.max(totalAmount - paidAmount, 0);

  function addToCart(product: PosProduct) {
    setCartItems((current) => {
      const existing = current.find((item) => item.id === product.id);
      if (existing) {
        return current.map((item) =>
          item.id === product.id
            ? { ...item, quantity: Math.min(item.quantity + 1, item.stockQty) }
            : item,
        );
      }

      return [...current, { ...product, quantity: 1 }];
    });
    setMessage(`${product.nameEn} added to cart.`);
  }

  function scanBarcode() {
    const normalized = barcodeQuery.trim();
    if (!normalized) {
      setMessage("Enter or scan a barcode first.");
      return;
    }

    const product = products.find((item) => item.barcode === normalized || item.sku === normalized);
    if (!product) {
      setMessage("No product found for barcode or SKU.");
      return;
    }

    addToCart(product);
    setBarcodeQuery("");
  }

  function updateQuantity(productId: string, quantity: number) {
    setCartItems((current) =>
      current
        .map((item) =>
          item.id === productId
            ? { ...item, quantity: Math.max(1, Math.min(quantity, item.stockQty)) }
            : item,
        )
        .filter((item) => item.quantity > 0),
    );
  }

  function removeItem(productId: string) {
    setCartItems((current) => current.filter((item) => item.id !== productId));
  }

  function holdSale() {
    if (cartItems.length === 0) {
      setMessage("Cart is empty. Add items before holding a sale.");
      return;
    }

    const heldSale: HeldSale = {
      id: `hold-${Date.now()}`,
      saleNo: `HOLD-${String(heldSales.length + 1).padStart(3, "0")}`,
      createdAt: new Date().toLocaleString("en-GB"),
      itemCount: cartItems.reduce((total, item) => total + item.quantity, 0),
      totalLak: totalAmount,
      items: cartItems,
    };

    setHeldSales((current) => [heldSale, ...current]);
    clearSale();
    setMessage(`${heldSale.saleNo} held locally.`);
  }

  function resumeSale() {
    const heldSale = heldSales.find((sale) => sale.id === selectedHeldSaleId);
    if (!heldSale) {
      setMessage("Select a held sale to resume.");
      return;
    }

    setCartItems(heldSale.items);
    setHeldSales((current) => current.filter((sale) => sale.id !== heldSale.id));
    setSelectedHeldSaleId("");
    setMessage(`${heldSale.saleNo} resumed.`);
  }

  function completeSale() {
    if (cartItems.length === 0) {
      setMessage("Cart is empty.");
      return;
    }
    if (dueAmount > 0) {
      setMessage("Payment is not complete yet.");
      return;
    }

    setReceiptOpen(true);
    setMessage("Sale completed locally. Receipt is ready to print.");
  }

  function clearSale() {
    setCartItems([]);
    setDiscountAmount(0);
    setDiscountPercent(0);
    setCashAmount(0);
    setQrAmount(0);
    setPaymentMode("cash");
  }

  return (
    <div className="flex flex-col gap-5">
      <section className="rounded-lg border border-border bg-card p-5">
        <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
          <div>
            <p className="text-sm font-medium text-primary">POS Sales System</p>
            <h1 className="mt-2 text-3xl font-semibold">Cashier POS / ຂາຍໜ້າຮ້ານ</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">
              Fast barcode checkout with product search, cart discounts, tax,
              cash, QR, mixed payment, hold/resume, and receipt preview. Mock
              data only.
            </p>
          </div>
          <div className="grid gap-2 text-sm sm:grid-cols-3 xl:min-w-[520px]">
            <InfoPill label="Branch" value={branchName} />
            <InfoPill label="Cashier" value={cashierName} />
            <InfoPill label="Currency" value="LAK" />
          </div>
        </div>
      </section>

      {message ? (
        <div className="rounded-md border border-primary/30 bg-primary/10 px-4 py-3 text-sm text-primary">
          {message}
        </div>
      ) : null}

      <section className="grid gap-5 xl:grid-cols-[1fr_430px]">
        <div className="flex flex-col gap-5">
          <section className="rounded-lg border border-border bg-card p-4">
            <div className="grid gap-3 lg:grid-cols-[1fr_1fr_auto]">
              <label className="relative">
                <Barcode className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
                <input
                  className="field-input pl-10"
                  placeholder="Scan barcode or SKU"
                  value={barcodeQuery}
                  onChange={(event) => setBarcodeQuery(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter") {
                      event.preventDefault();
                      scanBarcode();
                    }
                  }}
                />
              </label>
              <label className="relative">
                <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
                <input
                  className="field-input pl-10"
                  placeholder="Search product name, Lao, SKU"
                  value={productQuery}
                  onChange={(event) => setProductQuery(event.target.value)}
                />
              </label>
              <button
                className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground transition hover:opacity-90"
                type="button"
                onClick={scanBarcode}
              >
                <Barcode aria-hidden="true" />
                Add scan
              </button>
            </div>
            <div className="mt-4 flex gap-2 overflow-x-auto">
              {categories.map((category) => (
                <button
                  className={cn(
                    "h-10 shrink-0 rounded-md border px-3 text-sm font-semibold transition",
                    selectedCategory === category
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border text-muted-foreground hover:border-primary hover:text-foreground",
                  )}
                  key={category}
                  type="button"
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </section>

          <section className="grid grid-cols-2 gap-3 md:grid-cols-3 2xl:grid-cols-4">
            {filteredProducts.map((product) => (
              <button
                className="rounded-lg border border-border bg-card p-3 text-left transition hover:border-primary hover:shadow-sm"
                key={product.id}
                type="button"
                onClick={() => addToCart(product)}
              >
                <PosProductImage imageKey={product.imageKey} label={product.nameEn} />
                <div className="mt-3 min-h-12">
                  <div className="line-clamp-1 text-sm font-semibold">{product.nameEn}</div>
                  <div className="line-clamp-1 text-xs text-muted-foreground">{product.nameLo}</div>
                </div>
                <div className="mt-3 flex items-end justify-between gap-2">
                  <div>
                    <div className="text-base font-semibold">{formatLak(product.priceLak)}</div>
                    <div className="text-xs text-muted-foreground">LAK / {product.unitName}</div>
                  </div>
                  <span className="rounded-md bg-primary/10 px-2 py-1 text-xs font-semibold text-primary">
                    {product.stockQty}
                  </span>
                </div>
              </button>
            ))}
          </section>
        </div>

        <aside className="flex flex-col gap-5 xl:sticky xl:top-28 xl:self-start">
          <section className="rounded-lg border border-border bg-card">
            <div className="flex items-center justify-between gap-3 border-b border-border p-4">
              <div>
                <h2 className="text-lg font-semibold">Cart / ກະຕ່າ</h2>
                <p className="mt-1 text-xs text-muted-foreground">
                  {cartItems.length} product lines
                </p>
              </div>
              <ShoppingCart className="text-primary" aria-hidden="true" />
            </div>

            <div className="max-h-[360px] overflow-y-auto p-3">
              {cartItems.length === 0 ? (
                <div className="grid min-h-40 place-items-center rounded-md border border-dashed border-border text-center text-sm text-muted-foreground">
                  Scan barcode or tap product to start sale.
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  {cartItems.map((item) => (
                    <div className="rounded-md border border-border p-3" key={item.id}>
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <div className="line-clamp-1 font-semibold">{item.nameEn}</div>
                          <div className="mt-1 font-mono text-xs text-muted-foreground">{item.sku}</div>
                        </div>
                        <button
                          className="grid size-8 shrink-0 place-items-center rounded-md border border-border text-danger"
                          type="button"
                          onClick={() => removeItem(item.id)}
                          aria-label="Remove item"
                        >
                          <Trash2 aria-hidden="true" />
                        </button>
                      </div>
                      <div className="mt-3 flex items-center justify-between gap-3">
                        <div className="inline-flex h-10 items-center rounded-md border border-border">
                          <button className="grid size-10 place-items-center" type="button" onClick={() => updateQuantity(item.id, item.quantity - 1)} aria-label="Decrease quantity">
                            <Minus aria-hidden="true" />
                          </button>
                          <input
                            className="h-10 w-16 border-x border-border bg-transparent text-center text-sm font-semibold outline-none"
                            type="number"
                            min="1"
                            max={item.stockQty}
                            value={item.quantity}
                            onChange={(event) => updateQuantity(item.id, Number(event.target.value))}
                          />
                          <button className="grid size-10 place-items-center" type="button" onClick={() => updateQuantity(item.id, item.quantity + 1)} aria-label="Increase quantity">
                            <Plus aria-hidden="true" />
                          </button>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold">{formatLak(item.priceLak * item.quantity)} LAK</div>
                          <div className="text-xs text-muted-foreground">{formatLak(item.priceLak)} each</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>

          <section className="rounded-lg border border-border bg-card p-4">
            <h2 className="text-lg font-semibold">Totals</h2>
            <div className="mt-4 grid grid-cols-2 gap-3">
              <Field label="Discount amount">
                <input className="field-input" type="number" min="0" value={discountAmount} onChange={(event) => setDiscountAmount(Number(event.target.value))} />
              </Field>
              <Field label="Discount percent">
                <div className="relative">
                  <Percent className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
                  <input className="field-input pr-10" type="number" min="0" max="100" value={discountPercent} onChange={(event) => setDiscountPercent(Number(event.target.value))} />
                </div>
              </Field>
            </div>
            <label className="mt-4 flex items-center justify-between rounded-md border border-border p-3 text-sm font-medium">
              Tax {taxRatePercent}%
              <input
                className="size-5 accent-[var(--primary)]"
                type="checkbox"
                checked={taxEnabled}
                onChange={(event) => setTaxEnabled(event.target.checked)}
              />
            </label>
            <dl className="mt-4 flex flex-col gap-3 text-sm">
              <TotalRow label="Subtotal" value={`${formatLak(subtotal)} LAK`} />
              <TotalRow label="Discount" value={`-${formatLak(discountTotal)} LAK`} />
              <TotalRow label="Tax" value={`${formatLak(taxAmount)} LAK`} />
              <div className="flex items-center justify-between border-t border-border pt-3 text-xl font-semibold">
                <dt>Total</dt>
                <dd>{formatLak(totalAmount)} LAK</dd>
              </div>
            </dl>
          </section>

          <section className="rounded-lg border border-border bg-card p-4">
            <h2 className="text-lg font-semibold">Payment</h2>
            <div className="mt-4 grid grid-cols-3 gap-2">
              <PaymentButton active={paymentMode === "cash"} icon={Banknote} label="Cash" onClick={() => setPaymentMode("cash")} />
              <PaymentButton active={paymentMode === "qr"} icon={QrCode} label="QR" onClick={() => setPaymentMode("qr")} />
              <PaymentButton active={paymentMode === "mixed"} icon={CircleDollarSign} label="Mixed" onClick={() => setPaymentMode("mixed")} />
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {(paymentMode === "cash" || paymentMode === "mixed") ? (
                <Field label="Cash amount">
                  <input className="field-input" type="number" min="0" value={cashAmount} onChange={(event) => setCashAmount(Number(event.target.value))} />
                </Field>
              ) : null}
              {(paymentMode === "qr" || paymentMode === "mixed") ? (
                <Field label="QR amount">
                  <input className="field-input" type="number" min="0" value={qrAmount} onChange={(event) => setQrAmount(Number(event.target.value))} />
                </Field>
              ) : null}
            </div>
            <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
              <Metric label="Paid" value={`${formatLak(paidAmount)} LAK`} />
              <Metric label="Due" value={`${formatLak(dueAmount)} LAK`} />
              <Metric label="Change" value={`${formatLak(changeAmount)} LAK`} />
              <Metric label="Mode" value={paymentMode.toUpperCase()} />
            </dl>
            <button
              className="mt-4 inline-flex h-12 w-full items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground transition hover:opacity-90"
              type="button"
              onClick={completeSale}
            >
              <ReceiptText aria-hidden="true" />
              Complete sale
            </button>
          </section>

          <section className="rounded-lg border border-border bg-card p-4">
            <div className="flex items-center justify-between gap-3">
              <h2 className="text-lg font-semibold">Hold sale</h2>
              <Clock3 className="text-primary" aria-hidden="true" />
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_auto_auto]">
              <select className="field-input" value={selectedHeldSaleId} onChange={(event) => setSelectedHeldSaleId(event.target.value)}>
                <option value="">Select held sale</option>
                {heldSales.map((sale) => (
                  <option key={sale.id} value={sale.id}>
                    {sale.saleNo} - {formatLak(sale.totalLak)} LAK
                  </option>
                ))}
              </select>
              <button className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-border px-3 text-sm font-semibold transition hover:border-primary" type="button" onClick={resumeSale}>
                <RotateCcw aria-hidden="true" />
                Resume
              </button>
              <button className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-border px-3 text-sm font-semibold transition hover:border-primary" type="button" onClick={holdSale}>
                <Clock3 aria-hidden="true" />
                Hold
              </button>
            </div>
          </section>
        </aside>
      </section>

      {receiptOpen ? (
        <ReceiptPreview
          branchName={branchName}
          cashierName={cashierName}
          cartItems={cartItems}
          changeAmount={changeAmount}
          discountTotal={discountTotal}
          onClose={() => setReceiptOpen(false)}
          paidAmount={paidAmount}
          paymentMode={paymentMode}
          subtotal={subtotal}
          taxAmount={taxAmount}
          totalAmount={totalAmount}
        />
      ) : null}
    </div>
  );
}

function InfoPill({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-border bg-background p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="mt-1 truncate text-sm font-semibold">{value}</div>
    </div>
  );
}

function Field({ children, label }: { children: React.ReactNode; label: string }) {
  return (
    <label className="flex flex-col gap-2 text-sm font-medium">
      {label}
      {children}
    </label>
  );
}

function TotalRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between text-muted-foreground">
      <dt>{label}</dt>
      <dd className="font-semibold text-foreground">{value}</dd>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-border bg-background p-3">
      <dt className="text-xs text-muted-foreground">{label}</dt>
      <dd className="mt-1 font-semibold">{value}</dd>
    </div>
  );
}

function PaymentButton({
  active,
  icon: Icon,
  label,
  onClick,
}: {
  active: boolean;
  icon: typeof Banknote;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      className={cn(
        "inline-flex h-11 items-center justify-center gap-2 rounded-md border px-3 text-sm font-semibold transition",
        active
          ? "border-primary bg-primary text-primary-foreground"
          : "border-border text-muted-foreground hover:border-primary hover:text-foreground",
      )}
      type="button"
      onClick={onClick}
    >
      <Icon aria-hidden="true" />
      {label}
    </button>
  );
}

function ReceiptPreview({
  branchName,
  cashierName,
  cartItems,
  changeAmount,
  discountTotal,
  onClose,
  paidAmount,
  paymentMode,
  subtotal,
  taxAmount,
  totalAmount,
}: {
  branchName: string;
  cashierName: string;
  cartItems: PosCartItem[];
  changeAmount: number;
  discountTotal: number;
  onClose: () => void;
  paidAmount: number;
  paymentMode: PaymentMode;
  subtotal: number;
  taxAmount: number;
  totalAmount: number;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
      <div className="max-h-[92vh] w-full max-w-md overflow-y-auto rounded-lg border border-border bg-card p-5 shadow-2xl">
        <div className="flex items-center justify-between gap-3 print:hidden">
          <h2 className="text-lg font-semibold">Receipt preview</h2>
          <button className="h-10 rounded-md border border-border px-3 text-sm font-semibold" type="button" onClick={onClose}>
            Close
          </button>
        </div>
        <div className="mt-4 rounded-md border border-border bg-background p-5 font-mono text-sm">
          <div className="text-center">
            <div className="text-lg font-bold">IGO POS</div>
            <div>{branchName}</div>
            <div>Cashier: {cashierName}</div>
            <div>{new Date().toLocaleString("en-GB")}</div>
          </div>
          <div className="my-4 border-t border-dashed border-border" />
          <div className="flex flex-col gap-3">
            {cartItems.map((item) => (
              <div key={item.id}>
                <div className="flex justify-between gap-3">
                  <span>{item.nameEn}</span>
                  <span>{formatLak(item.priceLak * item.quantity)}</span>
                </div>
                <div className="text-muted-foreground">
                  {item.quantity} x {formatLak(item.priceLak)} LAK
                </div>
              </div>
            ))}
          </div>
          <div className="my-4 border-t border-dashed border-border" />
          <ReceiptRow label="Subtotal" value={subtotal} />
          <ReceiptRow label="Discount" value={-discountTotal} />
          <ReceiptRow label="Tax" value={taxAmount} />
          <ReceiptRow label="Total" value={totalAmount} strong />
          <ReceiptRow label={`Paid ${paymentMode.toUpperCase()}`} value={paidAmount} />
          <ReceiptRow label="Change" value={changeAmount} />
          <div className="my-4 border-t border-dashed border-border" />
          <div className="text-center">ຂອບໃຈ / Thank you</div>
        </div>
        <button className="mt-4 inline-flex h-11 w-full items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground print:hidden" type="button" onClick={() => window.print()}>
          <Printer aria-hidden="true" />
          Print receipt
        </button>
      </div>
    </div>
  );
}

function ReceiptRow({
  label,
  strong = false,
  value,
}: {
  label: string;
  strong?: boolean;
  value: number;
}) {
  return (
    <div className={cn("flex justify-between gap-3", strong && "font-bold")}>
      <span>{label}</span>
      <span>{formatLak(value)} LAK</span>
    </div>
  );
}
