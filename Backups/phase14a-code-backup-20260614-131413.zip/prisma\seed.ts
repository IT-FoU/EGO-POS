import { hash } from "bcryptjs";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { databaseUrl } from "../lib/db/database-url";

const prisma = new PrismaClient({
  adapter: new PrismaPg({ connectionString: databaseUrl }),
});

const permissions = [
  ["dashboard.view", "View dashboard", "dashboard"],
  ["company.manage", "Manage companies", "company"],
  ["branch.manage", "Manage branches", "company"],
  ["warehouse.manage", "Manage warehouses", "inventory"],
  ["users.manage", "Manage users", "users"],
  ["roles.manage", "Manage roles and permissions", "permissions"],
  ["audit.view", "View audit logs", "audit"],
  ["products.view", "View products", "product"],
  ["inventory.view", "View inventory", "inventory"],
] as const;

async function main() {
  const plan = await prisma.plan.upsert({
    where: { planName: "Free" },
    update: {},
    create: {
      planName: "Free",
      maxProducts: 5000,
      maxCashiers: 3,
      maxBranches: 1,
      maxReports: 5,
      maxPromotions: 0,
      customLogo: false,
      removeWatermark: false,
    },
  });

  const owner = await prisma.user.upsert({
    where: { username: "owner" },
    update: {},
    create: {
      username: "owner",
      email: "owner@gobox.local",
      fullName: "Go BOX Owner",
      passwordHash: await hash("ChangeMe123!", 12),
      preferredLocale: "lo",
    },
  });

  const company = await prisma.company.upsert({
    where: { id: "gobox-company" },
    update: {
      ownerUserId: owner.id,
      planId: plan.id,
    },
    create: {
      id: "gobox-company",
      name: "Go BOX",
      ownerUserId: owner.id,
      planId: plan.id,
      defaultLocale: "lo",
      baseCurrency: "LAK",
    },
  });

  const branch = await prisma.branch.upsert({
    where: { id: "gobox-main-branch" },
    update: {},
    create: {
      id: "gobox-main-branch",
      companyId: company.id,
      name: "Go BOX Main Branch",
      isMainBranch: true,
    },
  });

  await prisma.warehouse.upsert({
    where: { id: "gobox-default-warehouse" },
    update: {},
    create: {
      id: "gobox-default-warehouse",
      companyId: company.id,
      branchId: branch.id,
      name: "Default Warehouse",
      type: "store",
    },
  });

  await prisma.companyUser.upsert({
    where: {
      companyId_userId: {
        companyId: company.id,
        userId: owner.id,
      },
    },
    update: { isOwner: true },
    create: {
      companyId: company.id,
      userId: owner.id,
      isOwner: true,
    },
  });

  const role = await prisma.role.upsert({
    where: {
      companyId_name: {
        companyId: company.id,
        name: "Owner",
      },
    },
    update: {},
    create: {
      companyId: company.id,
      name: "Owner",
      description: "Full access for store owner",
      isSystem: true,
    },
  });

  for (const [key, name, module] of permissions) {
    const permission = await prisma.permission.upsert({
      where: { key },
      update: { name, module },
      create: { key, name, module },
    });

    await prisma.rolePermission.upsert({
      where: {
        roleId_permissionId: {
          roleId: role.id,
          permissionId: permission.id,
        },
      },
      update: {},
      create: {
        roleId: role.id,
        permissionId: permission.id,
      },
    });
  }

  await prisma.userRole.upsert({
    where: {
      userId_roleId: {
        userId: owner.id,
        roleId: role.id,
      },
    },
    update: { companyId: company.id },
    create: {
      userId: owner.id,
      roleId: role.id,
      companyId: company.id,
    },
  });

  await prisma.auditLog.create({
    data: {
      companyId: company.id,
      userId: owner.id,
      module: "system",
      action: "seed",
      newData: {
        message: "Phase 0 foundation seed completed",
      },
    },
  });

  console.info("Seed complete. Login with username owner and password ChangeMe123!");
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
