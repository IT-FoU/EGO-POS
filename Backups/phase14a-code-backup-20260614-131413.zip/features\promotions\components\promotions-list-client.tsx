"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Eye, Gift, Plus, Search, SlidersHorizontal } from "lucide-react";
import { PromotionStatusBadge } from "@/features/promotions/components/promotion-status-badge";
import { formatLak, formatPromotionType } from "@/features/promotions/format";
import type { Promotion, PromotionStatus } from "@/features/promotions/types";

const statusOptions: Array<PromotionStatus | "all"> = [
  "all",
  "active",
  "scheduled",
  "inactive",
  "expired",
];

export function PromotionsListClient({
  promotions,
}: {
  promotions: Promotion[];
}) {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<PromotionStatus | "all">("all");

  const filteredPromotions = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();

    return promotions.filter((promotion) => {
      const matchesQuery =
        normalizedQuery.length === 0 ||
        [
          promotion.promotionCode,
          promotion.promotionName,
          promotion.description,
          promotion.type,
        ]
          .join(" ")
          .toLowerCase()
          .includes(normalizedQuery);
      const matchesStatus = status === "all" || promotion.status === status;

      return matchesQuery && matchesStatus;
    });
  }, [promotions, query, status]);

  const activeCount = promotions.filter((promotion) => promotion.status === "active").length;
  const totalDiscount = promotions.reduce(
    (total, promotion) => total + promotion.totalDiscountLak,
    0,
  );
  const totalUsage = promotions.reduce(
    (total, promotion) => total + promotion.usageCount,
    0,
  );

  return (
    <div className="flex flex-col gap-6">
      <section className="rounded-lg border border-border bg-card p-6">
        <div className="flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between">
          <div>
            <p className="text-sm font-medium text-primary">Promotion Management</p>
            <h1 className="mt-2 text-3xl font-semibold">Promotions / ໂປຣໂມຊັນ</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">
              Manage mock discount campaigns, member offers, combo sets, and
              buy-x-get-y promotions with product/category targeting.
            </p>
          </div>
          <Link
            className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground transition hover:opacity-90"
            href="/promotions/new"
          >
            <Plus aria-hidden="true" />
            Create promotion
          </Link>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        <Metric icon={Gift} label="Active promotions" value={String(activeCount)} />
        <Metric icon={SlidersHorizontal} label="Total usage" value={formatLak(totalUsage)} />
        <Metric icon={Eye} label="Discount given" value={`${formatLak(totalDiscount)} LAK`} />
      </section>

      <section className="rounded-lg border border-border bg-card p-5">
        <div className="flex min-w-0 flex-col gap-3 md:flex-row">
          <label className="relative flex-1">
            <Search
              aria-hidden="true"
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            />
            <input
              className="field-input pl-10"
              placeholder="Search code, name, description, type"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
          </label>
          <select
            className="field-input md:w-48"
            value={status}
            onChange={(event) => setStatus(event.target.value as PromotionStatus | "all")}
            aria-label="Filter by promotion status"
          >
            {statusOptions.map((option) => (
              <option value={option} key={option}>
                {option === "all" ? "All statuses" : option}
              </option>
            ))}
          </select>
        </div>
      </section>

      <section className="overflow-hidden rounded-lg border border-border bg-card">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[980px] border-collapse text-left text-sm">
            <thead className="border-b border-border bg-background text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-semibold">Promotion code</th>
                <th className="px-4 py-3 font-semibold">Promotion name</th>
                <th className="px-4 py-3 font-semibold">Type</th>
                <th className="px-4 py-3 font-semibold">Start date</th>
                <th className="px-4 py-3 font-semibold">End date</th>
                <th className="px-4 py-3 font-semibold">Status</th>
                <th className="px-4 py-3 text-right font-semibold">Priority</th>
                <th className="px-4 py-3 text-right font-semibold">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredPromotions.map((promotion) => (
                <tr className="border-b border-border last:border-b-0" key={promotion.id}>
                  <td className="px-4 py-4 font-mono text-xs">{promotion.promotionCode}</td>
                  <td className="px-4 py-4">
                    <div className="font-semibold">{promotion.promotionName}</div>
                    <div className="mt-1 line-clamp-1 text-xs text-muted-foreground">
                      {promotion.description}
                    </div>
                  </td>
                  <td className="px-4 py-4">{formatPromotionType(promotion.type)}</td>
                  <td className="px-4 py-4">{promotion.startDate}</td>
                  <td className="px-4 py-4">{promotion.endDate}</td>
                  <td className="px-4 py-4">
                    <PromotionStatusBadge status={promotion.status} />
                  </td>
                  <td className="px-4 py-4 text-right font-semibold">{promotion.priority}</td>
                  <td className="px-4 py-4 text-right">
                    <Link
                      className="inline-flex h-9 items-center gap-2 rounded-md border border-border px-3 text-xs font-semibold transition hover:border-primary"
                      href={`/promotions/${promotion.id}`}
                    >
                      <Eye aria-hidden="true" />
                      View
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredPromotions.length === 0 ? (
          <div className="p-8 text-center text-sm text-muted-foreground">
            No promotions match the current search and filters.
          </div>
        ) : null}
      </section>
    </div>
  );
}

function Metric({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Gift;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-lg border border-border bg-card p-5">
      <div className="flex items-center justify-between gap-4">
        <div>
          <div className="text-sm text-muted-foreground">{label}</div>
          <div className="mt-2 text-2xl font-semibold">{value}</div>
        </div>
        <div className="grid size-11 place-items-center rounded-md bg-primary/10 text-primary">
          <Icon aria-hidden="true" />
        </div>
      </div>
    </div>
  );
}
