import { prisma } from "@/lib/db/prisma";
import type { SupplierPayment, SupplierPurchaseOrder, SupplierReceiving } from "@/features/suppliers/types";
import type { TenantContext } from "@/lib/db/write-context";
import { numberValue, optionalString, stringValue, withTenantTransaction } from "@/lib/db/write-context";
import {
  mapPrismaSupplier,
  mapPrismaSupplierPayment,
  mapPrismaSupplierPurchaseOrder,
  mapPrismaSupplierReceiving,
} from "@/features/suppliers/dto-mapper";

const db = prisma as any;

export async function getPrismaSuppliersSnapshot() {
  const [suppliers, purchaseOrders, receivings, payments] = await Promise.all([
    db.supplier.findMany({ orderBy: { name: "asc" } }),
    db.purchase.findMany({ include: { warehouse: true }, orderBy: { purchaseDate: "desc" } }),
    db.goodsReceipt.findMany({
      include: { items: true, purchase: true, warehouse: true },
      orderBy: { receivedAt: "desc" },
    }),
    db.purchasePayment.findMany({
      include: { purchase: true },
      orderBy: { paymentDate: "desc" },
    }),
  ]);

  return {
    payments: payments.map(mapPrismaSupplierPayment),
    purchaseOrders: purchaseOrders.map(mapPrismaSupplierPurchaseOrder),
    receivings: receivings.map(mapPrismaSupplierReceiving),
    suppliers: suppliers.map(mapPrismaSupplier),
  };
}

export async function getPrismaSuppliers() {
  const { suppliers } = await getPrismaSuppliersSnapshot();
  return suppliers;
}

export async function getPrismaSupplierById(supplierId: string) {
  const supplier = await db.supplier.findUnique({ where: { id: supplierId } });
  return supplier ? mapPrismaSupplier(supplier) : undefined;
}

export async function getPrismaSupplierDetail(supplierId: string) {
  const [snapshot, supplier] = await Promise.all([
    getPrismaSuppliersSnapshot(),
    getPrismaSupplierById(supplierId),
  ]);

  return {
    payments: snapshot.payments.filter((payment: SupplierPayment) => payment.supplierId === supplierId),
    purchaseOrders: snapshot.purchaseOrders.filter((order: SupplierPurchaseOrder) => order.supplierId === supplierId),
    receivings: snapshot.receivings.filter((receiving: SupplierReceiving) => receiving.supplierId === supplierId),
    supplier,
  };
}

export async function createPrismaSupplier(input: {
  address?: string;
  companyName?: string;
  contactPerson?: string;
  creditLimit?: number;
  email?: string;
  note?: string;
  openingBalance?: number;
  phone?: string;
  supplierCode?: string;
  taxNumber?: string;
}, tenant: TenantContext) {
  return withTenantTransaction({
    action: "create",
    module: "suppliers",
    newData: input,
    tenant,
    write: async (tx) => tx.supplier.create({
      data: {
        address: optionalString(input.address),
        companyId: tenant.companyId,
        companyName: optionalString(input.companyName),
        contactPerson: optionalString(input.contactPerson),
        creditLimit: numberValue(input.creditLimit),
        email: optionalString(input.email),
        name: stringValue(input.companyName, "Supplier"),
        note: optionalString(input.note),
        openingBalance: numberValue(input.openingBalance),
        outstandingBalance: numberValue(input.openingBalance),
        phone: optionalString(input.phone),
        supplierCode: optionalString(input.supplierCode),
        taxNumber: optionalString(input.taxNumber),
      },
    }),
  });
}

export async function updatePrismaSupplier(supplierId: string, input: Record<string, unknown>, tenant: TenantContext) {
  return withTenantTransaction({
    action: "update",
    module: "suppliers",
    newData: { supplierId, ...input },
    tenant,
    write: async (tx) => {
      const existing = await tx.supplier.findFirstOrThrow({ where: { companyId: tenant.companyId, id: supplierId } });
      return tx.supplier.update({ data: input, where: { id: existing.id } });
    },
  });
}

export async function archivePrismaSupplier(supplierId: string, tenant: TenantContext) {
  return updatePrismaSupplier(supplierId, { status: "inactive" }, tenant);
}
