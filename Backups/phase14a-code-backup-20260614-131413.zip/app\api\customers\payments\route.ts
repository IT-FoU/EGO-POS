import { createPrismaCustomerPayment } from "@/features/customers/prisma-repository";
import { runWrite } from "@/lib/api/write-response";

export async function POST(request: Request) {
  return runWrite((tenant, body) => createPrismaCustomerPayment(body, tenant), request);
}
