import type { PaymentMode, PosProduct } from "@/features/pos/types";

type Row = Record<string, any>;

function toNumber(value: unknown) {
  return value == null ? 0 : Number(value);
}

export function mapPrismaPosProduct(product: Row): PosProduct {
  const baseUnit = product.units?.find((unit: Row) => unit.isBaseUnit) ?? product.units?.[0];
  const stockQty = (product.balances ?? []).reduce(
    (total: number, balance: Row) => total + toNumber(balance.quantity),
    0,
  );

  return {
    barcode: product.barcode ?? "",
    categoryName: product.category?.nameEn ?? product.category?.nameLo ?? "",
    id: product.id,
    imageKey: product.imageUrl ?? "generic",
    nameEn: product.nameEn ?? "",
    nameLo: product.nameLo,
    priceLak: toNumber(product.sellingPriceLak),
    sku: product.sku ?? "",
    stockQty,
    unitName: baseUnit?.unitName ?? "Piece",
  };
}

export function mapPaymentModeToSalePayments({
  cashAmount,
  changeAmount,
  paymentMode,
  qrAmount,
}: {
  cashAmount: number;
  changeAmount: number;
  paymentMode: PaymentMode;
  qrAmount: number;
}) {
  if (paymentMode === "mixed") {
    return [
      { amount: cashAmount, changeAmount, paymentMethod: "cash" as const },
      { amount: qrAmount, changeAmount: 0, paymentMethod: "qr" as const },
    ].filter((payment) => payment.amount > 0);
  }

  return [
    {
      amount: paymentMode === "cash" ? cashAmount : qrAmount,
      changeAmount,
      paymentMethod: paymentMode,
    },
  ];
}
