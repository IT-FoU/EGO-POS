export type Warehouse = {
  id: string;
  name: string;
  branchName: string;
  type: "store" | "stockroom" | "distribution";
};

export type InventoryItem = {
  id: string;
  warehouseId: string;
  imageKey: string;
  productNameLo: string;
  productNameEn: string;
  barcode: string;
  sku: string;
  category: string;
  baseUnit: string;
  quantity: number;
  minStock: number;
  expiryDate?: string;
  lastMovementAt: string;
  daysWithoutSale: number;
};

export type StockMovement = {
  id: string;
  warehouseId: string;
  productName: string;
  sku: string;
  movementType:
    | "stock_in"
    | "adjustment"
    | "count"
    | "transfer_in"
    | "transfer_out"
    | "expired";
  quantity: number;
  beforeQty: number;
  afterQty: number;
  note: string;
  createdBy: string;
  createdAt: string;
};
