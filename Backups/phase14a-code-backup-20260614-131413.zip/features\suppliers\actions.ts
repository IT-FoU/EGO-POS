"use server";

import { requireSession } from "@/lib/auth/session";
import { tenantFromSession, writeFailure, writeSuccess } from "@/lib/db/write-context";
import { archivePrismaSupplier, createPrismaSupplier, updatePrismaSupplier } from "@/features/suppliers/prisma-repository";

async function tenant() {
  return tenantFromSession(await requireSession());
}

export async function createSupplierAction(input: Parameters<typeof createPrismaSupplier>[0]) {
  try { return writeSuccess(await createPrismaSupplier(input, await tenant())); } catch (error) { return writeFailure(error); }
}

export async function updateSupplierAction(supplierId: string, input: Record<string, unknown>) {
  try { return writeSuccess(await updatePrismaSupplier(supplierId, input, await tenant())); } catch (error) { return writeFailure(error); }
}

export async function archiveSupplierAction(supplierId: string) {
  try { return writeSuccess(await archivePrismaSupplier(supplierId, await tenant())); } catch (error) { return writeFailure(error); }
}
