import { prisma } from "@/lib/db/prisma";
import type { TenantContext } from "@/lib/db/write-context";
import { numberValue, optionalString, withTenantTransaction } from "@/lib/db/write-context";
import {
  mapPrismaInventoryBalance,
  mapPrismaStockMovement,
  mapPrismaWarehouse,
} from "@/features/inventory/dto-mapper";

const db = prisma as any;

export async function getPrismaInventorySnapshot() {
  const [warehouses, balances, movements] = await Promise.all([
    db.warehouse.findMany({ include: { branch: true }, orderBy: { name: "asc" } }),
    db.inventoryBalance.findMany({
      include: {
        product: {
          include: {
            category: true,
            inventoryLots: { orderBy: { expiryDate: "asc" }, take: 1 },
            units: true,
          },
        },
      },
      orderBy: { updatedAt: "desc" },
    }),
    db.stockMovement.findMany({
      include: { product: true },
      orderBy: { createdAt: "desc" },
      take: 50,
    }),
  ]);

  return {
    items: balances.map(mapPrismaInventoryBalance),
    movements: movements.map(mapPrismaStockMovement),
    warehouses: warehouses.map(mapPrismaWarehouse),
  };
}

export async function createStockIn(input: {
  expiryDate?: string;
  lotNumber?: string;
  note?: string;
  productId: string;
  quantity: number;
  unitId?: string;
  warehouseId: string;
}, tenant: TenantContext) {
  return withTenantTransaction({
    action: "stock_in",
    module: "inventory",
    newData: input,
    tenant,
    write: async (tx) => {
      const balance = await tx.inventoryBalance.upsert({
        create: {
          companyId: tenant.companyId,
          productId: input.productId,
          quantity: numberValue(input.quantity),
          warehouseId: input.warehouseId,
        },
        update: { quantity: { increment: numberValue(input.quantity) } },
        where: { warehouseId_productId: { productId: input.productId, warehouseId: input.warehouseId } },
      });

      await tx.inventoryLot.create({
        data: {
          companyId: tenant.companyId,
          expiryDate: input.expiryDate ? new Date(input.expiryDate) : undefined,
          lotNumber: optionalString(input.lotNumber),
          productId: input.productId,
          quantity: numberValue(input.quantity),
          receivedAt: new Date(),
          warehouseId: input.warehouseId,
        },
      });

      await tx.stockMovement.create({
        data: {
          afterQty: balance.quantity,
          beforeQty: Number(balance.quantity) - numberValue(input.quantity),
          companyId: tenant.companyId,
          createdBy: tenant.userId,
          lotNumber: optionalString(input.lotNumber),
          movementType: "purchase",
          note: optionalString(input.note),
          productId: input.productId,
          quantity: numberValue(input.quantity),
          referenceType: "stock_in",
          unitId: optionalString(input.unitId),
          warehouseId: input.warehouseId,
        },
      });

      return balance;
    },
  });
}

export async function createStockAdjustment(input: {
  note?: string;
  productId: string;
  quantity: number;
  reason?: string;
  warehouseId: string;
}, tenant: TenantContext) {
  return withTenantTransaction({
    action: "adjustment",
    module: "inventory",
    newData: input,
    tenant,
    write: async (tx) => {
      const current = await tx.inventoryBalance.findUnique({
        where: { warehouseId_productId: { productId: input.productId, warehouseId: input.warehouseId } },
      });
      const beforeQty = Number(current?.quantity ?? 0);
      const afterQty = beforeQty + numberValue(input.quantity);
      const balance = await tx.inventoryBalance.upsert({
        create: {
          companyId: tenant.companyId,
          productId: input.productId,
          quantity: afterQty,
          warehouseId: input.warehouseId,
        },
        update: { quantity: afterQty },
        where: { warehouseId_productId: { productId: input.productId, warehouseId: input.warehouseId } },
      });

      await tx.stockAdjustment.create({
        data: {
          adjustmentType: input.quantity >= 0 ? "increase" : "decrease",
          companyId: tenant.companyId,
          createdBy: tenant.userId,
          productId: input.productId,
          quantity: numberValue(input.quantity),
          reason: optionalString(input.reason),
          warehouseId: input.warehouseId,
        },
      });

      await tx.stockMovement.create({
        data: {
          afterQty,
          beforeQty,
          companyId: tenant.companyId,
          createdBy: tenant.userId,
          movementType: "adjustment",
          note: optionalString(input.note),
          productId: input.productId,
          quantity: numberValue(input.quantity),
          referenceType: "stock_adjustment",
          warehouseId: input.warehouseId,
        },
      });

      return balance;
    },
  });
}

export async function createStockCount(input: {
  countedQuantity: number;
  note?: string;
  productId: string;
  warehouseId: string;
}, tenant: TenantContext) {
  return withTenantTransaction({
    action: "count",
    module: "inventory",
    newData: input,
    tenant,
    write: async (tx) => {
      const current = await tx.inventoryBalance.findUnique({
        where: { warehouseId_productId: { productId: input.productId, warehouseId: input.warehouseId } },
      });
      const beforeQty = Number(current?.quantity ?? 0);
      const afterQty = numberValue(input.countedQuantity);
      const balance = await tx.inventoryBalance.upsert({
        create: {
          companyId: tenant.companyId,
          productId: input.productId,
          quantity: afterQty,
          warehouseId: input.warehouseId,
        },
        update: { quantity: afterQty },
        where: { warehouseId_productId: { productId: input.productId, warehouseId: input.warehouseId } },
      });
      await tx.stockMovement.create({
        data: {
          afterQty,
          beforeQty,
          companyId: tenant.companyId,
          createdBy: tenant.userId,
          movementType: "adjustment",
          note: optionalString(input.note),
          productId: input.productId,
          quantity: afterQty - beforeQty,
          referenceType: "stock_count",
          warehouseId: input.warehouseId,
        },
      });
      return balance;
    },
  });
}
