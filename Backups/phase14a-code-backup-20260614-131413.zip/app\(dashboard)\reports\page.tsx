import {
  BarChart3,
  CircleDollarSign,
  Package,
  ReceiptText,
  ShoppingCart,
  Truck,
  Users,
  Warehouse,
} from "lucide-react";
import {
  BarChart,
  MetricCard,
  ReportHeader,
  ReportLinkCard,
} from "@/features/reports/components/report-primitives";
import { formatLak, formatNumber } from "@/features/reports/format";
import { getReportsSnapshot } from "@/features/reports/report-service";

export default async function ReportsPage() {
  const { analytics, revenueTrend } = await getReportsSnapshot();

  return (
    <div className="flex flex-col gap-6">
      <ReportHeader
        title="Reports & Analytics / ລາຍງານ"
        description="Mock analytics dashboard for revenue, profit, transactions, customers, sales trends, and category breakdown."
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard icon={CircleDollarSign} label="Total Revenue" value={`${formatLak(analytics.totalRevenue)} LAK`} />
        <MetricCard icon={BarChart3} label="Total Profit" value={`${formatLak(analytics.totalProfit)} LAK`} />
        <MetricCard icon={ReceiptText} label="Total Transactions" value={formatNumber(analytics.totalTransactions)} />
        <MetricCard icon={Users} label="Total Customers" value={formatNumber(analytics.totalCustomers)} />
      </section>

      <section className="grid gap-6 xl:grid-cols-2">
        <BarChart
          rows={revenueTrend.map((point) => ({
            label: point.label,
            revenue: point.revenueLak,
          }))}
          title="Revenue Trend"
          valueKey="revenue"
        />
        <BarChart
          rows={revenueTrend.map((point) => ({
            label: point.label,
            sales: point.salesCount,
          }))}
          title="Sales Trend"
          valueKey="sales"
          valueType="number"
        />
      </section>

      <BarChart
        rows={analytics.categoryBreakdown}
        title="Product Category Breakdown"
        valueKey="value"
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
        <ReportLinkCard icon={ShoppingCart} title="Sales Report" href="/reports/sales" description="Daily, weekly, monthly, and yearly revenue, profit, tax, and transactions." />
        <ReportLinkCard icon={Package} title="Product Report" href="/reports/products" description="Top selling, low selling, revenue, and profit by product." />
        <ReportLinkCard icon={Warehouse} title="Inventory Report" href="/reports/inventory" description="Current stock, low stock, dead stock, and expiring stock." />
        <ReportLinkCard icon={Users} title="Customer Report" href="/reports/customers" description="Top customers, loyalty points, and customer spending." />
        <ReportLinkCard icon={Truck} title="Purchasing Report" href="/reports/purchasing" description="Purchases by supplier, payables, and purchase trends." />
      </section>
    </div>
  );
}
