import { archivePrismaProduct, deletePrismaProduct, updatePrismaProduct } from "@/features/products/prisma-repository";
import { runWrite } from "@/lib/api/write-response";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return runWrite((tenant, body) => updatePrismaProduct(id, body, tenant), request);
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const url = new URL(request.url);
  return runWrite((tenant) => url.searchParams.get("hard") === "true" ? deletePrismaProduct(id, tenant) : archivePrismaProduct(id, tenant));
}
