import type { StockMovement } from "@/features/inventory/types";

const movementLabels: Record<StockMovement["movementType"], string> = {
  stock_in: "Stock in",
  adjustment: "Adjustment",
  count: "Count",
  transfer_in: "Transfer in",
  transfer_out: "Transfer out",
  expired: "Expired",
};

export function StockMovementHistory({
  movements,
}: {
  movements: StockMovement[];
}) {
  return (
    <section className="overflow-hidden rounded-lg border border-border bg-card">
      <div className="border-b border-border p-5">
        <h2 className="text-lg font-semibold">Stock movement history</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Mock audit trail for stock changes by warehouse and product.
        </p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[880px] text-left text-sm">
          <thead className="border-b border-border bg-background text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Time</th>
              <th className="px-4 py-3">Type</th>
              <th className="px-4 py-3">Product</th>
              <th className="px-4 py-3">SKU</th>
              <th className="px-4 py-3 text-right">Before</th>
              <th className="px-4 py-3 text-right">Qty</th>
              <th className="px-4 py-3 text-right">After</th>
              <th className="px-4 py-3">Note</th>
              <th className="px-4 py-3">By</th>
            </tr>
          </thead>
          <tbody>
            {movements.map((movement) => (
              <tr className="border-b border-border last:border-b-0" key={movement.id}>
                <td className="px-4 py-4 text-muted-foreground">{movement.createdAt}</td>
                <td className="px-4 py-4 font-semibold">
                  {movementLabels[movement.movementType]}
                </td>
                <td className="px-4 py-4">{movement.productName}</td>
                <td className="px-4 py-4 font-mono text-xs">{movement.sku}</td>
                <td className="px-4 py-4 text-right">{movement.beforeQty}</td>
                <td className="px-4 py-4 text-right font-semibold">
                  {movement.quantity > 0 ? `+${movement.quantity}` : movement.quantity}
                </td>
                <td className="px-4 py-4 text-right">{movement.afterQty}</td>
                <td className="px-4 py-4 text-muted-foreground">{movement.note}</td>
                <td className="px-4 py-4">{movement.createdBy}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
