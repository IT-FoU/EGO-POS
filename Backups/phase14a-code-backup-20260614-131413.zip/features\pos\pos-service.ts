import { mockPosProducts } from "@/features/pos/mock-data";
import type { PosProduct } from "@/features/pos/types";
import { isDemoMode } from "@/lib/demo-mode";
import { getPrismaPosSnapshot } from "@/features/pos/prisma-repository";

export async function getPosSnapshot(): Promise<{
  products: PosProduct[];
  taxRatePercent: number;
  cashierName: string;
  branchName: string;
}> {
  if (!isDemoMode()) {
    return getPrismaPosSnapshot();
  }

  return {
    products: mockPosProducts,
    taxRatePercent: 10,
    cashierName: "Go BOX Owner",
    branchName: "Go BOX Main Branch",
  };
}
